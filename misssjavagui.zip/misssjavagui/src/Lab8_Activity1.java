/**
 * 
 */
/**
 * @author Administrator
 *
 */

import javax.swing.JOptionPane;
public class Lab8_Activity1 {
	static String name;
	static double balance;
	public static void main(String[] args) {

		
	int amt;
	 name = JOptionPane.showInputDialog("Enter your name: ");
	String [] options = {"Display", "Deposit", "Withdraw","Exit"};
			 Welcome(name);
	 
			 do {
String opt = (String)(JOptionPane.showInputDialog(null,
		"What do you want to do?",
		"Transaction",
		JOptionPane.QUESTION_MESSAGE,
		null, 
		options, 
		options[0]));

	switch(opt) {
	
	case "Display": display();
		   break;
	
	case "Deposit": amt = Integer.parseInt(JOptionPane.showInputDialog("Enter amount to deposit: "));
	deposit(amt);
	break;
	
	case "Withdraw": amt = Integer.parseInt(JOptionPane.showInputDialog("Enter amount to withdraw: "));
	withdraw(amt);
	break;
	
	case "Exit": exit();
	break;
	}
	}while (JOptionPane.showConfirmDialog(null,"Any more try?")==0);
	}
	
			static void exit(){
				JOptionPane.showMessageDialog(null, "Thank you and say goodbye to your money :>");
				System.exit(0);
			}
	 static void deposit(int amt) 
	{
		 balance = balance + amt; 
       JOptionPane.showMessageDialog(null,"name: " +name +"\n balance: "+balance);
	
		 
	}
	 static void display() {
		 JOptionPane.showMessageDialog(null,"name: " +name +"\n balance: " +balance);
	}
 static double withdraw(int amt) 
	{
		 balance = balance - amt; 
		 return  balance; 
	}
	static void Welcome(String fname) {
	{
		  JOptionPane.showMessageDialog(null,"Welcome to my ATM, " +fname,
				  "Careful with your Money",JOptionPane.WARNING_MESSAGE);
		  
		 
		 
	
	}
	
	 
	}

}
