package SCIENTIFIC;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import java.awt.CardLayout;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.Container;
import java.awt.Toolkit;

public class SCI_CALCULATOR extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	double temp, temp1, result, a;
	static double m1, m2;
	int k = 1, x = 0, y = 0, z = 0;
	char ch;
	public static String s;
	JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, zero, clr, pow2, pow3, exp,
			fac, plus, min, div, log, rec, mul, eq, addSub, dot, mr, mc, mp,
			mm, sqrt, sin, cos, tan;
	Container cont;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// get the theme 
					
					UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
					
					// create a jframe
					SCI_CALCULATOR frame = new SCI_CALCULATOR();
					frame.setVisible(true);
					frame.setResizable(false);;
					frame.setLocationRelativeTo(null);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws UnsupportedLookAndFeelException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 */
	public SCI_CALCULATOR() throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\JAVA_ECLIPSE\\WEN_SCIENTIFIC_CALCULATOR\\src\\scientific-calculator.png"));
		setTitle("WENDEV SCIENTIFIC CALCULATOR");
		
		// gui theme
		UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 529, 812);
		contentPane = new JAVA2D();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("MR");
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton.setBackground(new Color(255, 128, 64));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s = e.getActionCommand();
				if (s.equals("MR")) {
					textField.setText("");
					textField.setText(textField.getText() + m1);
				}
			}
		});
		btnNewButton.setBounds(20, 173, 104, 64);
		contentPane.add(btnNewButton);
		
		textField = new JTextField();
		textField.setFont(new Font("Verdana", Font.PLAIN, 20));
		textField.setForeground(new Color(255, 255, 255));
		textField.setBackground(new Color(128, 128, 128));
		textField.setBounds(20, 79, 472, 64);
		contentPane.add(textField);
		textField.setEditable(false);
		textField.setColumns(10);
		textField.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent keyevent) {
				char c = keyevent.getKeyChar();
				if (c >= '0' && c <= '9') {
				} else {
					keyevent.consume();
				}
			}
		});
		
		JLabel lblNewLabel = new JLabel("WENDEV SCIENTIFIC CALCULATOR V1.0");
		lblNewLabel.setForeground(new Color(0, 64, 64));
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel.setBounds(20, 0, 493, 87);
		contentPane.add(lblNewLabel);
		
		JButton btnMc = new JButton("MC");
		btnMc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s = e.getActionCommand();
				if (s.equals("MC")) {
					m1 = 0;
					textField.setText("");
				}
			}
		});
		btnMc.setForeground(Color.WHITE);
		btnMc.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnMc.setBackground(new Color(255, 128, 64));
		btnMc.setBounds(144, 173, 104, 64);
		contentPane.add(btnMc);
		
		JButton btnM = new JButton("M+");
		btnM.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
				if (s.equals("M+")) {
					if (k == 1) {
						m1 = Double.parseDouble(textField.getText());
						k++;
					} else {
						m1 += Double.parseDouble(textField.getText());
						textField.setText("" + m1);
					}
				}
			}
		});
		btnM.setForeground(Color.WHITE);
		btnM.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnM.setBackground(new Color(255, 128, 64));
		btnM.setBounds(268, 173, 104, 60);
		contentPane.add(btnM);
		
		JButton btnM_2 = new JButton("M-");
		btnM_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
				if (s.equals("M-")) {
					if (k == 1) {
						m1 = Double.parseDouble(textField.getText());
						k++;
					} else {
						m1 -= Double.parseDouble(textField.getText());
						textField.setText("" + m1);
					}
				}
			}
		});
		btnM_2.setForeground(Color.WHITE);
		btnM_2.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnM_2.setBackground(new Color(255, 128, 64));
		btnM_2.setBounds(383, 173, 109, 60);
		contentPane.add(btnM_2);
		
		JButton btnNewButton_1 = new JButton("1");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
				if (s.equals("1")) {
					if (z == 0) {
						textField.setText(textField.getText() + "1");
					} else {
						textField.setText("");
						textField.setText(textField.getText() + "1");
						z = 0;
					}
				}
			}
		});
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_1.setBackground(new Color(255, 128, 64));
		btnNewButton_1.setBounds(20, 249, 104, 64);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("2");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
					if (s.equals("2")) {
						if (z == 0) {
							textField.setText(textField.getText() + "2");
						} else {
							textField.setText("");
							textField.setText(textField.getText() + "2");
							z = 0;
						}
					}
			}
		});
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_2.setBackground(new Color(255, 128, 64));
		btnNewButton_2.setBounds(144, 248, 104, 64);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("3");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
					if (s.equals("3")) {
						if (z == 0) {
							textField.setText(textField.getText() + "3");
						} else {
							textField.setText("");
							textField.setText(textField.getText() + "3");
							z = 0;
						}
					}
			}
		});
		btnNewButton_3.setForeground(Color.WHITE);
		btnNewButton_3.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_3.setBackground(new Color(255, 128, 64));
		btnNewButton_3.setBounds(268, 244, 104, 68);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("4");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
					if (s.equals("4")) {
						if (z == 0) {
							textField.setText(textField.getText() + "4");
						} else {
							textField.setText("");
							textField.setText(textField.getText() + "4");
							z = 0;
						}
					}
			}
		});
		btnNewButton_4.setForeground(Color.WHITE);
		btnNewButton_4.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_4.setBackground(new Color(255, 128, 64));
		btnNewButton_4.setBounds(383, 244, 109, 64);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("5");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
					if (s.equals("5")) {
						if (z == 0) {
							textField.setText(textField.getText() + "5");
						} else {
							textField.setText("");
							textField.setText(textField.getText() + "5");
							z = 0;
						}
					}
				
			}
		});
		btnNewButton_5.setForeground(Color.WHITE);
		btnNewButton_5.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_5.setBackground(new Color(255, 128, 64));
		btnNewButton_5.setBounds(20, 323, 104, 64);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("6");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
					if (s.equals("6")) {
						if (z == 0) {
							textField.setText(textField.getText() + "6");
						} else {
							textField.setText("");
							textField.setText(textField.getText() + "6");
							z = 0;
						}
					}
			}
		});
		btnNewButton_6.setForeground(Color.WHITE);
		btnNewButton_6.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_6.setBackground(new Color(255, 128, 64));
		btnNewButton_6.setBounds(144, 323, 104, 64);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("7");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
					if (s.equals("7")) {
						if (z == 0) {
							textField.setText(textField.getText() + "7");
						} else {
							textField.setText("");
							textField.setText(textField.getText() + "7");
							z = 0;
						}
					}
			}
		});
		btnNewButton_7.setForeground(Color.WHITE);
		btnNewButton_7.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_7.setBackground(new Color(255, 128, 64));
		btnNewButton_7.setBounds(268, 323, 104, 64);
		contentPane.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("8");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
					if (s.equals("8")) {
						if (z == 0) {
							textField.setText(textField.getText() + "8");
						} else {
							textField.setText("");
							textField.setText(textField.getText() + "8");
							z = 0;
						}
					}
			}
		});
		btnNewButton_8.setForeground(Color.WHITE);
		btnNewButton_8.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_8.setBackground(new Color(255, 128, 64));
		btnNewButton_8.setBounds(383, 324, 109, 60);
		contentPane.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("9");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = e.getActionCommand();
				if (s.equals("9")) {
					if (z == 0) {
						textField.setText(textField.getText() + "9");
					} else {
						textField.setText("");
						textField.setText(textField.getText() + "9");
						z = 0;
					}
				}
			}
		});
		btnNewButton_9.setForeground(Color.WHITE);
		btnNewButton_9.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9.setBackground(new Color(255, 128, 64));
		btnNewButton_9.setBounds(20, 398, 104, 64);
		contentPane.add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("0");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
					if (s.equals("0")) {
						if (z == 0) {
							textField.setText(textField.getText() + "0");
						} else {
							textField.setText("");
							textField.setText(textField.getText() + "0");
							z = 0;
						}
					}
			}
		});
		btnNewButton_10.setForeground(Color.WHITE);
		btnNewButton_10.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_10.setBackground(new Color(255, 128, 64));
		btnNewButton_10.setBounds(144, 398, 104, 64);
		contentPane.add(btnNewButton_10);
		
		JButton btnNewButton_11 = new JButton("+");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s = e.getActionCommand();
				if (s.equals("+")) {
					if (textField.getText().equals("")) {
						textField.setText("");
						temp = 0;
						ch = '+';
					} else {
						temp = Double.parseDouble(textField.getText());
						textField.setText("");
						ch = '+';
						y = 0;
						x = 0;
					}
					textField.requestFocus();
				}
				
			}
		});
		btnNewButton_11.setForeground(Color.WHITE);
		btnNewButton_11.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_11.setBackground(new Color(255, 128, 64));
		btnNewButton_11.setBounds(268, 398, 104, 64);
		contentPane.add(btnNewButton_11);
		
		JButton btnNewButton_12 = new JButton("-");
		btnNewButton_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s = e.getActionCommand();
				if (s.equals("-")) {
					if (textField.getText().equals("")) {
						textField.setText("");
						temp = 0;
						ch = '-';
					} else {
						x = 0;
						y = 0;
						temp = Double.parseDouble(textField.getText());
						textField.setText("");
						ch = '-';
					}
					textField.requestFocus();
				}
			}
		});
		btnNewButton_12.setForeground(Color.WHITE);
		btnNewButton_12.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_12.setBackground(new Color(255, 128, 64));
		btnNewButton_12.setBounds(383, 398, 109, 64);
		contentPane.add(btnNewButton_12);
		
		JButton btnNewButton_9_1 = new JButton("X");
		btnNewButton_9_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s = e.getActionCommand();
				if (s.equals("X")) {
					if (textField.getText().equals("")) {
						textField.setText("");
						temp = 1;
						ch = 'X';
					} else {
						x = 0;
						y = 0;
						temp = Double.parseDouble(textField.getText());
						ch = 'X';
						textField.setText("");
					}
					textField.requestFocus();
				}
			}
		});
		btnNewButton_9_1.setForeground(Color.WHITE);
		btnNewButton_9_1.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_1.setBackground(new Color(255, 128, 64));
		btnNewButton_9_1.setBounds(20, 473, 104, 64);
		contentPane.add(btnNewButton_9_1);
		
		JButton btnNewButton_9_2 = new JButton("÷");
		btnNewButton_9_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s = e.getActionCommand();
				if (s.equals("÷")) {
					if (textField.getText().equals("")) {
						textField.setText("");
						temp = 1;
						ch = '÷';
					} else {
						x = 0;
						y = 0;
						temp = Double.parseDouble(textField.getText());
						ch = '÷';
						textField.setText("");
					}
					textField.requestFocus();
				}
			}
		});
		btnNewButton_9_2.setForeground(Color.WHITE);
		btnNewButton_9_2.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2.setBounds(144, 473, 104, 64);
		contentPane.add(btnNewButton_9_2);
		
		JButton btnNewButton_9_2_1 = new JButton("+/-");
		btnNewButton_9_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (s.equals("+/-")) {
					s = e.getActionCommand();
					if (x == 0) {
						textField.setText("-" + textField.getText());
						x = 1;
					} else {
						textField.setText(textField.getText());
					}
				}
			}
		});
		btnNewButton_9_2_1.setForeground(Color.WHITE);
		btnNewButton_9_2_1.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_1.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_1.setBounds(268, 473, 104, 64);
		contentPane.add(btnNewButton_9_2_1);
		
		JButton btnNewButton_9_2_2 = new JButton(".");
		btnNewButton_9_2_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s = e.getActionCommand();
				if (s.equals(".")) {
					if (y == 0) {
						textField.setText(textField.getText() + ".");
						y = 1;
					} else {
						textField.setText(textField.getText());
					}
				}
			}
		});
		btnNewButton_9_2_2.setForeground(Color.WHITE);
		btnNewButton_9_2_2.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_2.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_2.setBounds(383, 473, 109, 64);
		contentPane.add(btnNewButton_9_2_2);
		
		JButton btnNewButton_9_2_3 = new JButton("=");
		btnNewButton_9_2_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s = e.getActionCommand();
				if (s.equals("=")) {
					if (textField.getText().equals("")) {
						textField.setText("");
					} else {
						temp1 = Double.parseDouble(textField.getText());
						switch (ch) {
						case '+':
							result = temp + temp1;
							break;
						case '-':
							result = temp - temp1;
							break;
						case '÷':
							result = temp / temp1;
							break;
						case 'X':
							result = temp * temp1;
							break;
						}
						textField.setText("");
						textField.setText(textField.getText() + result);
						z = 1;
					}
				}
			}
		});
		btnNewButton_9_2_3.setForeground(Color.WHITE);
		btnNewButton_9_2_3.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_3.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_3.setBounds(20, 548, 104, 64);
		contentPane.add(btnNewButton_9_2_3);
		
		JButton btnNewButton_9_2_3_1 = new JButton("1/x");
		btnNewButton_9_2_3_1.setForeground(Color.WHITE);
		btnNewButton_9_2_3_1.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_3_1.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_3_1.setBounds(144, 548, 104, 64);
		contentPane.add(btnNewButton_9_2_3_1);
		
		JButton btnNewButton_9_2_3_2 = new JButton("Sqrt");
		btnNewButton_9_2_3_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
				if (s.equals("Sqrt")) {
					if (textField.getText().equals("")) {
						textField.setText("");
					} else {
						a = Math.sqrt(Double.parseDouble(textField.getText()));
						textField.setText("");
						textField.setText(textField.getText() + a);
					}
				}
			}
		});
		btnNewButton_9_2_3_2.setForeground(Color.WHITE);
		btnNewButton_9_2_3_2.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_3_2.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_3_2.setBounds(268, 548, 104, 64);
		contentPane.add(btnNewButton_9_2_3_2);
		
		JButton btnNewButton_9_2_3_3 = new JButton("log");
		btnNewButton_9_2_3_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
				if (s.equals("log")) {
					if (textField.getText().equals("")) {
						textField.setText("");
					} else {
						a = Math.log(Double.parseDouble(textField.getText()));
						textField.setText("");
						textField.setText(textField.getText() + a);
					}
				}
			}
		});
		btnNewButton_9_2_3_3.setForeground(Color.WHITE);
		btnNewButton_9_2_3_3.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_3_3.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_3_3.setBounds(383, 548, 109, 64);
		contentPane.add(btnNewButton_9_2_3_3);
		
		JButton btnNewButton_9_2_3_4 = new JButton("SIN");
		btnNewButton_9_2_3_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
				if (s.equals("SIN")) {
					if (textField.getText().equals("")) {
						textField.setText("");
					} else {
						a = Math.sin(Double.parseDouble(textField.getText()));
						textField.setText("");
						textField.setText(textField.getText() + a);
					}
				}
			}
		});
		btnNewButton_9_2_3_4.setForeground(Color.WHITE);
		btnNewButton_9_2_3_4.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_3_4.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_3_4.setBounds(20, 623, 104, 64);
		contentPane.add(btnNewButton_9_2_3_4);
		
		JButton btnNewButton_9_2_3_5 = new JButton("COS");
		btnNewButton_9_2_3_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
				if (s.equals("COS")) {
					if (textField.getText().equals("")) {
						textField.setText("");
					} else {
						a = Math.cos(Double.parseDouble(textField.getText()));
						textField.setText("");
						textField.setText(textField.getText() + a);
					}
				}
			}
		});
		btnNewButton_9_2_3_5.setForeground(Color.WHITE);
		btnNewButton_9_2_3_5.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_3_5.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_3_5.setBounds(144, 623, 104, 64);
		contentPane.add(btnNewButton_9_2_3_5);
		
		JButton btnNewButton_9_2_3_6 = new JButton("TAN");
		btnNewButton_9_2_3_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
				if (s.equals("TAN")) {
					if (textField.getText().equals("")) {
						textField.setText("");
					} else {
						a = Math.tan(Double.parseDouble(textField.getText()));
						textField.setText("");
						textField.setText(textField.getText() + a);
					}
				}
				
			}
		});
		btnNewButton_9_2_3_6.setForeground(Color.WHITE);
		btnNewButton_9_2_3_6.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_3_6.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_3_6.setBounds(268, 623, 104, 64);
		contentPane.add(btnNewButton_9_2_3_6);
		
		JButton btnNewButton_9_2_3_7 = new JButton("X^2");
		btnNewButton_9_2_3_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s = e.getActionCommand();
				if (s.equals("X^2")) {
					if (textField.getText().equals("")) {
						textField.setText("");
					} else {
						a = Math.pow(Double.parseDouble(textField.getText()), 2);
						textField.setText("");
						textField.setText(textField.getText() + a);
					}
				}
			}
		});
		btnNewButton_9_2_3_7.setForeground(Color.WHITE);
		btnNewButton_9_2_3_7.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_3_7.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_3_7.setBounds(383, 623, 109, 64);
		contentPane.add(btnNewButton_9_2_3_7);
		
		JButton btnNewButton_9_2_3_4_1 = new JButton("X^3");
		btnNewButton_9_2_3_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s = e.getActionCommand();
				if (s.equals("X^3")) {
					if (textField.getText().equals("")) {
						textField.setText("");
					} else {
						a = Math.pow(Double.parseDouble(textField.getText()), 3);
						textField.setText("");
						textField.setText(textField.getText() + a);
					}
				}
			}
		});
		btnNewButton_9_2_3_4_1.setForeground(Color.WHITE);
		btnNewButton_9_2_3_4_1.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_3_4_1.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_3_4_1.setBounds(20, 698, 104, 64);
		contentPane.add(btnNewButton_9_2_3_4_1);
		
		JButton btnNewButton_9_2_3_4_2 = new JButton("EXP");
		btnNewButton_9_2_3_4_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s = e.getActionCommand();
				if (s.equals("EXP")) {
					if (textField.getText().equals("")) {
						textField.setText("");
					} else {
						a = Math.exp(Double.parseDouble(textField.getText()));
						textField.setText("");
						textField.setText(textField.getText() + a);
					}
				}
			}
		});
		btnNewButton_9_2_3_4_2.setForeground(Color.WHITE);
		btnNewButton_9_2_3_4_2.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_3_4_2.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_3_4_2.setBounds(144, 698, 104, 64);
		contentPane.add(btnNewButton_9_2_3_4_2);
		
		JButton btnNewButton_9_2_3_4_3 = new JButton("N!");
		btnNewButton_9_2_3_4_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s = e.getActionCommand();
				
				if (s.equals("N!")) {
					if (textField.getText().equals("")) {
						textField.setText("");
					} else {
						a = fact(Double.parseDouble(textField.getText()));
						textField.setText("");
						textField.setText(textField.getText() + a);
					}
				}
				textField.requestFocus();
			
			}
		});
		btnNewButton_9_2_3_4_3.setForeground(Color.WHITE);
		btnNewButton_9_2_3_4_3.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_3_4_3.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_3_4_3.setBounds(268, 698, 104, 64);
		contentPane.add(btnNewButton_9_2_3_4_3);
		
		JButton btnNewButton_9_2_3_4_4 = new JButton("AC");
		btnNewButton_9_2_3_4_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 s = e.getActionCommand();
				if (s.equals("AC")) {
					textField.setText("");
					x = 0;
					y = 0;
					z = 0;
				}
			}
		});
		btnNewButton_9_2_3_4_4.setForeground(Color.WHITE);
		btnNewButton_9_2_3_4_4.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_9_2_3_4_4.setBackground(new Color(255, 128, 64));
		btnNewButton_9_2_3_4_4.setBounds(383, 698, 109, 64);
		contentPane.add(btnNewButton_9_2_3_4_4);
		
		
	}
	

	double fact(double x) {
		int er = 0;
		if (x < 0) {
			er = 20;
			return 0;
		}
		double i, s = 1;
		for (i = 2; i <= x; i += 1.0)
			s *= i;
		return s;
	}
}
