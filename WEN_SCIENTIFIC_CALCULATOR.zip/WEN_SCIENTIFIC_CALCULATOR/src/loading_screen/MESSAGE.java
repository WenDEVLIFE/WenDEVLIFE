package loading_screen;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;

import SCIENTIFIC.JAVA2D;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.event.ActionListener;
import java.net.URI;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class MESSAGE extends JDialog {

	private final JPanel contentPanel = new JAVA2D();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			MESSAGE dialog = new MESSAGE();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
			dialog.setModal(true);
			dialog.setLocationRelativeTo(null);
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 * @throws UnsupportedLookAndFeelException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 */
	public MESSAGE() throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\JAVA_ECLIPSE\\WEN_SCIENTIFIC_CALCULATOR\\src\\scientific-calculator.png"));
		setTitle("MESSAGE");
		MESSAGE dialog = this;
		UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		setBounds(100, 100, 450, 462);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Hello Welcome to WENDEV Scientific Calculator V1.0");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 12));
		lblNewLabel.setBounds(35, 11, 443, 59);
		contentPanel.add(lblNewLabel);
		
		JLabel lblCreatedByFrouen = new JLabel("Created by: Frouen M. Medina Jr.");
		lblCreatedByFrouen.setForeground(new Color(255, 255, 255));
		lblCreatedByFrouen.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 12));
		lblCreatedByFrouen.setBounds(10, 68, 414, 59);
		contentPanel.add(lblCreatedByFrouen);
		
		JLabel lblFollowMeOn = new JLabel("FOLLOW ME ON GITHUB & FACEBOOK");
		lblFollowMeOn.setForeground(new Color(255, 255, 255));
		lblFollowMeOn.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 12));
		lblFollowMeOn.setBounds(10, 211, 443, 59);
		contentPanel.add(lblFollowMeOn);
		
		JButton btnWendevlife = new JButton("WENDEVLIFE");
		btnWendevlife.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
	                    Desktop.getDesktop().browse(new URI("https://github.com/WenDEVLIFE"));
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
			}
		});
		btnWendevlife.setForeground(new Color(255, 255, 255));
		btnWendevlife.setFont(new Font("Verdana", Font.PLAIN, 12));
		btnWendevlife.setBackground(new Color(255, 128, 0));
		btnWendevlife.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\WEN_SCIENTIFIC_CALCULATOR\\src\\github-logo.png"));
		btnWendevlife.setBounds(10, 264, 204, 73);
		contentPanel.add(btnWendevlife);
		
		JButton btnOk = new JButton("CLOSE");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dialog.dispose();
			}
		});
		btnOk.setForeground(Color.WHITE);
		btnOk.setFont(new Font("Verdana", Font.PLAIN, 12));
		btnOk.setBackground(new Color(255, 128, 0));
		btnOk.setBounds(122, 363, 178, 48);
		contentPanel.add(btnOk);
		
		JLabel lblThisWasCreated = new JLabel("This was created for our final examination");
		lblThisWasCreated.setForeground(new Color(255, 255, 255));
		lblThisWasCreated.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 12));
		lblThisWasCreated.setBounds(10, 160, 414, 59);
		contentPanel.add(lblThisWasCreated);
		
		JLabel lblSubmittedToMary = new JLabel("Submitted to: Mary Cris Magbanua");
		lblSubmittedToMary.setForeground(new Color(255, 255, 255));
		lblSubmittedToMary.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 12));
		lblSubmittedToMary.setBounds(10, 119, 414, 59);
		contentPanel.add(lblSubmittedToMary);
		
		JButton btnFb = new JButton("FACEBOOK");
		btnFb.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\WEN_SCIENTIFIC_CALCULATOR\\src\\facebook.png"));
		btnFb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
                    Desktop.getDesktop().browse(new URI("https://www.facebook.com/profile.php?id=100008626543963"));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
			}
		});
		btnFb.setForeground(Color.WHITE);
		btnFb.setFont(new Font("Verdana", Font.PLAIN, 12));
		btnFb.setBackground(new Color(255, 128, 0));
		btnFb.setBounds(237, 264, 185, 73);
		contentPanel.add(btnFb);
	}
}
