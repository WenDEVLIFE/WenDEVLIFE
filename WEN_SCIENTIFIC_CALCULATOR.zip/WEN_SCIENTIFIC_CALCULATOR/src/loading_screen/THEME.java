package loading_screen;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class THEME extends JPanel {

    private static final long serialVersionUID = 1L;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();

        int panelWidth = getWidth();
        int panelHeight = getHeight();

     // Define the two original gradients
        GradientPaint gradient1 = new GradientPaint(1000, 0, new Color(0, 82, 212), 0, 0, new Color(67, 100, 247), true);
        GradientPaint gradient2 = new GradientPaint(1000, 0, new Color(111, 177, 252), 1000, 0, new Color(111, 177, 252));

        // Convert the colors to HSB
        float[] hsb1 = Color.RGBtoHSB(0, 82, 212, null);
        float[] hsb2 = Color.RGBtoHSB(111, 177, 252, null);

        // Interpolate between the HSB values
        float[] hsbInterpolated = new float[3];
        hsbInterpolated[0] = (hsb1[0] + hsb2[0]) / 2; // average of hue
        hsbInterpolated[1] = (hsb1[1] + hsb2[1]) / 5; // average of saturation
        hsbInterpolated[2] = (hsb1[2] + hsb2[2]) / 2; // average of brightness

        // Convert the interpolated HSB value back to RGB color
        Color interpolatedColor = new Color(Color.HSBtoRGB(hsbInterpolated[0], hsbInterpolated[1], hsbInterpolated[2]));

        // Create a new GradientPaint object with the interpolated color
        GradientPaint interpolatedGradient = new GradientPaint(1000, 0, interpolatedColor, 0, 0, interpolatedColor);

        // Use the new GradientPaint for painting
        g2.setPaint(interpolatedGradient);
        g2.fillRect(0, 0, panelWidth, panelHeight);

        g2.dispose();

    }
}
