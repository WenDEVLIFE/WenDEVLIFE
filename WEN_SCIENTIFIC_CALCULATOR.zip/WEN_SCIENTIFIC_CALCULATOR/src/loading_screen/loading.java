package loading_screen;

import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;

import SCIENTIFIC.SCI_CALCULATOR;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JProgressBar;
import javax.swing.SwingWorker;

public class loading extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loading frames = new loading();
					frames.setVisible(true);
					frames.setResizable(false);;
					frames.setLocationRelativeTo(null);
					UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws UnsupportedLookAndFeelException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 */
	public loading() throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		setUndecorated(true);
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\JAVA_ECLIPSE\\WEN_SCIENTIFIC_CALCULATOR\\src\\scientific-calculator.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 584, 486);
		contentPane = new THEME();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("WENDEV SCIENTIFIC CALCULATOR V1.0");
		lblNewLabel.setForeground(new Color(0, 64, 64));
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 23));
		lblNewLabel.setBounds(29, 206, 531, 87);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\WEN_SCIENTIFIC_CALCULATOR\\src\\scientific-calculator.png"));
		lblNewLabel_1.setBounds(238, 128, 94, 104);
		contentPane.add(lblNewLabel_1);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(36, 292, 499, 33);
		contentPane.add(progressBar);
		// Create a SwingWorker to perform the long-running task in the background
				SwingWorker<Void, Integer> worker = new SwingWorker<Void, Integer>() {
					
					@Override
					protected Void doInBackground() throws Exception {
						// Perform the long-running task here
						for (int i = 0; i <= 100; i++) {
							// Update the progress bar value and repaint it
							publish(i);
							Thread.sleep(50);
						}
						return null;
					}
					
					@Override
					protected void process(java.util.List<Integer> chunks) {
						// Update the progress bar value in the foreground thread
						progressBar.setValue(chunks.get(chunks.size() - 1));
					}
					
					@Override
					protected void done() {
						// Dispose the current frame and create and display the next frame
						dispose();
						SCI_CALCULATOR frame = null;
						try {
							frame = new SCI_CALCULATOR();
							frame.setVisible(true);
							frame.setResizable(false);;
							frame.setLocationRelativeTo(null);
							MESSAGE dialog = new MESSAGE();
							dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
							dialog.setVisible(true);
							dialog.setModal(true);
							dialog.setLocationRelativeTo(null);
						} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
								| UnsupportedLookAndFeelException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					}
				};
				
				// Start the SwingWorker
				worker.execute();
			
		
		JLabel lblLoading = new JLabel("");
		lblLoading.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\WEN_SCIENTIFIC_CALCULATOR\\src\\giphy.gif"));
		lblLoading.setForeground(new Color(0, 64, 64));
		lblLoading.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 20));
		lblLoading.setBounds(42, 346, 493, 87);
		contentPane.add(lblLoading);
	}
}
