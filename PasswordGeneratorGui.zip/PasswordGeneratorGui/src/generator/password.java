package generator;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.security.SecureRandom;  
import java.util.Collections;  
import java.util.List;  
import java.util.Random;  
import java.util.stream.Collectors;  
import java.util.stream.IntStream;  
import java.util.stream.Stream; 

public class password extends JFrame implements ActionListener {
	JLabel pass;
	JPanel sidebar;
	JTextField password;
	JButton generate;
	JButton how;
	JButton github;
	JButton facebook;
	JLabel Title;
password (){
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setLayout(null);
	
	//JButton
	how = new JButton();
	ImageIcon l = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\PasswordGeneratorGui\\src\\generator\\question.png").getImage().getScaledInstance(50,50, Image.SCALE_SMOOTH));
	how.setIcon(l);
	how.setBounds(15,180,50,50);
	how.setFocusable(false);
	how.setOpaque(false);
	how.setContentAreaFilled(false);
	how.setBorderPainted(false);
	how.addActionListener(this);
	
	facebook = new JButton();
	ImageIcon f = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\PasswordGeneratorGui\\src\\generator\\facebook.png").getImage().getScaledInstance(50,50, Image.SCALE_SMOOTH));
	facebook.setIcon(f);
	facebook.setBounds(15,100,50,50);
	facebook.setFocusable(false);
	facebook.setOpaque(false);
	facebook.setContentAreaFilled(false);
	facebook.setBorderPainted(false);
	facebook.addActionListener(this);
	
	github = new JButton();
	ImageIcon g = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\PasswordGeneratorGui\\src\\generator\\github.png").getImage().getScaledInstance(50,50, Image.SCALE_SMOOTH));
	github.setIcon(g);
	github.setBounds(15,30,50,50);
	github.setFocusable(false);
	github.setOpaque(false);
	github.setContentAreaFilled(false);
	github.setBorderPainted(false);
	github.addActionListener(this);
	
	//sidebar
	sidebar = new JPanel();
	sidebar.setBackground(new Color(255,255,255));
	sidebar.setBounds(0,0,80,500); 
	sidebar.setAlignmentX(JPanel.LEFT_ALIGNMENT);
	sidebar.setLayout(null);
	sidebar.add(how);
	sidebar.add(facebook);
	sidebar.add(github);

	
	
	Title = new JLabel("Password Generator");
	Title.setBounds(250,-150,350,400);
	Title.setFont(new Font("Sans-Serif", Font.PLAIN,35));
	Title.setForeground(new Color (255,255,255));
	//password
	pass = new JLabel("Password");
	pass.setBounds(110, -30, 300, 300);
	pass.setHorizontalAlignment(JLabel.CENTER);
	pass.setForeground(new Color (255,255,255));
	pass.setFont(new Font("Verdana", Font.PLAIN, 30));
	 password = new JTextField(15);
	//Changing JTEXTFIELD BACKGROUND
	Color color1 = Color.BLACK;
	 password.setBackground(color1);
	 password.setFont(new Font("Sans-Serif", Font.PLAIN, 30));
	 password.setForeground(new Color (0,100,0));
	 password.setBounds(340,100,300,50);
	 password.setEditable(false);
	 
	//JBUTTON
	generate = new JButton("Generate Password");
	generate.setBackground(Color.RED);
	generate.setBounds(250, 300, 250, 90);
	generate.setFont(new Font("Sans-Serif", Font.PLAIN,20));
	generate.setForeground(new Color (255,255,255));
	generate.addActionListener(this);
	
	this.setTitle("Password Generator by WenDevLife");
	this.setSize(720, 500);
	this.add(Title);
	this.add(pass);
	this.add(generate);
	this.add(password);
	this.add(sidebar);
	this.setVisible(true);
	this.setLocationRelativeTo(null);
	this.getContentPane().setBackground(new Color(24, 25, 26));
}
@Override
public void actionPerformed(ActionEvent e) {
	//Functions of buttons
	if (e.getSource()==generate) {
	    String pass = generateSecurePassword(); 
	    password.setText(pass);  
	}
	if (e.getSource()==how) {
		JOptionPane.showMessageDialog(this, "Click the generate the password button to generate",
                "Information", JOptionPane.INFORMATION_MESSAGE);
	}
	if (e.getSource()==facebook) {
		try {
			String myurl ="https://www.facebook.com/profile.php?id=100008626543963";
			java.awt.Desktop.getDesktop().browse(java.net.URI.create(myurl));
		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}
	if (e.getSource()==github) {
		try {
			String myurl ="https://github.com/WenDEVLIFE/WenDEVLIFE";
			java.awt.Desktop.getDesktop().browse(java.net.URI.create(myurl));
		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}
}
// Password Functions
public static String generateSecurePassword() {  
    
    // generate a string having 2 numbers, 2 special chars, 2 upper case letters, and 2 lower case letters  
     Stream<Character> demoPassword = Stream.concat(getRandomNumbers(2),   
             Stream.concat(getRandomSpecialChars(2),   
                     Stream.concat(getRandomAlphabets(2, true), getRandomAlphabets(2, false))));  
      
    // create a list of Char that stores all the characters, numbers, and special characters   
    List<Character> listOfChar = demoPassword.collect(Collectors.toList());  
      
    // use shuffle() method of the Collections to shuffle the list elements   
    Collections.shuffle(listOfChar);  
      
    //generate a random string(secure password) by using list stream() method and collect() method  
    String password = listOfChar.stream()  
            .collect(StringBuilder::new, StringBuilder::append, StringBuilder::append)  
            .toString();  
              
    // return RandomStringGenerator password to the main() method   
    return password;  
}  
// create getRandomSpecialChars() method that returns a Stream of special chars of the specified length  
public static Stream<Character> getRandomSpecialChars(int length) {  
      
    Stream<Character> specialCharsStream;  
      
    // create instance of SecureRandom  
    Random random = new SecureRandom();  
      
    // use ints() method of random to get IntStream of special chars of the specified length  
    IntStream specialChars = random.ints(length, 33, 45);  
    specialCharsStream =  specialChars.mapToObj(data -> (char) data);  
      
    // return stream to the main() method  
    return specialCharsStream;  
}  
  
// create getRandomNumbers() method that returns a Stream of numbers of the specified length  
public static Stream<Character> getRandomNumbers(int length) {  
      
    Stream<Character> numberStream;  
      
    // create instance of SecureRandom  
    Random random = new SecureRandom();  
      
    // use ints() method of random to get IntStream of number of the specified length  
    IntStream numberIntStream = random.ints(length, 48, 57);  
    numberStream = numberIntStream.mapToObj(data -> (char) data);  
      
    // return number stream to main() method  
    return numberStream;  
}  
  
// create getRandomAlphabets() method that returns either a stream of upper case chars or stream of lower case chars  
// of the specified length based on the boolean variable check  
public static Stream<Character> getRandomAlphabets(int length, boolean check) {  
      
    Stream<Character> lowerUpperStream;  
      
    // for lower case stream  
    if(check == true) {  
        // create instance of SecureRandom  
        Random random = new SecureRandom();  
          
        // use ints() method of random to get IntStream of lower case letters of the specified length  
        IntStream lCaseStream = random.ints(length, 'a', 'z');  
        lowerUpperStream =  lCaseStream.mapToObj(data -> (char) data);  
    }  
    // for upper case stream  
    else {  
        // create instance of SecureRandom  
        Random random = new SecureRandom();  
          
        // use ints() method of random to get IntStream of upper case letters of the specified length  
        IntStream uCaseStream = random.ints(length, 'A', 'Z');  
        lowerUpperStream =  uCaseStream.mapToObj(data -> (char) data);  
    }  
      
    // return lowerUpperStream to main() method  
    return lowerUpperStream;  
      
}  
}
