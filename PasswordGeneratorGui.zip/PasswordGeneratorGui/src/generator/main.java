package generator;

import java.awt.Image;
import java.awt.Toolkit;

public class main {
public static void main(String []args) {
	password main  = new password();
	Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\PasswordGeneratorGui\\src\\generator\\key.png");    
	main.setIconImage(icon);  
}
}
