package conversion;
import java.util.Scanner;
public class Conversion {
	public static void main(String args[]) {
		Scanner ask = new Scanner (System.in);
		Scanner num = new Scanner (System.in);
		Scanner compute = new Scanner (System.in);
		Float inch,kilometers, yard, mile;
		double meters;
		double centimeters, weight, height, BMI, foot,micrometers;
		char op =0;
		do {
		int option;
		System.out.println("------------------------------------------------------");
		System.out.println("-------------JAVA METER AND INCH CALCULATOR-----------");
		System.out.println("-----------------By Frouen M. Medina Jr---------------");
		System.out.println("------------------------------------------------------");
		System.out.println("Select From The Option");
		System.out.println("[1] Inch to Centimeters");
		System.out.println("[2] Kilometers to Meters");
		System.out.println("[3] Meters to Kilometer");
		System.out.println("[4] Centimeters to Inch");
		System.out.println("[5] BMI calculator");
		System.out.println("[6] Inch to Foot");
		System.out.println("[7] Foot to Centimeters");
		System.out.println("[8] Yard to kilomenters");
		System.out.println("[9] Foot to Centimeters");
		System.out.println("[10] Foot to Centimeters");
		option = num.nextInt();
		
		
		switch (option) {
		case 1:
			System.out.println("Enter a number in Inches\n");
			inch = compute.nextFloat();
			centimeters = inch*2.54;
			System.out.println("Centimeters Are " + centimeters);
		      System.out.println("Do you want to continue, Y/N");
              op =ask.next().charAt(0);
			break;
		case 2:
			System.out.println("Enter a Kilometer\n");
			kilometers = compute.nextFloat();
			meters = kilometers * 1000;
			System.out.println("The Meters are " + meters);
		      System.out.println("Do you want to continue, Y/N");
              op =ask.next().charAt(0);
			break;
		case 3: 
			System.out.println("Enter a Meters\n");
			meters = compute.nextFloat();
			kilometers =  (float) (meters / 1000);
			System.out.println("The Kilometers are " + meters);
		      System.out.println("Do you want to continue, Y/N");
              op =ask.next().charAt(0);
			break;
		case 4:
			System.out.println("Enter A centimeters");
			centimeters = compute.nextDouble();
			inch = (float) (centimeters / 2.54);
			System.out.println("The Inch Are " + inch);
		      System.out.println("Do you want to continue, Y/N");
              op =ask.next().charAt(0);
			break;
		case 5:
			System.out.println("Input a weight in kilogram: ");
			weight = compute.nextDouble();
			System.out.println("Input height in meters");
			height = compute.nextDouble();
			BMI = weight / (height*height);
		 System.out.print("The Body Mass Index (BMI) is " + BMI + " kg/m2");
	      System.out.println("Do you want to continue, Y/N");
          op =ask.next().charAt(0);
		 break;
		case 6:
			System.out.println("Enter a Inch");
			inch = compute.nextFloat();	
			foot = inch / 12;
			System.out.println("The Foot is" + foot);
			break;
		case 7:
			System.out.println("Enter Foot");
			foot = compute.nextFloat();
			centimeters = foot * 30.48;
			System.out.println("The Centimeters is" + foot);
			 System.out.println("Do you want to continue, Y/N");
	          op =ask.next().charAt(0);
			
			break;
		case 8:
			System.out.println("Enter Yard");
			yard = compute.nextFloat();
			kilometers = yard/1094;
			System.out.println("The Kilometers is " + yard);
			 System.out.println("Do you want to continue, Y/N");
	          op =ask.next().charAt(0);
			break;
		case 9:
			System.out.println("Enter a Mile");
			mile = compute.nextFloat();
			meters = mile * 1609.34;
			System.out.println("The Meters is " + meters);
			 System.out.println("Do you want to continue, Y/N");
	          op =ask.next().charAt(0);
			break;
		case 10:
			System.out.println("Enter Micrometers");
			micrometers = compute.nextDouble();
			meters = micrometers / 10000;
			System.out.println("The Meters is " + meters);
			 System.out.println("Do you want to continue, Y/N");
	          op =ask.next().charAt(0);
			break;
			
	    default:
	    	System.out.println("Select From The Options");
	        System.out.println("Do you want to continue, Y/N");
            op =ask.next().charAt(0);
	    	break;
			
		}
	} while(op =='Y'||op=='y'); 
    System.out.println("Close");
}
}
