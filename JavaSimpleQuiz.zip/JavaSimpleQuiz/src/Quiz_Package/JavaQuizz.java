package Quiz_Package;
import java.io.FileWriter;
import java.io.IOException;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;    
import java.util.Scanner;
public class JavaQuizz {
	static String name;
	static Scanner alphabetics = new Scanner(System.in);
	static int score=0;
	static int mistake=0;
	// number of questions
	static int n[] = {1,2,3,4,5};
	// to read the users answer
	static char answer;
	static char alphabets[] = {'a','b','c','d'};
	// Ask the user to put a name
	public static void Myname(){
		Scanner scanner = new Scanner (System.in);
		
		System.out.println("Enter Your Name:");
	   name = scanner.nextLine();
		
		
	}
	public static void History_Class(){
		
		System.out.println("--------------------------------------------------------");
		System.out.println("\t\tGoodluck Answering All 5 Questions");
		System.out.println("--------------------------------------------------------");
		System.out.println("");
		System.out.println(n[0]+" What Country is the biggest of Landmass?");
		System.out.println(alphabets[0]+" Russia");
		System.out.println(alphabets[1]+" China");
		System.out.println(alphabets[2]+" Usa");
		System.out.println(alphabets[3]+" America");
		answer = alphabetics.next().charAt(0);
		if (answer=='a') {
			System.out.println("You are Correct");
			System.out.println("");
			score++;
			
		} 
		else {
			System.out.println("You are Wrong");
			System.out.println("");
			mistake++;
			
		}
		System.out.println(n[1]+" When World War 2 Started?");
		System.out.println(alphabets[0]+" August 08, 1945");
		System.out.println(alphabets[1]+" July 19, 1943");
		System.out.println(alphabets[2]+" September 1, 1939");
		System.out.println(alphabets[3]+" December 12, 1938");
		answer = alphabetics.next().charAt(0);
		if (answer=='c') {
			System.out.println("You are Correct");
			System.out.println("");
			score++;
			
		} 
		else {
			System.out.println("You are Wrong");
			System.out.println("");
			mistake++;
			
		}
		System.out.println(n[2]+" What Date Russia Civil War Happened?");
		System.out.println(alphabets[0]+" August 08, 1945");
		System.out.println(alphabets[1]+" July 19, 1943");
		System.out.println(alphabets[2]+" September 1, 1939");
		System.out.println(alphabets[3]+" November 7, 1917 ");
		answer = alphabetics.next().charAt(0);
		if (answer=='d') {
			System.out.println("You are Correct");
			System.out.println("");
			score++;
			
		} 
		else {
			System.out.println("You are Wrong");
			System.out.println("");
			mistake++;
			
		}
		System.out.println(n[3]+" What Date Coldwar Started and Ended?");
		System.out.println(alphabets[0]+" August 08, 1945 - December 10, 1984");
		System.out.println(alphabets[1]+" July 19, 1943 - August 29, 1945");
		System.out.println(alphabets[2]+" March 12, 1947 – December 26, 1991");
		System.out.println(alphabets[3]+" November 7, 1917 - August 08, 1934 ");
		answer = alphabetics.next().charAt(0);
		if (answer=='c') {
			System.out.println("You are Correct");
			System.out.println("");
			score++;
			
		} 
		else {
			System.out.println("You are Wrong");
			System.out.println("");
			mistake++;
			
		}
		System.out.println(n[4]+" What Date Pangea Exist?");
		System.out.println(alphabets[0]+" about 300-200 million years ago");
		System.out.println(alphabets[1]+" about 600-900 million years ago");
		System.out.println(alphabets[2]+" about 700-960 million years ago – December 26, 1991");
		System.out.println(alphabets[3]+" about 760-990 million years ago – December 26, 1991 ");
		answer = alphabetics.next().charAt(0);
		if (answer=='a') {
			System.out.println("You are Correct");
			System.out.println("");
			score++;
			
		} 
		else {
			System.out.println("You are Wrong");
			System.out.println("");
			mistake++;
			
		}
		System.out.println("--------------------------------------------------------");
		System.out.println("\t\tYou Score:"+score);
		System.out.println("\t\tYour Mistake:"+mistake);
		System.out.println("--------------------------------------------------------");
		
		
	}
public static void Geopolitics_Class(){
	System.out.println("--------------------------------------------------------");
	System.out.println("\t\tGoodluck Answering All 5 Questions");
	System.out.println("--------------------------------------------------------");
	System.out.println("");
	System.out.println(n[0]+" Why China Want South China Sea?");
	System.out.println(alphabets[0]+" for Military Strategic position, trade route, and oil");
	System.out.println(alphabets[1]+" for tourism");
	System.out.println(alphabets[2]+" for Resources and minerals");
	System.out.println(alphabets[3]+" for business");
	answer = alphabetics.next().charAt(0);
	if (answer=='a') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println(n[1]+" Why Russia Invaded Ukraine?");
	System.out.println(alphabets[0]+" Restoring USSR ");
	System.out.println(alphabets[1]+" Threat to Russia National Security due to western influence");
	System.out.println(alphabets[2]+" Puppet them");
	System.out.println(alphabets[3]+" Want to join NATO");
	answer = alphabetics.next().charAt(0);
	if (answer=='b') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println(n[2]+" Why Nato won't allow ukraine to join in nato?");
	System.out.println(alphabets[0]+" Avoid tensions with russia");
	System.out.println(alphabets[1]+" Russia will attack them");
	System.out.println(alphabets[2]+" They wont allow nation to join in nato during its wartime");
	System.out.println(alphabets[3]+" none of the above ");
	answer = alphabetics.next().charAt(0);
	if (answer=='c') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println(n[3]+" Why the liberal party lost the election in Ph on May 09, 2022?");
	System.out.println(alphabets[0]+" Destroying enemys image and their political party is broken due to aquinos failure in their reforms from 2011-2016");
	System.out.println(alphabets[1]+" lack of voters");
	System.out.println(alphabets[2]+" Because of their supporters");
	System.out.println(alphabets[3]+" Because of lack of support of the people in the Philippines ");
	answer = alphabetics.next().charAt(0);
	if (answer=='d') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println(n[4]+" Why Philippines is still 3rd country?");
	System.out.println(alphabets[0]+" lack of political reforms, economic reforms and etc");
	System.out.println(alphabets[1]+" lack of rights");
	System.out.println(alphabets[2]+" lack of destroying the corruption");
	System.out.println(alphabets[3]+" all of the above");
	answer = alphabetics.next().charAt(0);
	if (answer=='a') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println("--------------------------------------------------------");
	System.out.println("\t\tYou Score:"+score);
	System.out.println("\t\tYour Mistake:"+mistake);
	System.out.println("--------------------------------------------------------");
		
		
	}
public static void Technology_Class(){
	System.out.println("--------------------------------------------------------");
	System.out.println("\t\tGoodluck Answering All 5 Questions");
	System.out.println("--------------------------------------------------------");
	System.out.println("");
	System.out.println(n[0]+" Who created Java?");
	System.out.println(alphabets[0]+" James Gosling");
	System.out.println(alphabets[1]+" Elon Musk");
	System.out.println(alphabets[2]+" Jezz bezzoz");
	System.out.println(alphabets[3]+" Bill Gates");
	answer = alphabetics.next().charAt(0);
	if (answer=='a') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println(n[1]+" What year python created?");
	System.out.println(alphabets[0]+" January 10, 1990 ");
	System.out.println(alphabets[1]+" August 05, 1995");
	System.out.println(alphabets[2]+" September 12, 1991");
	System.out.println(alphabets[3]+" february 20, 1991");
	answer = alphabetics.next().charAt(0);
	if (answer=='d') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println(n[2]+" What is SQL stand for?");
	System.out.println(alphabets[0]+" Structured Query Language");
	System.out.println(alphabets[1]+" Structures Queried Language");
	System.out.println(alphabets[2]+" Structured Query Lang");
	System.out.println(alphabets[3]+" none of the above ");
	answer = alphabetics.next().charAt(0);
	if (answer=='a') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println(n[3]+" Why DBMS is used for?");
	System.out.println(alphabets[0]+" saves information");
	System.out.println(alphabets[1]+" delete data and save");
	System.out.println(alphabets[2]+" serves as an interface between an end-user and a database, allowing users to create, read, update, and delete data in the database.");
	System.out.println(alphabets[3]+" all of the above ");
	answer = alphabetics.next().charAt(0);
	if (answer=='c') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println(n[4]+" Will Ai takeover the world?");
	System.out.println(alphabets[0]+" I dont know");
	System.out.println(alphabets[1]+" we will see them someday");
	System.out.println(alphabets[2]+" maybe soon");
	System.out.println(alphabets[3]+" none of the above");
	answer = alphabetics.next().charAt(0);
	if (answer=='d') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println("--------------------------------------------------------");
	System.out.println("\t\tYou Score:"+score);
	System.out.println("\t\tYour Mistake:"+mistake);
	System.out.println("--------------------------------------------------------");
		
		
}
	
	

public static void ICT_Class(){
	System.out.println("--------------------------------------------------------");
	System.out.println("\t\tGoodluck Answering All 5 Questions");
	System.out.println("--------------------------------------------------------");
	System.out.println("");
	System.out.println(n[0]+" RAM stands for?");
	System.out.println(alphabets[0]+" Random Annex Memory");
	System.out.println(alphabets[1]+" Random Acession Memorization");
	System.out.println(alphabets[2]+" Read Access Memory");
	System.out.println(alphabets[3]+" Random Access Memory");
	answer = alphabetics.next().charAt(0);
	if (answer=='d') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println(n[1]+" Its a hardware that stores Data even its turned off?");
	System.out.println(alphabets[0]+" Ram ");
	System.out.println(alphabets[1]+" ROM");
	System.out.println(alphabets[2]+" Primary Memory");
	System.out.println(alphabets[3]+" Secondary Memory");
	answer = alphabetics.next().charAt(0);
	if (answer=='c') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println(n[2]+" its a cable that transmitted light and internet thru fiber?");
	System.out.println(alphabets[0]+" Fiber Cable");
	System.out.println(alphabets[1]+" Copper Cable");
	System.out.println(alphabets[2]+" Lan Cable");
	System.out.println(alphabets[3]+" RJ45 ");
	answer = alphabetics.next().charAt(0);
	if (answer=='a') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println(n[3]+" which is not part of input devices?");
	System.out.println(alphabets[0]+" keyboard");
	System.out.println(alphabets[1]+" mouse");
	System.out.println(alphabets[2]+" Plotters");
	System.out.println(alphabets[3]+" all of the above ");
	answer = alphabetics.next().charAt(0);
	if (answer=='c') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println(n[4]+" Why hardware still uprgrading?");
	System.out.println(alphabets[0]+" Because people want innovation and new");
	System.out.println(alphabets[1]+" don't want to stick to old");
	System.out.println(alphabets[2]+" Yes because we want new");
	System.out.println(alphabets[3]+" none of the above");
	answer = alphabetics.next().charAt(0);
	if (answer=='a') {
		System.out.println("You are Correct");
		System.out.println("");
		score++;
		
	} 
	else {
		System.out.println("You are Wrong");
		System.out.println("");
		mistake++;
		
	}
	System.out.println("--------------------------------------------------------");
	System.out.println("\t\tYou Score:"+score);
	System.out.println("\t\tYour Mistake:"+mistake);
	System.out.println("--------------------------------------------------------");
		
		
}
	
public static void main(String []args) {
	Scanner num = new Scanner (System.in);
	int said=0;
    int yes1;
	Scanner says= new Scanner(System.in);
	Scanner write = new Scanner (System.in);
	Scanner write2 = new Scanner (System.in);
	 Myname();
	do {
      //Simple GUI1
	System.out.println("--------------------------------------------------------");
	System.out.println("\t\t Java Simple Quiz Program V1.0");
	//print the local date and time
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
	LocalDateTime now = LocalDateTime.now();  
    System.out.println("\t\t\t"+dtf.format(now));  
	System.out.println("--------------------------------------------------------");
	System.out.println("Select to Start");
	//select array 1
	String Select[] = {"[1] Start the Quiz","[2] Exit"};
	// for Loop
	for (String i: Select){
		System.out.print(i+ "\n");
	}
	int sel = num.nextInt();
	switch (sel) {
	case 1:
		//Simple GUI2
		System.out.println("--------------------------------------------------------");
		System.out.println("\t\tSelect a Topic to Proceeed");
		System.out.println("--------------------------------------------------------");
		//select array2
		String Select1[] = {"[1] History","[2] Geopolitics","[3] Technology related topic like IT,CS,COMPUTER ENGINEER,and IS","[4] ICT Topics","[5] Exit"};
		for (String i: Select1) {
			//PRINT SELECT2 ARRAY
			System.out.print(i+ "\n");
		}
		int sel2 =num.nextInt();
		switch (sel2) {
		case 1:
			History_Class();
			//ask the user to print the result
			System.out.println("Do you want to Save your Result? types 1 to yes or 2 to no");
			yes1=says.nextInt();
		if (yes1==1)
		{
			//print file io;
				try {
				   System.out.println("Enter a FileNamme Example: Filename.txt");
				      String written1 = write2.nextLine();
				      FileWriter myWriter = new FileWriter(written1);
				      myWriter.write("------------------------------------------------------------------------------------\n");
				      myWriter.write("\t\tHistory Class Quiz Score\n");
				      myWriter.write("Name:"+ name+ "\n" + "Your Score:" + score + "\n" +  "Your Mistake:" + mistake + "\n");
				      myWriter.write("------------------------------------------------------------------------------------");
				      myWriter.close();
				      
				      System.out.println("Successfully wrote to the file.");
				      System.out.println("Are you sure to exit?, type any key to exit and press 1 to continue");
					  said = num.nextInt();
				} catch (IOException e) {
				      System.out.println("An error occurred.");
				      e.printStackTrace();
			}	
				}
		
			else if (yes1==2) {
				System.out.println("Are you sure to exit?, type any key to exit and press 1 to continue");
				said = num.nextInt();
				}

			break;
		case 2:
			Geopolitics_Class();
			//ask the user to print the result
			System.out.println("Do you want to Save your Result? types 1 to yes or 2 to no");
			yes1=says.nextInt();
		if (yes1==1){
			//print file io;
				try {
				   System.out.println("Enter a FileNamme Example: Filename.txt");
				      String written1 = write2.nextLine();
				      FileWriter myWriter = new FileWriter(written1);
				      myWriter.write("------------------------------------------------------------------------------------\n");
				      myWriter.write("\t\tICT Class Quiz Score\n");
				      myWriter.write("Name:"+ name+ "\n" + "Your Score:" + score + "\n" +  "Your Mistake:" + mistake + "\n");
				      myWriter.write("------------------------------------------------------------------------------------");
				      myWriter.close();
				      System.out.println("Successfully wrote to the file.");
				      System.out.println("Are you sure to exit?, type any key to exit and press 1 to continue");
					  said = num.nextInt();
					  } catch (IOException e) {
				      System.out.println("An error occurred.");
				      e.printStackTrace();
				      }	
				}
		
			else if (yes1==2) {
				System.out.println("Are you sure to exit?, type any key to exit and press 1 to continue");
				said = num.nextInt();
				}
			break;
		case 3:
			Technology_Class();
			//ask the user to print the result
			System.out.println("Do you want to Save your Result? types 1 to yes or 2 to no");
			yes1=says.nextInt();
		if (yes1==1)
		{
			//print using file io;
				try {
				   System.out.println("Enter a FileNamme Example: Filename.txt");
				      String written1 = write2.nextLine();
				      FileWriter myWriter = new FileWriter(written1);
				      myWriter.write("------------------------------------------------------------------------------------\n");
				      myWriter.write("\t\tTechnology Class Quiz Score\n");
				      myWriter.write("Name:"+ name+ "\n" + "Your Score:" + score + "\n" +  "Your Mistake:" + mistake + "\n");
				      myWriter.write("------------------------------------------------------------------------------------");
				      myWriter.close();
				      System.out.println("Successfully wrote to the file.");
				      System.out.println("Are you sure to exit?, type any key to exit and press 1 to continue");
					  said = num.nextInt();
				} catch (IOException e) {
				      System.out.println("An error occurred.");
				      e.printStackTrace();
			}	
				}
		
			else if (yes1==2) {
				System.out.println("Are you sure to exit?, type any key to exit and press 1 to continue");
				said = num.nextInt();
				}
			break;
		case 4:
			ICT_Class();
			//ask the user to print the result
			System.out.println("Do you want to Save your Result? types 1 to yes or 2 to no");
			yes1=says.nextInt();
		if (yes1==1)
		{
			//print the result using file io;
				try {
				   System.out.println("Enter a FileNamme Example: Filename.txt");
				      String written1 = write2.nextLine();
				      FileWriter myWriter = new FileWriter(written1);
				      myWriter.write("------------------------------------------------------------------------------------\n");
				      myWriter.write("\t\tICT Class Quiz Score\n");
				      myWriter.write("Name:"+ name+ "\n" + "Your Score:" + score + "\n" +  "Your Mistake:" + mistake + "\n");
				      myWriter.write("------------------------------------------------------------------------------------");
				      myWriter.close();
				      System.out.println("Successfully wrote to the file.");
				      System.out.println("Are you sure to exit?, type any key to exit and press 1 to continue");
					  said = num.nextInt();
				} catch (IOException e) {
				      System.out.println("An error occurred.");
				      e.printStackTrace();
			}	
				}
		
			else if (yes1==2) {
				System.out.println("Are you sure to exit?, type any key to exit and press 1 to continue");
				said = num.nextInt();
				}
			break;
		case 5:
			System.out.println("Are you sure to exit?, type any number to exit and press 1 to continue");
			said = num.nextInt();
			break;
		default:
			System.out.println("Program Successfully Terminated!");
			break;
		}
			
		break;
	case 2:
		//Ask the user to continue or Not
		System.out.println("Are you sure to exit?, type any number to exit and press 1 to continue");
		said = num.nextInt();
		break;
	}

	
		
		
		
		//if the user type 1 the program loop to run
	}while(said==1);
	System.out.println("Close");
}
}
