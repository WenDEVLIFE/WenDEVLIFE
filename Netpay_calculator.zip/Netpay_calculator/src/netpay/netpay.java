package netpay;

import java.util.Scanner;

public class netpay {
	 public static void main(String args[]) {
		 double Grosspayment, Netpay, Netpay2;
		 int ratehour, totalhour, totalovertime;
		 Scanner Employee_Name = new Scanner (System.in);
		 Scanner compute = new Scanner (System.in);
		 
		 System.out.println("Enter Your Name");
		 String Name =Employee_Name.nextLine();
		 System.out.println("Enter your Rate/hour");
		 ratehour = compute.nextInt();
		 System.out.println("Enter your Total Hours");
		 totalhour = compute.nextInt();
		 System.out.println("Enter your Total Overtime Hours");
		 totalovertime = compute.nextInt();
		
		 Grosspayment =(totalhour*ratehour) + ((ratehour*20) * totalovertime);
		 
		 if (Grosspayment>=10000.00) {
			 Netpay = (Grosspayment*12)/100;
			 Netpay2 = Grosspayment - Netpay;
			 System.out.println("Employee Name " + Name);
			 System.out.println("Your Rate/Hour is " + ratehour);
			 System.out.println("Your Total Hours is " + totalhour);
			 System.out.println("Your Total Hours is " + totalovertime);
			 System.out.println("Your Grosspay is " + Grosspayment);
			 System.out.println("Your Netpay is ");
			 System.out.println(Netpay2);
		 } else {
			 System.out.println("Employee Name " + Name);
			 System.out.println("Your Rate/Hour is " + ratehour);
			 System.out.println("Your Total Hours is " + totalhour);
			 System.out.println("Your Total Hours is " + totalovertime);
			 System.out.println("The Grosspay are not deducted");
			 System.out.println(Grosspayment);
		 }
	 }
}
