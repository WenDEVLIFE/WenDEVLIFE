package JavaEDMS;

import java.util.Scanner;
public class JavaEdmsSimple
{ 
 public static void main(String args[]) { 
 char op =0;
     Scanner ask = new Scanner (System.in);
      System.out.println("=-=-=-=--=-=-=-=--=-=-=-=-=-=--=-=-=");
      System.out.println("=-=-=-=-=--=-Login-=-=-=-=-=-=-=-=-=");
      System.out.println("=-=-=-=--=-=-=-=--=-=-=-=-=-=--=-=-=");
      String information = ask.nextLine();
      System.out.println("=-=-=-=--=-=-=-=--=-=-=-=-=-=--=-=-=");
      System.out.println("=-=-=-=-=--=-Password-=-=-=-=-=-=-=-");
      System.out.println("=-=-=-=--=-=-=-=--=-=-=-=-=-=--=-=-=");
      String information2 = ask.nextLine();  
    do
 {
      if (information.equals("Wen5677") && information2.equals("watapam2x")) {
          System.out.println("Welcome User Wen5677");
          System.out.println("Select an Option");
          System.out.println("[1.] Upload a File");
          System.out.println("[2.] Instruction");
          System.out.println("[3.] Quit");
          int select = ask.nextInt();
          switch(select) {
              case 1: 
                  Scanner file = new Scanner (System.in);
                  System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
                  System.out.println("=-=-=-=File=Section=-=-=-=-=-=-=-");
                  System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
                  System.out.println("=-=-=-=Upload=a=File=-=-=-=-=-=-=");
                  System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
                  System.out.println("=-=-=-=Enter=The=Filename=-=-=-=-");
                  System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n");
                  String filename = file.nextLine();
                  System.out.println("The Filename " + filename + "has successfully uploaded ");
                  System.out.println("Do you wish to perform another operation, YES/NO");
                  op =ask.next().charAt(0);
                  break;
                case 2:
                  System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
                  System.out.println("=-=-=-=How=To=Use=-=-=-=-=-=-=-=-");
                  System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
                  System.out.println("[1.]Select An Option");
                  System.out.println("[2.]Select Upload a file");
                  System.out.println("[3.]Create a filename");
                  System.out.println("[4.]Done You have successfully upload your files.");
                  break;
                  default:
                      System.out.println("Are you want to quit?");
                      System.out.println("Do you want to continue, Y/N");
              op =ask.next().charAt(0);
              break;
          }
          
          
      } else if  (information.equals("GlenXBanate") && information2.equals("girl&boybestfriendrule")) {
        System.out.println("Welcome User GlenXBanate");
          System.out.println("Select an Option");
          System.out.println("[1.] Upload a File");
          System.out.println("[2.] Instruction");
          System.out.println("[3.] Quit");
          int select = ask.nextInt();
          switch(select) {
              case 1: 
                  Scanner file = new Scanner (System.in);
                  System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
                  System.out.println("=-=-=-=File=Section=-=-=-=-=-=-=-");
                  System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
                  System.out.println("=-=-=-=Upload=a=File=-=-=-=-=-=-=");
                  System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
                  System.out.println("=-=-=-=Enter=The=Filename=-=-=-=-");
                  System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n");
                  String filename = file.nextLine();
                  System.out.println("The Filename " + filename + "has successfully uploaded ");
                  System.out.println("Do you wish to perform another operation, YES/NO");
                  op =ask.next().charAt(0);
                  break;
                case 2:
                  System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
                  System.out.println("=-=-=-=How=To=Use=-=-=-=-=-=-=-=-");
                  System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
                  System.out.println("[1.]Select An Option");
                  System.out.println("[2.]Select Upload a file");
                  System.out.println("[3.]Create a filename");
                  System.out.println("[4.]Done You have successfully upload your files.");
                  break;
                  default:
                      System.out.println("Are you want to quit?");
                      System.out.println("Do you want to continue, Y/N");
              op =ask.next().charAt(0);
              break;
            }

      } else {
          System.out.println("Credentials are Incorrect");
          System.out.println("Do you want to continue, YES/NO");
              op =ask.next().charAt(0);
              continue;
      }
   } while(op =='Y'||op=='y'); 
    System.out.println("Close");
}
}

    


