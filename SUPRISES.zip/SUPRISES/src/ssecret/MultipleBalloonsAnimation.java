package ssecret;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MultipleBalloonsAnimation extends JFrame {
    private static final int FRAME_WIDTH = 800;
    private static final int FRAME_HEIGHT = 600;
    private static final int BALLOON_WIDTH = 40;
    private static final int BALLOON_HEIGHT = 60;

    private List<Balloon> balloons;

    public MultipleBalloonsAnimation() {
        setTitle("Multiple Balloons Animation");
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        balloons = new ArrayList<>();

        Random random = new Random();

        // Create 10 random balloons with initial positions and speeds
        for (int i = 0; i < 10; i++) {
            int x = random.nextInt(FRAME_WIDTH - BALLOON_WIDTH);
            int y = random.nextInt(FRAME_HEIGHT - BALLOON_HEIGHT);
            int speed = random.nextInt(3) + 1;

            Balloon balloon = new Balloon(x, y, speed);
            balloons.add(balloon);
        }

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new AnimationTask(), 0, 10); // Schedule the animation task

        setVisible(true);
    }

    @Override
    public void paint(Graphics g) {
        Image image = createImage(getWidth(), getHeight());
        Graphics buffer = image.getGraphics();
        drawBalloons(buffer);
        g.drawImage(image, 0, 0, this);
    }

    private void drawBalloons(Graphics g) {
        for (Balloon balloon : balloons) {
            g.setColor(balloon.getColor());
            g.fillOval(balloon.getX(), balloon.getY(), BALLOON_WIDTH, BALLOON_HEIGHT);
        }
    }

    class AnimationTask extends TimerTask {
        @Override
        public void run() {
            // Update the position of each balloon
            for (Balloon balloon : balloons) {
                balloon.updatePosition(FRAME_WIDTH, FRAME_HEIGHT);
            }

            // Repaint the frame to reflect the updated positions
            repaint();
        }
    }

    class Balloon {
        private int x, y; // Current position of the balloon
        private int speed; // Speed of vertical movement
        private Color color; // Color of the balloon

        public Balloon(int x, int y, int speed) {
            this.x = x;
            this.y = y;
            this.speed = speed;

            Random random = new Random();
            int r = random.nextInt(256);
            int g = random.nextInt(256);
            int b = random.nextInt(256);
            color = new Color(r, g, b);
        }

        public int getX() {
            return x;
        }

        public int getY() {
            return y;
        }

        public Color getColor() {
            return color;
        }

        public void updatePosition(int frameWidth, int frameHeight) {
            y -= speed;

            // If the balloon goes above the top of the frame, reset its position to the bottom
            if (y < -BALLOON_HEIGHT) {
                y = frameHeight;
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MultipleBalloonsAnimation());
    }
}