package ssecret;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatSolarizedDarkContrastIJTheme;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.Timer;

public class mainframe extends JFrame {

	/**
	 * 
	 */
	 private static String[] words = {
			 "test",
			 "I just want you to know that",
			 "Thank you for being here with me", 
			 "Its been 3 years and counting",
			 "Nata nagkaila",
			 "Even tho unsahay dili ka ",
			 "maka reply diretso",
			 "I still always remember that ",
			 "You are always there for me",
			 "even tho i feel like ignored ",
			 "or because you are annoyed at me",
			 "I still waiting at your reply",
			 "because i care alot at you",
			 "I really like you so much",
			 "Not because of your looks",
			 "I like you,",
			 "Because of who you are right now",
			 "Your special to me",
			 "I know that im just your friend",
			 "But i really admired you alot",
			 "Unta dili ka malain",
			 "And lastly you're important",
			 
			 "I have a present click the button",
			 };
	    private static int wordIndex = 0;
	private static final long serialVersionUID = 1L;
	private int click=0;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		 try {
		        FlatSolarizedDarkContrastIJTheme.setup();
		    } catch (Exception e) {
		    	
		        e.printStackTrace();
		        
		    }
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//create a frame
					mainframe frame = new mainframe();
					frame.setVisible(true);
					frame.setResizable(false);
					frame.setSize(1024,648);
					
					
				} catch (Exception e) {
					
					e.printStackTrace();
					
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public mainframe() {
		mainframe frame = this;
		// to enable exit
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 567);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		 //labels
		JLabel lblNewLabel = new JLabel("Hi");
		lblNewLabel.setBounds(361, 151, 637, 104);
		lblNewLabel.setFont(new Font("Verdana", Font.PLAIN, 35));
		
		JLabel lblClicks = new JLabel("CLICKS:0");
		lblClicks.setFont(new Font("Verdana", Font.PLAIN, 35));
		lblClicks.setBounds(31, 413, 637, 104);
		contentPane.add(lblClicks);
		
		//buttons
		JButton btnClickForSuprise = new JButton("CLICK FOR SUPRISE");
		btnClickForSuprise.setBounds(311, 279, 265, 78);
		contentPane.add(btnClickForSuprise);
		btnClickForSuprise.setVisible(false);
		btnClickForSuprise.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  SwingUtilities.invokeLater(HBD_JUL::new);
				  frame.dispose();
			}
	});
		
		JButton btnNewButton = new JButton("CLICK ME");
		btnNewButton.setBounds(311, 279, 265, 78);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				wordIndex = (wordIndex + 1) % words.length;
				lblNewLabel.setText(words[wordIndex]);
				lblNewLabel.setBounds(100, 178, 528, 35);
				lblNewLabel.setFont(new Font("Verdana", Font.PLAIN, 25));
			
				click++;
				if(click>=1) {
					lblClicks.setText("Clicks:"+click);
					lblNewLabel.setBounds(250, 178, 528, 35);
					
				}
				if (click==22) {
					btnClickForSuprise.setVisible(true);
					btnNewButton.setVisible(false);
				}
				
				

			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnNewButton);
		contentPane.add(lblNewLabel);
		
		
		
		JLabel lblClickTimes = new JLabel("CLICK 22 TIMES");
		lblClickTimes.setFont(new Font("Verdana", Font.PLAIN, 35));
		lblClickTimes.setBounds(600, 413, 637, 104);
		contentPane.add(lblClickTimes);
		
	
		
		// timer so that the animation will work well
		 Timer timer = new Timer(500, new ActionListener() {
			 
			 // escapulation
	            private int colorIndex = 0;
	            
	            // arrays and colors
	            private Color[] colors = {Color.RED, Color.GREEN, Color.BLUE ,Color.PINK};

	            @Override
	            //set the color every second
	            public void actionPerformed(ActionEvent e) {
	            	lblNewLabel.setForeground(colors[colorIndex]);
	                colorIndex = (colorIndex + 1) % colors.length;
	            }
	        });
		 // timer start
	        timer.start();

		
		
	}
}
