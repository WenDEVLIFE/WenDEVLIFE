package ssecret;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;

import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatSolarizedDarkContrastIJTheme;



import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class HBD_JUL extends JFrame {
    private static final int FRAME_WIDTH = 800;
    private static final int FRAME_HEIGHT = 600;
    private static final int BALLOON_WIDTH = 40;
    private static final int BALLOON_HEIGHT = 60;
    private static final int TAIL_LENGTH = 50;
    private static final long serialVersionUID = 1L;
	private static Clip clip;
	   void playMusic() {
		try {
			AudioInputStream audioIn = AudioSystem.getAudioInputStream(new File("src/hbd.wav"));
			clip = AudioSystem.getClip();
			clip.open(audioIn);
			clip.loop(Clip.LOOP_CONTINUOUSLY);
			clip.start();
		} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
			e.printStackTrace();
		}
	}
    private List<Balloon> balloons;

    public HBD_JUL() {
    	// call the music static void
    	playMusic();
    	
    	
        setTitle("HAPPI BORTHDAY JHULLICAKES");
        setSize(800, 645);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Create a JLayeredPane to hold the components
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setLayout(null); // Use null layout manager

        // Create the balloons and add them to the layered pane
        balloons = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            int x = random.nextInt(FRAME_WIDTH - BALLOON_WIDTH);
            int y = random.nextInt(FRAME_HEIGHT - BALLOON_HEIGHT);
            int speed = random.nextInt(3) + 1;

            Balloon balloon = new Balloon(x, y, speed);
            balloons.add(balloon);
            layeredPane.add(balloon, JLayeredPane.DEFAULT_LAYER);
        }

        // Create the JLabel and add it to the layered pane
        JLabel lblHappyBirthdayJhullana = new JLabel("HAPPY BIRTHDAY JHULLANA");
        lblHappyBirthdayJhullana.setFont(new Font("Verdana", Font.PLAIN, 35));
        layeredPane.add(lblHappyBirthdayJhullana, JLayeredPane.PALETTE_LAYER);
        lblHappyBirthdayJhullana.setBounds(114, 109, 576, 50); // Set the bounds of the label
        
      

        setContentPane(layeredPane); // Set the layered pane as the content pane
        setVisible(true);

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new AnimationTask(), 0, 10); // Schedule the animation task
        
        
        Timer labelTimer = new Timer();
        labelTimer.scheduleAtFixedRate(new LabelAnimationTask(lblHappyBirthdayJhullana), 0, 500); // Schedule the label animation task
        
        JLabel lblNewLabel = new JLabel("New label");
        lblNewLabel.setIcon(new ImageIcon("src\\photo.jpg"));
        lblNewLabel.setBounds(162, 170, 372, 307);
        lblNewLabel.setVisible(false);
        layeredPane.add(lblNewLabel);
        
        JLabel lblYouGotA = new JLabel("YOU GOT A CAKE!");
        lblYouGotA.setFont(new Font("Verdana", Font.PLAIN, 35));
        lblYouGotA.setBounds(222, 528, 576, 50);
        lblYouGotA .setVisible(false);
        layeredPane.add(lblYouGotA);
        
        JButton btnNewButton = new JButton("Click for suprises");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		lblNewLabel.setVisible(true);
        		 lblYouGotA .setVisible(true);
        		 btnNewButton.setBounds(273, 480, 230, 50);
        		 try {
        				AudioInputStream audioIn = AudioSystem.getAudioInputStream(new File("src/yehey.wav"));
        				clip = AudioSystem.getClip();
        				clip.open(audioIn);
        				
        				clip.start();
        			} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e1) {
        				e1.printStackTrace();
        			}
        	}
        });
        btnNewButton.setBounds(273, 294, 230, 50);
        layeredPane.add(btnNewButton);
      
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        drawBalloons(g);
    }

    private void drawBalloons(Graphics g) {
        for (Balloon balloon : balloons) {
            g.setColor(balloon.getColor());
            g.fillOval(balloon.getX(), balloon.getY(), BALLOON_WIDTH, BALLOON_HEIGHT);

            // Draw the tail
            int tailX = balloon.getX() + (BALLOON_WIDTH / 2);
            int tailY = balloon.getY() + BALLOON_HEIGHT;
            for (int i = 0; i < TAIL_LENGTH; i++) {
                g.drawLine(tailX, tailY + i, tailX, tailY + i + 1);
            }
        }
    }

    class AnimationTask extends TimerTask {
        @Override
        public void run() {
            // Update the position of each balloon
            for (Balloon balloon : balloons) {
                balloon.updatePosition(FRAME_WIDTH, FRAME_HEIGHT);
            }

            // Repaint the frame to reflect the updated positions
            repaint();
        }
    }

    class Balloon extends JComponent {
        /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private int x, y; // Current position of the balloon
        private int speed; // Speed of vertical movement
        private Color color; // Color of the balloon

        public Balloon(int x, int y, int speed) {
            this.x = x;
            this.y = y;
            this.speed = speed;

            Random random = new Random();
            int r = random.nextInt(256);
            int g = random.nextInt(256);
            int b = random.nextInt(256);
            color = new Color(r, g, b);
        }

        public int getX() {
            return x;
        }

        public int getY() {
            return y;
        }

        public Color getColor() {
            return color;
        }

        public void updatePosition(int frameWidth, int frameHeight) {
            y -= speed;

            // If the balloon goes above the top of the frame, reset its position to the bottom
            if (y < -BALLOON_HEIGHT) {
                y = frameHeight;
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            // Draw the balloon
            g.setColor(color);
            g.fillOval(0, 0, BALLOON_WIDTH, BALLOON_HEIGHT);

            // Draw the tail
            int tailX = BALLOON_WIDTH / 2;
            int tailY = BALLOON_HEIGHT;
            for (int i = 0; i < TAIL_LENGTH; i++) {
                g.drawLine(tailX, tailY + i, tailX, tailY + i + 1);
            }
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(BALLOON_WIDTH, BALLOON_HEIGHT);
        }
    }
    class LabelAnimationTask extends TimerTask {
        private final JLabel label;
        private int colorIndex = 0;
        private final Color[] colors = {Color.RED, Color.GREEN, Color.BLUE, Color.PINK};

        public LabelAnimationTask(JLabel label) {
            this.label = label;
        }

		@Override
		public void run() {
			// TODO Auto-generated method stub
			 label.setForeground(colors[colorIndex]);
	            colorIndex = (colorIndex + 1) % colors.length;
		}
    }
    
    public static void main(String[] args) {
    	 try {
		        FlatSolarizedDarkContrastIJTheme.setup();
		    } catch (Exception e) {
		    	
		        e.printStackTrace();
		        
		    }
        SwingUtilities.invokeLater(HBD_JUL::new);
    }
}