#include <iostream>
using namespace std;

int main () {

    int x = 10, y = 15;

    cout <<((x !=y) && (x < y));
}
