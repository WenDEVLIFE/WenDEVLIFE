#include <iostream>

using namespace std;

int main () {

	string name;
	
cout <<"Enter your fullname" <<endl;
 cin >>name;

  
 cout <<"My Name is" " "<<name <<endl;
 
 return 0;
}
