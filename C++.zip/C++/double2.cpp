#include <iostream> 
using namespace std;

int main () {
    // float is to store 7 digit numbers //
float num1, num2, num3, num4;
cout<<"Enter first number" <<endl;
cin>>num1;
cout<<"Enter Second Number" <<endl;
cin>>num2; 
cout<<"Enter Third Number" <<endl;
cin>>num3;
cout<<"Enter Fourth Number" <<endl;
cin>>num4;  
cout << num1 << " *" << num2 <<" * " << num3 << " * " << num4 << " = " << num1 * num2 * num3 * num4;
return 0;

}