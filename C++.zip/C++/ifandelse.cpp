#include <iostream>
using namespace std;

int main(){
	
	int a,b;
	
    string  z;
	
	cout<<"Enter First Number:";
	cin>>a;
	cout<<"Enter Second Number:";
	cin>>b;
	cout<<"Operation to  be used:";
	cin>>z;
	
	if(z=="sum"){
		cout<<a+b;
	}
	
	else if (z=="product"){
		cout<<a*b;
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	return 0;
	
}
