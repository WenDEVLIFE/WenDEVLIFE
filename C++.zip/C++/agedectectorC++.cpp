#include <iostream>
using namespace std;

int main() {

cout<<"SHERLEY DOG";







return 0;

}