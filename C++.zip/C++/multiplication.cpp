#include <iostream>
using namespace std;

int main () {
    //declared variable si int means integer or whole number while initialization si i=0 og conditional */
    // si i<=5; and lastly si i++ is incriment */
    int num;
    cout<<"Enter a interger from 1-10 anything you want!\n";
    cin>>num;
     for (int i=0; i<=12; i++)
     cout<<num<<"x"<<i<<"="<<num * i <<endl;
     return 0;
}