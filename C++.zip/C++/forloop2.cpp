#include <iostream>
using namespace std;

int main () {
    //declared variable si int og initialization si i=0 og conditional si i<=5; and lastly si i++ is incriment */
    int num;
    cout<<"Enter A number\n";
    cin>>num;
     for (int i=1; i<=num; i++)
     cout<<i<<endl;
}