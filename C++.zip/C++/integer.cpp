#include <iostream>
using namespace std;

int main () {
int num;
cout << "Enter the integer" <<endl;
cin >>num;

switch (num){
    case 10:
cout << "You enter positive integers "<<endl;
break;
case 9:
cout << "You enter positive integers "<<endl;
break;
case 8:
cout << "You enter positive integers "<<endl;
break;
case 7:
cout << "You enter positive integers "<<endl;
break;
case 6:
cout << "You enter positive integers "<<endl;
break;
case 5:
cout << "You enter positive integers "<<endl;
break;
case 4:
cout << "You enter positive integers "<<endl;
break;
case 3:
cout << "You enter positive integers "<<endl;
break;
case 2:
cout << "You enter positive integers "<<endl;
break;
case 1:
cout << "You enter positive integers "<<endl;
break;
case 0:
cout << "You enter negative integers "<<endl;
break;
case -10:
cout << "You enter negative integers "<<endl;\
break;

case -9:
cout << "You enter negative integers "<<endl;
break;

case -8:
cout << "You enter negative integers "<<endl;
break;

case -7:
cout << "You enter negative integers "<<endl;
break;

case -6:
cout << "You enter negative integers "<<endl;
break;

case -5:
cout << "You enter negative integers "<<endl;
break;

case -4:
cout << "You enter negative integers "<<endl;
break;

case -3:
cout << "You enter negative integers "<<endl;
break;
case -2:
cout << "You enter negative integers "<<endl;
break;
case -1:
cout << "You enter positive integers "<<endl;
break;



default:
cout << "invalid input";
break;
}

}
 