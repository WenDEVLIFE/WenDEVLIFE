#include <iostream>
using namespace std;

int main() {
    int grade;
cout<<"Enter your grade\n";
cin>>grade;

if (grade>=75)
 {
cout<<"You have a passing grade";
} 
else
 {
    cout<<"You have a failing grade";
}
return 0;

}