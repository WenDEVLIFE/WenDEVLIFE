#include <iostream>
using namespace std;
//read the int my number //
int main() {
  int myNumber;
  myNumber = 200;
  cout << myNumber;
  return 0;
}
