#include <iostream> 
using namespace std;

int main () {
int num1, num2, result;
cout<<"Enter first number" <<endl;
cin>>num1;
cout<<"Enter Second Number" <<endl;
cin>>num2; 
cout << num1 << " + " << num2 << " = " << num1 + num2;
return 0;

}