#include <iostream>
#include <string.h>
using namespace std;

int main()
{
 float kilometers;
 cout<<"Enter a kilometers" <<endl;
 cin>>kilometers;
float  meters = kilometers * 1000;
 cout <<"meters in kilometers\n"<<meters;
 return 0;
}