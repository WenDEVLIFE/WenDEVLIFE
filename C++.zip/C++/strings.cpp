#include <iostream>
using namespace std;

int main () {
string Iname = "Jennie";
string Lname = "Kim";
string fullName = Iname + " " + Lname;
cout << fullName;
}