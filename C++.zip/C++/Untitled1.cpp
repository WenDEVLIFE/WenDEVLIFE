#include <iostream>
using namespace std;

int main() {
  cout << "Hello IGOP!";
  return 0;
}
