#include <iostream>
using namespace std;
//read the int my number //
int main () {
for (int i = 0; i < 1000; i++) {
 cout <<  "pogi will always help each other " << endl;
}
}