#include <iostream>
using namespace std;

int main ()
{

string valid, answer;
cout << "Welcome to Question and Answer plss tubaga og tarung" <<endl;
// 1st question
 cout << " 1. Earth is flat? yes/no" <<endl;
 cin >>valid; 

 if("yes" == valid){
        cout <<" NAUNSA KA SAPAKON TIKA DILI PLAT ANG EARTH!" <<endl;
    }else if("no" == valid) {
     cout <<"tama ka dong!" <<endl;

    }
     else {
      cout << "naglibog?" << endl;
     }
     // 2nd question
cout << "2.dog is a mammal?  yes/no" <<endl;
 cin >>valid; 
 if("yes" == valid){
        cout <<" TAMAA GYUD KA!" <<endl;
    }else if("no" == valid) {
     cout <<"Mali!!!" <<endl;

    }
     else {
      cout << "naglibog nasaddd?" << endl;
     }
// 3rd question
cout << " 3.sherley is a good girl?  yes/no" <<endl;
 cin >>valid; 
 if("yes" == valid){
        cout <<" TAMAA GYUD KA!" <<endl;
    }else if("no" == valid) {
     cout <<"Mali!!!" <<endl;

    }
     else {
      cout << "naglibog nasaddd pahapak tikang SHERLEY?" << endl;
     }
// 4th question
cout << "4 .Garces is IGOP?  yes/no" <<endl;
 cin >>answer; 
 if("yes" == answer){
        cout <<" TAMAA GYUD KA!" <<endl;
    }
    else if("no" == answer) {
     cout <<"Mali!!!" <<endl;

    }
     else {
      cout << "padungab kang GARCES??" << endl;
     }

     // 5th question
cout << "5 . GlennJoy is Humble?  yes/no" <<endl;
 cin >>answer; 
 if("yes" == answer){
        cout <<" TAMAA GYUD KA! Humble kaayo hawd mag PROGRAMMING" <<endl;
    }
    else if("no" == answer) {
     cout <<"Mali!!! taka2x gyud og tubag oy kayata nemo!" <<endl;

    }
     else {
      cout << "pasumbag kang GLENN??" << endl;
     }

     // end //
     cout << "Salamat sa pagtubag  og sunod nasad BABUSSH!" <<endl;
 return 0;
 

}