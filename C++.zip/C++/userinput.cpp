#include <iostream>
using namespace std;
//read the int my number //

int main() {
   cout << "Welcome to Division Calculator ";
  int a, b;
  int divide;
  cout << "Type a number: ";
  cin >> a;
  cout << "Type another number: ";
  cin >> b;
  divide = a / b;
  cout << "divide is: " << divide;
  return 0;
}