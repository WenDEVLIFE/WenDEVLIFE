#include <iostream>
using namespace std;

int main () {

    int passenger, difference;
    int x=50;
    int y=26;
    cout<<"Enter The Passenger";
    cin>>passenger;
    difference = passenger - x - y;
    cout<<difference;
}