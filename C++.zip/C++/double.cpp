#include <iostream>
using namespace std;

int main ( ) {
    float n1, n2;

    cout <<"Enter First number" <<endl;
    cin >>n1;
      cout <<"Enter Second number" <<endl;
    cin >>n2;


    cout << "The Sum is :" " " << n1 + n2 <<endl;
    cout << "The substract is :" " " << n1 - n2 <<endl;
    cout << "The Division is :" " " << n1 / n2 <<endl;
    cout << "The Product is :" " " << n1 * n2 <<endl;

}