// this a header file //
#include <iostream>
using namespace std;
// execute program //
int main() {
int age; 
string name, city, gender;
cout << " Enter your Name" <<endl;
cin >> name;
cout << "Enter your City" <<endl;
cin >> city;
cout << "Enter your Gender" <<endl;
cin >> gender;
cout << "Enter your Age"  <<endl;
cin >> age;

cout << " My Name is " " " <<name <<endl;
cout << " I live in " " " <<city <<endl;
cout << " I am " " " <<age <<endl;
cout << " My gender is " <<gender << endl;

return 0;
}