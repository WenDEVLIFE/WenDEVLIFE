#include <iostream>
using namespace std;

int main () {
    //declared variable si i=0 og conditional si i<=5; and lastly si i++ is incriment */
     for (int i=0; i<=5; i++)
     cout<<i<<endl;
}