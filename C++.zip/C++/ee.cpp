#include <iostream>
using namespace std;

/// @brief 
/// @return 
int main() {
  cout << "Hello World!";
  return 0;
}