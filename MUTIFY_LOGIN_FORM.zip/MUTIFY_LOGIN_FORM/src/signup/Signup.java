package signup;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Login_package.Login_Page;

import javax.swing.ComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;

public class Signup extends JFrame implements MouseListener,ActionListener {
	JButton exit, min, max;
	JMenuItem maxm, minm, exitm, lockm;
	JButton mutify, signup, back;
	JLabel SignTitle, user1, pass1, sex, birthday,age2;
	JTextField User, Pass, email;
	JComboBox gender;
	JComboBox m;
	JComboBox petsa;
	JComboBox year;
	JComboBox edad;
	
	
	
	mouselistener1 mml = new mouselistener1(this);
	ImageIcon exit_focused = new ImageIcon(new ImageIcon("srC/exited.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon exit_ico = new ImageIcon(new ImageIcon("src/exit.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon minimize_focused = new ImageIcon(new ImageIcon("src/minimized.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon minimize_ico = new ImageIcon(new ImageIcon("src/minimize.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon maximize_focused = new ImageIcon(new ImageIcon("src/maximized.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon maximize_ico = new ImageIcon(new ImageIcon("src/maximize.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	public Signup () {
		
		this.setUndecorated(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		exit = new JButton();
		exit.setIcon(exit_ico);
		exit.setOpaque(false);
		exit.setBorderPainted(false);
		exit.setContentAreaFilled(false);
		exit.setFocusable(false);
		exit.setBounds(690,10,15,15);
		exit.addMouseListener(this);
		this.add(exit);
		
		mutify= new JButton("");
		ImageIcon i = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\MUTIFY_LOGIN_FORM\\src\\mutify.png").getImage().getScaledInstance(61,61, Image.SCALE_SMOOTH));
		mutify.setIcon(i);
		mutify.setBounds(310,-110, 61, 300);
		mutify.setFocusable(false);
		mutify.setOpaque(false);
		mutify.setContentAreaFilled(false);
		mutify.setBorderPainted(false);
		this.add(mutify);
		
		SignTitle = new JLabel("Sign Up");
		SignTitle.setBounds(190, -55, 300, 300);
		SignTitle.setHorizontalAlignment(JLabel.CENTER);
		SignTitle.setForeground(new Color (255,255,255));
		SignTitle.setFont(new Font("Verdana", Font.PLAIN, 16));
		this.add(SignTitle);

		// Username
				user1 = new JLabel();
				user1.setText("Username");
				user1.setBounds(200,120,250,30);
				user1.setForeground(new Color (255,255,255));
				this.add(user1);
				User = new JTextField(15);
				User.setBounds(270,120,250,30);
				this.add(User);
				//password
				pass1 = new JLabel();
				pass1.setText("Password");
			    pass1.setBounds(200,170,250,30);
			    pass1.setForeground(new Color (255,255,255));
			    this.add(pass1);
			    Pass = new JTextField(15);
			    Pass.setBounds(270,170,250,30);
			    this.add(Pass);
			    
			    sex = new JLabel ("Gender");
			    sex.setBounds(200,220,250,30);
			    sex.setForeground(new Color (255,255,255));
				this.add(sex);
			    //array for JCOMBO
			   String[] genders  = {"Select a Gender","Male","Female"};
		
			    gender = new JComboBox(genders);
			    gender.setBounds(270,220,180,30);
			    this.add(gender);
			    
			    //Birthday
			    birthday = new JLabel ("Birthday");
			    birthday.setBounds(200,270,250,30);
			    birthday.setForeground(new Color (255,255,255));
			    this.add(birthday);
			    //JCOMBO MONTH
			    String month [] = {"Month","January","February","March","April","May","June","July","August","September","Octuber","November","December"};
			    m = new JComboBox(month);
			    m.setBounds(270,270,100,30);
			    this.add(m);
			  //JCOMBO DATE
			    String[] date  = {"Day","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15,","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
			    petsa = new JComboBox(date);
			    petsa.setBounds(380,270,50,30);
			    this.add(petsa);
			  //JCOMBO YEAR
			    String[] year1  = {"Year","2023","2022","2021","2020","2019","2018","2017","2016","2015","2014","2013","2012","2011","2010","2009","2008,","2007","2006","2005","2004","2003","2002","2001","2000","1999","1998","1997","1996","1995","1994","1993","1992"};
			    year = new JComboBox(year1);
			    year.setBounds(440,270,90,30);
			    this.add(year);
			    //AGE
			    age2 = new JLabel ("Age");
			    age2.setBounds(200,320,100,30);
			    age2.setForeground(new Color (255,255,255));
				this.add(age2);
				//JCOMBO AGE
				 String[] age = {"Select Age","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15,","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
				 edad = new JComboBox(age);
				 edad.setBounds(270,320,90,30);
				 this.add(edad);
				 //SIGNUP BUTTON
				 signup = new JButton("Signup"); 
					signup.setBackground(Color.RED);
					signup.setForeground(new Color (255,255,255));
					signup.setBounds(150,400,180,30); 
					signup.addActionListener(this);
					this.add(signup);
					
					back = new JButton("Back To Login"); 
					back.setBackground(Color.RED);
					back.setForeground(new Color (255,255,255));
					back.setBounds(400,400,180,30); 
					back.addActionListener(this);
					this.add(back);

				 
		min = new JButton();
		min.setIcon(minimize_ico);
		min.setOpaque(false);
		min.setBorderPainted(false);
		min.setContentAreaFilled(false);
		min.setFocusable(false);
		min.setBounds(620,10,15,15);
		min.addMouseListener(this);
		this.add(min);
		
		max = new JButton();
		max.setIcon(maximize_ico);
		max.setOpaque(false);
		max.setBorderPainted(false);
		max.setContentAreaFilled(false);
		max.setFocusable(false);
		max.setBounds(650,10,15,15);
		max.addMouseListener(this);
		this.add(max);
		
		this.setLayout(null);
		this.setVisible(true);
		this.setSize(720, 500);
		this.setVisible(true);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.getContentPane().setBackground(new Color(24, 25, 26));
		this.addMouseListener(mml);  this.addMouseMotionListener(mml);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String userValue = User.getText(); 
		String passValue = Pass.getText(); 
		
	 if (e.getSource()==back) {
		//connected to Login_Package
		 Login_Page lPage = new Login_Page();
		 
		 dispose();
		
	 }
	 
	 if (e.getSource()==signup) {
		 if (User.getText().isEmpty() && Pass.getText().isEmpty()) {
			 JOptionPane.showMessageDialog(this, "Please Enter Your Credentials to Sign Up",
                     "Warning", JOptionPane.WARNING_MESSAGE);
		}
		 else {
			 JOptionPane.showMessageDialog(this, "Successfully Registered Account",
	                 "Success", JOptionPane.INFORMATION_MESSAGE);
			 User.setText("");
			 Pass.setText("");
		 }
	 }
		if(e.getSource()==exitm) this.dispose();
	}
		public void mouseClicked(MouseEvent e) {
			if(e.getSource()==exit) this.dispose();
			if(e.getSource()==min) this.setState(Frame.ICONIFIED);
			if(e.getSource()==max) this.setState(Frame.MAXIMIZED_BOTH);
			
		}

		@Override
		public void mousePressed(MouseEvent e) {

			if(e.getSource()==exit) exit.setIcon(exit_focused);
			if(e.getSource()==max) max.setIcon(maximize_focused);
			if(e.getSource()==min) min.setIcon(minimize_focused);
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			
			if(e.getSource()==exit) exit.setIcon(exit_ico);
			if(e.getSource()==max) max.setIcon(maximize_ico);
			if(e.getSource()==min) min.setIcon(minimize_ico);
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			if(e.getSource()==exit) exit.setIcon(exit_focused);
			if(e.getSource()==max) max.setIcon(maximize_focused);
			if(e.getSource()==min) min.setIcon(minimize_focused);
			
			
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			if(e.getSource()==exit) exit.setIcon(exit_ico);
			if(e.getSource()==max) max.setIcon(maximize_ico);
			if(e.getSource()==min) min.setIcon(minimize_ico);
			
		}
}