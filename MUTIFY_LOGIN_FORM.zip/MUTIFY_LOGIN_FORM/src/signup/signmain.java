package signup;
import java.awt.Point;

import java.awt.Color;

public class signmain {
 public static void main (String [] args) {
	  new Signup();
	 
 }
}
