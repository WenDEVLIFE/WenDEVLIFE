package Login_package;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

import signup.Signup;

public class Login_Page extends JFrame implements MouseListener,ActionListener {
	// Data Types 
	JPanel loginform;
	JTextField User;
	JPasswordField Pass;
	JButton userico;
	JLabel user1, pass1, Logintitle;
	JButton loginbutton, signup ,mutify;
	JButton exit, min, max;
	JMenuItem maxm, minm, exitm, lockm;
	JCheckBox checkBox1;
	int a,b,c;
	mouselistener1 mml = new mouselistener1(this);
	ImageIcon exit_focused = new ImageIcon(new ImageIcon("srC/exited.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon exit_ico = new ImageIcon(new ImageIcon("src/exit.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon minimize_focused = new ImageIcon(new ImageIcon("src/minimized.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon minimize_ico = new ImageIcon(new ImageIcon("src/minimize.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon maximize_focused = new ImageIcon(new ImageIcon("src/maximized.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon maximize_ico = new ImageIcon(new ImageIcon("src/maximize.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	
	public Login_Page() {
		
	
		this.setUndecorated(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		
		// Logo
		mutify= new JButton("");
		ImageIcon i = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\MUTIFY_LOGIN_FORM\\src\\mutify.png").getImage().getScaledInstance(91,91, Image.SCALE_SMOOTH));
		mutify.setIcon(i);
		mutify.setBounds(310,-100, 91, 300);
		mutify.setFocusable(false);
		mutify.setOpaque(false);
		mutify.setContentAreaFilled(false);
		mutify.setBorderPainted(false);
		this.add(mutify);
		
		//Mutify Logo
		userico = new JButton();
		ImageIcon l = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\MUTIFY_LOGIN_FORM\\src\\listening.png").getImage().getScaledInstance(50,50, Image.SCALE_SMOOTH));
		userico.setIcon(l);
		userico.setBounds(235, -110,50, 300);
		userico.setFocusable(false);
		userico.setOpaque(false);
		userico.setContentAreaFilled(false);
		userico.setBorderPainted(false);
	
		//login title
		Logintitle = new JLabel("Login");
		Logintitle.setBounds(110, -70, 300, 300);
		Logintitle.setHorizontalAlignment(JLabel.CENTER);
		Logintitle.setForeground(new Color (255,255,255));
		Logintitle.setFont(new Font("Verdana", Font.PLAIN, 16));
		
		exit = new JButton();
		exit.setIcon(exit_ico);
		exit.setOpaque(false);
		exit.setBorderPainted(false);
		exit.setContentAreaFilled(false);
		exit.setFocusable(false);
		exit.setBounds(690,10,15,15);
		exit.addMouseListener(this);
		this.add(exit);
		
		min = new JButton();
		min.setIcon(minimize_ico);
		min.setOpaque(false);
		min.setBorderPainted(false);
		min.setContentAreaFilled(false);
		min.setFocusable(false);
		min.setBounds(620,10,15,15);
		min.addMouseListener(this);
		this.add(min);
		
		max = new JButton();
		max.setIcon(maximize_ico);
		max.setOpaque(false);
		max.setBorderPainted(false);
		max.setContentAreaFilled(false);
		max.setFocusable(false);
		max.setBounds(650,10,15,15);
		max.addMouseListener(this);
		this.add(max);
		
		
		// Username
		user1 = new JLabel();
		user1.setText("Username");
		user1.setBounds(50,100,80,30);
		user1.setForeground(new Color (255,255,255));
		User = new JTextField(15);
		User.setBounds(130,100,250,30);
		
		//password
		pass1 = new JLabel();
		pass1.setText("Password");
	    pass1.setBounds(50,150,80,30);
	    pass1.setForeground(new Color (255,255,255));
	    Pass = new JPasswordField(15);
	    Pass.setBounds(130,150,250,30);
	    
	  //login form 
	    loginform = new JPanel();
		loginform.setBackground(new Color(0, 0, 0));
		loginform.setBounds(100,100,500,300);   
		
		//login buttons
		loginbutton = new JButton("Login");
		loginbutton.setBackground(Color.RED);
		loginbutton.setBounds(100,250,80,30);; 
		loginbutton.setForeground(new Color (255,255,255));
		loginbutton.addActionListener(this);
		// sign up button
		signup = new JButton("Signup"); 
		signup.setBackground(Color.RED);
		signup.setForeground(new Color (255,255,255));
		signup.setBounds(350,249,80,30); 
		signup.addActionListener(this);
		
		loginform.setAlignmentX(JPanel.CENTER_ALIGNMENT);
		loginform.add(loginbutton); loginform.add(signup);
		loginform.add(user1); loginform.add(pass1); loginform.add(User); loginform.add(Pass); loginform.add(Logintitle); loginform.add(userico);
		loginform.setLayout(null);
		
		 checkBox1 = new JCheckBox("Show Password");  
	      checkBox1.setBounds(230,300,130,30); 
	      checkBox1.setForeground(new Color (255,255,255));
	      checkBox1.setBackground(Color.BLACK);
	      checkBox1.addActionListener(this);
	    this.add(checkBox1);
	
		this.add(loginform);
		this.setVisible(true);
		this.setSize(720, 500);
		this.setVisible(true);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.getContentPane().setBackground(new Color(24, 25, 26));
		this.addMouseListener(mml);  this.addMouseMotionListener(mml);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// Get the value of UseField and PassField
				String userValue = User.getText(); 
				// to get the value of Password
				String passValue = new String(Pass.getPassword());
				
				//IF checkbox got checked
			if (e.getSource()==checkBox1) {
				
				if (checkBox1.isSelected()) {
				      Pass.setEchoChar((char)0);
					} 
					
					if (!checkBox1.isSelected()) {
					   Pass.setEchoChar('*');
					}
					
			}
		
			// Signup Button Function
		if (e.getSource()==signup) {
			this.toBack();
			//Proceed to SignUp Window
			 Signup Signup = new Signup();
			 dispose();
		}

		  
		
		
		// for login button to not conflict with sign up buttons always put {}
		if (e.getSource()==loginbutton) {
		if (User.getText().isEmpty() && new String(Pass.getPassword()).isEmpty() ) {
			 JOptionPane.showMessageDialog(this, "Username and Password is empty",
                     "ERROR", JOptionPane.ERROR_MESSAGE);
		}
		  if (userValue.equals("wen@mutify.com") && passValue.equals("mutify2022")) {  //if authentic, navigate user to a new page  
			  JOptionPane.showMessageDialog(this, "User Successfully Login",
                      "Warning", JOptionPane.WARNING_MESSAGE);
	            
	        }  
	        else{  
	            //show error message  
	        	 JOptionPane.showMessageDialog(this, "Username or Password is Incorrect",
                         "ERROR", JOptionPane.ERROR_MESSAGE);
	        }  
		}
		if(e.getSource()==exitm) this.dispose();
		
		
	}
		public void mouseClicked(MouseEvent e) {
			if(e.getSource()==exit) this.dispose();
			if(e.getSource()==min) this.setState(Frame.ICONIFIED);
			if(e.getSource()==max) this.setState(Frame.MAXIMIZED_BOTH);
			
		}

		@Override
		public void mousePressed(MouseEvent e) {

			if(e.getSource()==exit) exit.setIcon(exit_focused);
			if(e.getSource()==max) max.setIcon(maximize_focused);
			if(e.getSource()==min) min.setIcon(minimize_focused);
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			
			if(e.getSource()==exit) exit.setIcon(exit_ico);
			if(e.getSource()==max) max.setIcon(maximize_ico);
			if(e.getSource()==min) min.setIcon(minimize_ico);
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			if(e.getSource()==exit) exit.setIcon(exit_focused);
			if(e.getSource()==max) max.setIcon(maximize_focused);
			if(e.getSource()==min) min.setIcon(minimize_focused);
			
			
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			if(e.getSource()==exit) exit.setIcon(exit_ico);
			if(e.getSource()==max) max.setIcon(maximize_ico);
			if(e.getSource()==min) min.setIcon(minimize_ico);
			
		}
}
