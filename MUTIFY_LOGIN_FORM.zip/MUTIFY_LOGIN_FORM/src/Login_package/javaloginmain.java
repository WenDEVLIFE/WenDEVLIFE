package Login_package;

import java.awt.Color;
import java.awt.Point;

public class javaloginmain {
public static void main(String [] args) {
	
	new Login_Page();
	
}

}
