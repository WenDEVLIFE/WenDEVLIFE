package bmipage;

import java.awt.Image;
import java.awt.Toolkit;
import java.io.IOException;


public class main {
public static void main (String []args) {
	bmipage bmipage = new bmipage();
	Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUIBMI_CALCULATOR\\src\\bmipage\\HEART.png");    
	bmipage.setIconImage(icon);    
	bmipage.setLayout(null);  

}
}
