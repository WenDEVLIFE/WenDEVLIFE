package bmipage;

//Libraries
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class bmipage extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	final int FRAME_WIDTH = 1024;
	final int FRAME_HEIGHT = 786;
	
	JPanel Navbar;
	JPanel label1;
	JTextField weight, meters2;
	JButton logo;
	JButton logo2;
	JButton bmi1;
	JButton Compute_Bmi;
	JLabel Title, weight1,meter1;

	
public bmipage() {

	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setLayout(null);
	
	// FOR Navbar
	Navbar = new JPanel();
	Navbar.setLayout(new BorderLayout(20, 15));
	Navbar.setBackground(new Color(128,128,128));
	Navbar.setBounds(-90,-100,1400,210);
	
	Title = new JLabel("BMI Calculator");
	Title.setBounds(300,50,200,200);
	Title.setForeground(new Color (255,255,255));
	Title.setFont(new Font("Sans-Serif", Font.PLAIN, 30));
	
	// Logo
	logo = new JButton();
	ImageIcon l = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUIBMI_CALCULATOR\\src\\bmipage\\bsit2.png").getImage().getScaledInstance(100,100, Image.SCALE_SMOOTH));
	logo.setIcon(l);
	logo.setBounds(100,100,100,100);
	logo.setFocusable(false);
	logo.setOpaque(false);
	logo.setContentAreaFilled(false);
	logo.setBorderPainted(false);
	logo2 = new JButton();
	ImageIcon d = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUIBMI_CALCULATOR\\src\\bmipage\\dvc.png").getImage().getScaledInstance(100,100, Image.SCALE_SMOOTH));
	logo2.setIcon(d);
	logo2.setBounds(200,100,100,100);
	logo2.setFocusable(false);
	logo2.setOpaque(false);
	logo2.setContentAreaFilled(false);
	logo2.setBorderPainted(false);
	Border border1 = new LineBorder(Color.BLACK, 4, true);
	Navbar.setBorder(border1);
	Navbar.add(logo); 
	Navbar.add(logo2); 
	Navbar.add(Title);
	Navbar.setAlignmentX(JPanel.TOP_ALIGNMENT);
	Navbar.setLayout(null);
	
	//TextFields
	//weight JLabels
	weight1 = new JLabel("Input your weight in kilograms");
	weight1.setBounds(20,150,250,30);
	weight1.setFont(new Font("Sans-Serif", Font.PLAIN, 18));
	weight1.setForeground(new Color (255,255,255));
	weight = new JTextField(4);
	//Changing JTEXTFIELD BACKGROUND
	Color color1 = Color.BLACK;
	weight.setBackground(color1);
	weight.setFont(new Font("Sans-Serif", Font.PLAIN, 20));
	weight.setForeground(new Color (0,100,0));
	weight.setBounds(260,150,200,30);
	
	//meter JLabels
	meter1 = new JLabel("Input your height in meters");
	meter1.setBounds(20,230,250,30);
	meter1.setFont(new Font("Sans-Serif", Font.PLAIN, 18));
	meter1.setForeground(new Color (255,255,255));
	
	//meter Textfield
	meters2 = new JTextField(4);
	//Changing JTEXTFIELD BACKGROUND
    Color color = Color.BLACK;
    meters2.setForeground(new Color (0,100,0));
	meters2.setFont(new Font("Sans-Serif", Font.PLAIN, 20));
	meters2.setBackground(color);
	meters2.setBounds(260,230,200,30);
	
	//calculate bmi
	Compute_Bmi = new JButton("Calculate");
	Compute_Bmi.setBackground(Color.RED);
	Compute_Bmi.setForeground(new Color (255,255,255));
	Compute_Bmi.setBounds(150,300,200,30); 
	Compute_Bmi.addActionListener(this);

	//label logo
	bmi1 = new JButton();
	ImageIcon li = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUIBMI_CALCULATOR\\src\\bmipage\\bmi1.png").getImage().getScaledInstance(100,100, Image.SCALE_SMOOTH));
	bmi1.setIcon(li);
	bmi1.setBounds(200,10,100,100);
	bmi1.setFocusable(false);
	bmi1.setOpaque(false);
	bmi1.setContentAreaFilled(false);
	bmi1.setBorderPainted(false);

	// Label
	label1 = new JPanel();
	label1.setBackground(new Color(128,128,128));
	label1.setBounds(250,200,500,400); 
	label1.setAlignmentX(JPanel.CENTER_ALIGNMENT);
	Border border = new LineBorder(Color.BLACK, 4, true);
    label1.setBorder(border);
	label1.setLayout(null);
	label1.add(weight1); 
	label1.add(bmi1);
	label1.add(weight);
	label1.add(meter1);
	label1.add(meters2);
	label1.add(Compute_Bmi);
	
	//Background Image of the App
	ImageIcon background_image = new ImageIcon(new ImageIcon("src/bmipage/dvc3.jpg").getImage().getScaledInstance(FRAME_WIDTH, FRAME_HEIGHT, Image.SCALE_SMOOTH));
	JLabel background_Label = new JLabel(background_image);
	background_Label.setBounds(0,0,FRAME_WIDTH, FRAME_HEIGHT);

	

	
	
	// Add
	this.setTitle("BMI Calculator By: WenDevLife");
	this.add(Navbar);
	this.add(label1);
	this.setVisible(true);
	this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
	this.setVisible(true);
	this.setResizable(false);
	this.setLocationRelativeTo(null);
	
	//display the background image
	this.add(background_Label);
	//this.getContentPane().setBackground(new Color(35, 203, 167));
	
}

@Override
public void actionPerformed(ActionEvent e) {
	//functions of the buttons
	if (e.getSource()==Compute_Bmi) {
		//if the JTextField is Empty 
		if (weight.getText().isEmpty() && meters2.getText().isEmpty() ) {
			 JOptionPane.showMessageDialog(this, "Please Fill in the Blanks to Proceed",
                    "ERROR", JOptionPane.ERROR_MESSAGE);
		}
		// else the user put a value on the JTextField
		else {
			//calculate the value
			 double kilograms = Double.parseDouble(weight.getText());
	         double meters    = Double.parseDouble(meters2.getText());
	         int    bmi       = (int)computeBMI(kilograms, meters);
	         JLabel hericon = new JLabel(new ImageIcon("HEART.png"));
	         ImageIcon icon = new ImageIcon(new ImageIcon("src/bmipage/HEART.png").getImage().getScaledInstance(20,20, Image.SCALE_SMOOTH));
	         JOptionPane.showMessageDialog(null, "Your BMI is " + bmi,null, JOptionPane.INFORMATION_MESSAGE, icon);
		}
		
	}
	
}

// calculate the input
private int computeBMI(double weight, double meters2) {
	 return (int) (weight / (meters2 * meters2));
}
}
