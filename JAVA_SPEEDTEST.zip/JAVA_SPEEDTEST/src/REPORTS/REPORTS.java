package REPORTS;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.MalformedURLException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import ABOUT_US.ABOUT_US;
import speedtestmain.SPEEDTEST;
import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import javax.swing.UIManager;

public class REPORTS extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public JTable table;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					REPORTS frame2 = new REPORTS();
					frame2.setVisible(true);
					frame2.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public REPORTS() throws MalformedURLException {
		REPORTS frame2 = this;
		setFont(new Font("Franklin Gothic Medium Cond", Font.PLAIN, 31));
		setTitle("                                                     JAVA INTERNET SPEEDTEST");
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\speed.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 748);
		contentPane =new JPanel();
		contentPane.setBackground(new Color(16, 42, 67));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(16, 42, 72)));
		panel.setBackground(new Color(16, 42, 72));
		panel.setBounds(-12, -34, 106, 754);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\speed1.png"));
		lblNewLabel_1.setBounds(32, 31, 64, 64);
		panel.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(16, 42, 72));
		panel_1.setBounds(10, 135, 86, 107);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(20, 0, 86, 56);
		panel_1.add(lblNewLabel_2);
		lblNewLabel_2.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\icons8-wi-fi-48.png"));
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(0, 0, 86, 107);
		panel_1.add(lblNewLabel_3);
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			public  void setColor (JPanel panel_1) {
				panel_1.setBackground(new Color (255,255,255));
			}
			public  void resetColor (JPanel pl3) {
				pl3.setBackground(new Color (16, 42, 72));
				
			
			}
		
		
			
			@Override
			public void mouseClicked(MouseEvent e) {
				setColor(panel_1);
				SPEEDTEST frame1 = null;
				try {
					frame1 = new SPEEDTEST();
					frame1.setVisible(true);
					frame1.setResizable(false);
					frame2.dispose();
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				resetColor(panel_1);
			
				
			}
		});
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		
		JLabel lblNewLabel_4_1_1 = new JLabel("  TEST YOUR INTERNET");
		lblNewLabel_4_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_4_1_1.setBounds(0, 55, 86, 14);
		panel_1.add(lblNewLabel_4_1_1);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBackground(new Color(16, 42, 72));
		panel_1_1.setBounds(10, 253, 86, 107);
		panel.add(panel_1_1);
		
		JLabel lblNewLabel_2_1 = new JLabel("");
		lblNewLabel_2_1.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\icons8-reports-58.png"));
		lblNewLabel_2_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_2_1.setBounds(10, 11, 58, 56);
		panel_1_1.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("");
		lblNewLabel_3_1.addMouseListener(new MouseAdapter() {
			public  void setColor (JPanel panel_1_1) {
				panel_1_1.setBackground(new Color (255,255,255));
			}
			public  void resetColor (JPanel pl3) {
				pl3.setBackground(new Color (16, 42, 72));
				
			
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				setColor(panel_1_1);
				REPORTS frame2 = null;
				try {
					frame2 = new REPORTS();
					frame2.setVisible(true);
					frame2.dispose();
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				resetColor(panel_1_1);
				
			}
		});
		lblNewLabel_3_1.setForeground(Color.WHITE);
		lblNewLabel_3_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_3_1.setBounds(0, 0, 86, 107);
		panel_1_1.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_4 = new JLabel("REPORTS");
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_4.setBounds(22, 78, 46, 14);
		panel_1_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel = new JLabel("JAVA SPEEDTEST");
		lblNewLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 11));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(20, 90, 86, 14);
		panel.add(lblNewLabel);
		
		JPanel panel_1_1_1 = new JPanel();
		panel_1_1_1.setLayout(null);
		panel_1_1_1.setBackground(new Color(16, 42, 72));
		panel_1_1_1.setBounds(10, 371, 86, 107);
		panel.add(panel_1_1_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("");
		lblNewLabel_2_1_1.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\icons8-more-info-48.png"));
		lblNewLabel_2_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_2_1_1.setBounds(10, 11, 58, 56);
		panel_1_1_1.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("ABOUT US");
		lblNewLabel_4_1.setForeground(Color.WHITE);
		lblNewLabel_4_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_4_1.setBounds(10, 68, 46, 14);
		panel_1_1_1.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("");
		lblNewLabel_3_1_1.setBounds(0, 0, 86, 107);
		panel_1_1_1.add(lblNewLabel_3_1_1);
		lblNewLabel_3_1_1.addMouseListener(new MouseAdapter() {
			public  void setColor (JPanel panel_1_1) {
				panel_1_1_1.setBackground(new Color (255,255,255));
			}
			public  void resetColor (JPanel pl3) {
				pl3.setBackground(new Color (16, 42, 72));
				
			
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				setColor(panel_1_1_1);
				ABOUT_US frame3 = new ABOUT_US();
				frame3.setResizable(false);
				frame3.setVisible(true);
				frame2.dispose();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				resetColor(panel_1_1_1);
			
				
				
				
			}

		});
		lblNewLabel_3_1_1.setForeground(Color.WHITE);
		lblNewLabel_3_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		
		JLabel lblNewLabel_5 = new JLabel("TEST REPORTS");
		lblNewLabel_5.setForeground(Color.WHITE);
		lblNewLabel_5.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
		lblNewLabel_5.setBounds(260, 11, 172, 69);
		contentPane.add(lblNewLabel_5);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(192, 192, 192));
		panel_2.setBounds(142, 91, 402, 575);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		//Our Jtable Report
		table = new JTable();
		table.setBackground(new Color(0, 0, 0));
		table.setCellSelectionEnabled(true);
		table.setColumnSelectionAllowed(true);
		table.setBounds(391, 0, -389, 580);
		//rows and column but it is not working l think its a bug from my window builder
		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("URL");
		model.addColumn("Speed (KB/s");
		table.setModel(model);
		panel_2.add(table);
		
		
		
		
		
		
	}
}
