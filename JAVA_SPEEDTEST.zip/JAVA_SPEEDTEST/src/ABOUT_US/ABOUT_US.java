package ABOUT_US;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.MalformedURLException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import REPORTS.REPORTS;
import speedtestmain.SPEEDTEST;

public class ABOUT_US extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ABOUT_US frame3 = new ABOUT_US();
					frame3.setVisible(true);
					frame3.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ABOUT_US() {
		ABOUT_US frame3 = this;
		setFont(new Font("Franklin Gothic Medium Cond", Font.PLAIN, 31));
		setTitle("                                                     JAVA INTERNET SPEEDTEST");
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\speed.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 748);
		contentPane =new JPanel();
		contentPane.setBackground(new Color(16, 42, 67));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(16, 42, 72)));
		panel.setBackground(new Color(16, 42, 72));
		panel.setBounds(-12, -34, 106, 754);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\speed1.png"));
		lblNewLabel_1.setBounds(32, 31, 64, 64);
		panel.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(16, 42, 72));
		panel_1.setBounds(10, 135, 86, 107);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(20, 0, 66, 56);
		panel_1.add(lblNewLabel_2);
		lblNewLabel_2.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\icons8-wi-fi-48.png"));
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(0, 0, 86, 107);
		panel_1.add(lblNewLabel_3);
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			public  void setColor (JPanel panel_1) {
				panel_1.setBackground(new Color (255,255,255));
			}
			public  void resetColor (JPanel pl3) {
				pl3.setBackground(new Color (16, 42, 72));
				
			
			}
		
		
			
			@Override
			public void mouseClicked(MouseEvent e) {
				setColor(panel_1);
				SPEEDTEST frame1 = null;
				try {
					frame1 = new SPEEDTEST();
					frame1.setVisible(true);
					frame1.setResizable(false);
					frame3.dispose();
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				frame1.setVisible(true);
				frame3.dispose();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				resetColor(panel_1);
			
				
			}
		});
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		
		JLabel lblNewLabel_4_1_1 = new JLabel("  TEST YOUR INTERNET");
		lblNewLabel_4_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_4_1_1.setBounds(0, 55, 86, 14);
		panel_1.add(lblNewLabel_4_1_1);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBackground(new Color(16, 42, 72));
		panel_1_1.setBounds(10, 253, 86, 107);
		panel.add(panel_1_1);
		
		JLabel lblNewLabel_2_1 = new JLabel("");
		lblNewLabel_2_1.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\icons8-reports-58.png"));
		lblNewLabel_2_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_2_1.setBounds(10, 11, 58, 56);
		panel_1_1.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("");
		lblNewLabel_3_1.addMouseListener(new MouseAdapter() {
			public  void setColor (JPanel panel_1_1) {
				panel_1_1.setBackground(new Color (255,255,255));
			}
			public  void resetColor (JPanel pl3) {
				pl3.setBackground(new Color (16, 42, 72));
				
			
			}
			@SuppressWarnings("null")
			@Override
			public void mouseClicked(MouseEvent e) {
				setColor(panel_1_1);
				REPORTS frame2 = null;
				
				try {
					frame2 = new REPORTS();
					frame2.setVisible(true);
					frame2.setResizable(false);
					frame3.dispose();
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				resetColor(panel_1_1);
				
			}
		});
		lblNewLabel_3_1.setForeground(Color.WHITE);
		lblNewLabel_3_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_3_1.setBounds(0, 0, 86, 107);
		panel_1_1.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_4 = new JLabel("REPORTS");
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_4.setBounds(22, 78, 46, 14);
		panel_1_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel = new JLabel("JAVA SPEEDTEST");
		lblNewLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 11));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(20, 90, 86, 14);
		panel.add(lblNewLabel);
		
		JPanel panel_1_1_1 = new JPanel();
		panel_1_1_1.setLayout(null);
		panel_1_1_1.setBackground(new Color(16, 42, 72));
		panel_1_1_1.setBounds(10, 371, 86, 107);
		panel.add(panel_1_1_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("");
		lblNewLabel_2_1_1.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\icons8-more-info-48.png"));
		lblNewLabel_2_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_2_1_1.setBounds(10, 11, 58, 56);
		panel_1_1_1.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("ABOUT US");
		lblNewLabel_4_1.setForeground(Color.WHITE);
		lblNewLabel_4_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_4_1.setBounds(10, 66, 46, 14);
		panel_1_1_1.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("");
		lblNewLabel_3_1_1.setBounds(0, 0, 86, 107);
		panel_1_1_1.add(lblNewLabel_3_1_1);
		lblNewLabel_3_1_1.addMouseListener(new MouseAdapter() {
			public  void setColor (JPanel panel_1_1) {
				panel_1_1_1.setBackground(new Color (255,255,255));
			}
			public  void resetColor (JPanel pl3) {
				pl3.setBackground(new Color (16, 42, 72));
				
			
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				setColor(panel_1_1_1);
				ABOUT_US frame3 = new ABOUT_US();
				frame3.setVisible(true);
				frame3.setResizable(false);
				frame3.dispose();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				resetColor(panel_1_1_1);
			
				
				
				
			}

		});
		lblNewLabel_3_1_1.setForeground(Color.WHITE);
		lblNewLabel_3_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		
		JLabel lblNewLabel_5 = new JLabel("ABOUT US");
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
		lblNewLabel_5.setBounds(267, 21, 120, 69);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setBackground(new Color(192, 192, 192));
		lblNewLabel_6.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\SPEDETRES.png"));
		lblNewLabel_6.setBounds(177, 60, 312, 272);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_5_1 = new JLabel(" JAVA SPEEDTEST ");
		lblNewLabel_5_1.setForeground(Color.WHITE);
		lblNewLabel_5_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
		lblNewLabel_5_1.setBounds(233, 314, 210, 69);
		contentPane.add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_5_2 = new JLabel("VERSION ");
		lblNewLabel_5_2.setForeground(Color.WHITE);
		lblNewLabel_5_2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_2.setBounds(133, 362, 78, 69);
		contentPane.add(lblNewLabel_5_2);
		
		JLabel lblNewLabel_5_2_1 = new JLabel("1.0");
		lblNewLabel_5_2_1.setForeground(Color.WHITE);
		lblNewLabel_5_2_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_2_1.setBounds(133, 406, 78, 69);
		contentPane.add(lblNewLabel_5_2_1);
		
		JLabel lblNewLabel_5_2_2 = new JLabel("CREATOR");
		lblNewLabel_5_2_2.setForeground(Color.WHITE);
		lblNewLabel_5_2_2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_2_2.setBounds(117, 442, 78, 69);
		contentPane.add(lblNewLabel_5_2_2);
		
		JLabel lblNewLabel_5_2_2_1 = new JLabel("@WENDEVLIFE");
		lblNewLabel_5_2_2_1.setForeground(Color.WHITE);
		lblNewLabel_5_2_2_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_2_2_1.setBounds(104, 499, 128, 69);
		contentPane.add(lblNewLabel_5_2_2_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(192, 192, 192));
		panel_2.setBounds(169, 76, 320, 240);
		contentPane.add(panel_2);
		
		JLabel lblNewLabel_5_2_2_2 = new JLabel("APP CREATED");
		lblNewLabel_5_2_2_2.setForeground(Color.WHITE);
		lblNewLabel_5_2_2_2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_2_2_2.setBounds(104, 551, 162, 69);
		contentPane.add(lblNewLabel_5_2_2_2);
		
		JLabel lblNewLabel_5_2_2_1_1 = new JLabel("02/03/23");
		lblNewLabel_5_2_2_1_1.setForeground(Color.WHITE);
		lblNewLabel_5_2_2_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_2_2_1_1.setBounds(117, 599, 83, 69);
		contentPane.add(lblNewLabel_5_2_2_1_1);
		
		JLabel lblNewLabel_5_2_3 = new JLabel("HEADQUATERS");
		lblNewLabel_5_2_3.setForeground(Color.WHITE);
		lblNewLabel_5_2_3.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_2_3.setBounds(369, 362, 120, 69);
		contentPane.add(lblNewLabel_5_2_3);
		
		JLabel lblNewLabel_5_2_1_1 = new JLabel("Davao City, Philippines");
		lblNewLabel_5_2_1_1.setForeground(Color.WHITE);
		lblNewLabel_5_2_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_2_1_1.setBounds(324, 394, 199, 69);
		contentPane.add(lblNewLabel_5_2_1_1);
		
		JLabel lblNewLabel_5_2_3_1 = new JLabel("COMPANY OR GROUP");
		lblNewLabel_5_2_3_1.setForeground(Color.WHITE);
		lblNewLabel_5_2_3_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_2_3_1.setBounds(334, 442, 173, 69);
		contentPane.add(lblNewLabel_5_2_3_1);
		
		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\Untitled design (2).png"));
		lblNewLabel_7.setBounds(334, 499, 199, 165);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_5_2_2_1_1_1 = new JLabel("@UPCR");
		lblNewLabel_5_2_2_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_5_2_2_1_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_2_2_1_1_1.setBounds(405, 654, 69, 44);
		contentPane.add(lblNewLabel_5_2_2_1_1_1);
		
		JPanel panel_2_1 = new JPanel();
		panel_2_1.setBackground(Color.LIGHT_GRAY);
		panel_2_1.setBounds(324, 498, 220, 166);
		contentPane.add(panel_2_1);
	}
}
