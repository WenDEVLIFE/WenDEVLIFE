package LOADINGBAR;

import java.io.IOException;

import javax.swing.UnsupportedLookAndFeelException;



public class main {
// for loading bar
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, IOException, UnsupportedLookAndFeelException {
		// TODO Auto-generated method stub
		new loadingbar();	
	}

}
