package LOADINGBAR;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.UnsupportedLookAndFeelException;

import speedtestmain.SPEEDTEST;



public class loadingbar extends JFrame {
	private static final long serialVersionUID = 1L;
	
	ImageIcon bg = new ImageIcon(new ImageIcon("src//SPEEDTEST.png")
			.getImage().getScaledInstance(420, 320, Image.SCALE_SMOOTH));
	ImageIcon logo = new ImageIcon(new ImageIcon("SPEEDTEST.png")
			.getImage().getScaledInstance(289,126, Image.SCALE_SMOOTH));
	
	JLabel bg_label, welcome;
	
	JPanel panel, concept, panel_exit;
	
	JProgressBar load = new JProgressBar(0,100);
	
	JLayeredPane layer;
	
	JButton start;
	
	public loadingbar() throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setUndecorated(true);
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\speed.png"));
		
		load.setBounds(0, 400, 420, 20);
		load.setValue(0);
		load.setOpaque(false);
		load.setForeground(new Color(0,128,0));
		
		welcome = new JLabel(logo);
		welcome.setBounds(0, 190,289,126);
		welcome.setOpaque(false);
		
		panel = new JPanel();
		panel.setBounds(0, 0, 420, 320);
		panel.setSize(new Dimension(420,320));
		panel.setOpaque(false);
		panel.setLayout(new BorderLayout());
		panel.add(load, BorderLayout.SOUTH);
		
		concept = new JPanel();
		concept.setBounds(0, 100, 420, 320);
		concept.setOpaque(false);
		concept.add(welcome);
		
		bg_label = new JLabel(bg);
		bg_label.setBounds(0, 0, 420, 320);
		bg_label.add(panel);
		
		/*layer = new JLayeredPane();
		layer.setBounds(0,0,420, 320);
		layer.add(bg_label, JLayeredPane.DEFAULT_LAYER);
		layer.add(panel, JLayeredPane.PALETTE_LAYER);
		layer.add(concept, JLayeredPane.MODAL_LAYER); */
		
		add(concept);
		add(panel);
		
		pack();
		setSize(420, 320);
		setLocationRelativeTo(null);
		setVisible(true);
		add(bg_label);
		
		try {
			fill();
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public void fill() throws InterruptedException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		int i = 0;
		while (i<=100) {
			
			load.setValue(i);
			Thread.sleep(30);
			i++;
			
			if (i==100) {
				SPEEDTEST frame = new SPEEDTEST();
				frame.setVisible(true);
				this.dispose();
			}
		}
		
	}
	public void actionPerformed(ActionEvent e) {
		
	}

}
