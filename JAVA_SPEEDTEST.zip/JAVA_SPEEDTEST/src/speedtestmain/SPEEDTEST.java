package speedtestmain;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Label;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import ABOUT_US.ABOUT_US;
import REPORTS.REPORTS;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTable;

public class SPEEDTEST extends REPORTS {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public JPanel ABOUTUS;
	

	/**
	 * Launch the application.s
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SPEEDTEST frame1 = new SPEEDTEST();
					frame1.setVisible(true);
					frame1.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws MalformedURLException 
	 */
	@SuppressWarnings("unchecked")
	public SPEEDTEST() throws MalformedURLException {
		
     SPEEDTEST frame1 = this;
     class LinkItem {
    	    private String text;
    	    private URL url;

    	    public LinkItem(String text, URL url) {
    	        this.text = text;
    	        this.url = url;
    	    }

    	    @SuppressWarnings("unused")
			public String getText() {
    	        return text;
    	    }

    	    public URL getUrl() {
    	        return url;
    	    }

    	    @Override
    	    public String toString() {
    	        return text;
    	    }
    	}
		setFont(new Font("Franklin Gothic Medium Cond", Font.PLAIN, 31));
		setTitle("                                                     JAVA INTERNET SPEEDTEST");
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\speed.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 748);
		contentPane =new JPanel();
		contentPane.setBackground(new Color(16, 42, 67));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(16, 42, 72)));
		panel.setBackground(new Color(16, 42, 72));
		panel.setBounds(-12, -34, 106, 754);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\speed1.png"));
		lblNewLabel_1.setBounds(32, 31, 64, 64);
		panel.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(16, 42, 72));
		panel_1.setBounds(10, 135, 86, 107);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(21, 0, 76, 56);
		panel_1.add(lblNewLabel_2);
		lblNewLabel_2.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\icons8-wi-fi-48.png"));
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(0, 0, 86, 107);
		panel_1.add(lblNewLabel_3);
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			public  void setColor (JPanel panel_1) {
				panel_1.setBackground(new Color (255,255,255));
			}
			public  void resetColor (JPanel pl3) {
				pl3.setBackground(new Color (16, 42, 72));
				
			
			}
		
		
			
			@Override
			public void mouseClicked(MouseEvent e) {
				setColor(panel_1);
				SPEEDTEST frame1 = null;
				try {
					frame1 = new SPEEDTEST();
					frame1.setVisible(true);
					frame1.setResizable(false);
					frame1.dispose();
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				resetColor(panel_1);
			
				
			}
		});
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		
		JLabel lblNewLabel_4_1_1 = new JLabel("  TEST YOUR INTERNET");
		lblNewLabel_4_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_4_1_1.setBounds(0, 56, 86, 14);
		panel_1.add(lblNewLabel_4_1_1);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBackground(new Color(16, 42, 72));
		panel_1_1.setBounds(10, 253, 86, 107);
		panel.add(panel_1_1);
		
		JLabel lblNewLabel_2_1 = new JLabel("");
		lblNewLabel_2_1.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\icons8-reports-58.png"));
		lblNewLabel_2_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_2_1.setBounds(10, 11, 58, 56);
		panel_1_1.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("");
		lblNewLabel_3_1.addMouseListener(new MouseAdapter() {
			public  void setColor (JPanel panel_1_1) {
				panel_1_1.setBackground(new Color (255,255,255));
			}
			public  void resetColor (JPanel pl3) {
				pl3.setBackground(new Color (16, 42, 72));
				
			
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				setColor(panel_1_1);
				REPORTS frame2 = null;
				try {
					frame2 = new REPORTS();
					frame2.setVisible(true);
					frame2.setResizable(false);
					frame1.dispose();
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				resetColor(panel_1_1);
				
			}
		});
		lblNewLabel_3_1.setForeground(Color.WHITE);
		lblNewLabel_3_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_3_1.setBounds(0, 0, 86, 107);
		panel_1_1.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_4 = new JLabel("REPORTS");
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_4.setBounds(22, 78, 46, 14);
		panel_1_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel = new JLabel("JAVA SPEEDTEST");
		lblNewLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 11));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(20, 90, 86, 14);
		panel.add(lblNewLabel);
		
		JPanel panel_1_1_1 = new JPanel();
		panel_1_1_1.setLayout(null);
		panel_1_1_1.setBackground(new Color(16, 42, 72));
		panel_1_1_1.setBounds(10, 371, 86, 107);
		panel.add(panel_1_1_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("");
		lblNewLabel_2_1_1.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\icons8-more-info-48.png"));
		lblNewLabel_2_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_2_1_1.setBounds(10, 11, 58, 56);
		panel_1_1_1.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("ABOUT US");
		lblNewLabel_4_1.setForeground(Color.WHITE);
		lblNewLabel_4_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		lblNewLabel_4_1.setBounds(20, 69, 46, 14);
		panel_1_1_1.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("");
		lblNewLabel_3_1_1.setBounds(0, 0, 86, 107);
		panel_1_1_1.add(lblNewLabel_3_1_1);
		lblNewLabel_3_1_1.addMouseListener(new MouseAdapter() {
			public  void setColor (JPanel panel_1_1) {
				panel_1_1_1.setBackground(new Color (255,255,255));
			}
			public  void resetColor (JPanel pl3) {
				pl3.setBackground(new Color (16, 42, 72));
				
			
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				setColor(panel_1_1_1);
				ABOUT_US frame3 = new ABOUT_US();
				frame3.setResizable(false);
				frame3.setVisible(true);
				frame1.dispose();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				resetColor(panel_1_1_1);
			
				
				
				
			}

		});
		lblNewLabel_3_1_1.setForeground(Color.WHITE);
		lblNewLabel_3_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 10));
		
		JLabel lblNewLabel_5 = new JLabel("JAVA SPEEDTEST");
		lblNewLabel_5.setForeground(Color.WHITE);
		lblNewLabel_5.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
		lblNewLabel_5.setBounds(259, 11, 194, 69);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_5_1 = new JLabel("SELECT A WEBSITE");
		lblNewLabel_5_1.setForeground(Color.WHITE);
		lblNewLabel_5_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_1.setBounds(125, 103, 150, 69);
		contentPane.add(lblNewLabel_5_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setForeground(new Color(255, 255, 255));
		comboBox.setBackground(new Color(128, 128, 128));
		//array value
		comboBox.setModel(new DefaultComboBoxModel(new LinkItem[] {
		    new LinkItem("Google", new URL("https://www.google.com")),
		    new LinkItem("YouTube", new URL("https://www.youtube.com")),
		    new LinkItem("Instagram", new URL("https://www.instagram.com")),
		    new LinkItem("Speedtest", new URL("https://www.speedtest.net")),
		    new LinkItem("Twitter", new URL("https://www.twitter.com")),
		    new LinkItem("Fast.com", new URL("https://www.fast.com")),
		    new LinkItem("PLDT", new URL("https://www.pldthome.com")),
		    new LinkItem("GLOBE", new URL("https://www.globe.com.ph")),
		    new LinkItem("DITO", new URL("https://www.dito.ph")),
		    new LinkItem("GITHUB", new URL("https://github.com")),
		    new LinkItem("STACK OVERFLOW", new URL("https://stackoverflow.com/")),
		    new LinkItem("CHATGPT OPENAI", new URL("https://chat.openai.com/chat")),
		}));

		comboBox.addActionListener((ActionListener) new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		      
		    }
		});

		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox.setBounds(274, 121, 259, 38);
		contentPane.add(comboBox);
		
		JLabel lblNewLabel_5_1_1 = new JLabel("");
		lblNewLabel_5_1_1.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\icons8-speed-test-64.png"));
		lblNewLabel_5_1_1.setForeground(Color.WHITE);
		lblNewLabel_5_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_1_1.setBounds(322, 204, 71, 69);
		contentPane.add(lblNewLabel_5_1_1);
		
		JLabel lblNewLabel_5_1_2 = new JLabel("SPEEDTEST RESULT");
		lblNewLabel_5_1_2.setForeground(Color.WHITE);
		lblNewLabel_5_1_2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_1_2.setBounds(274, 272, 155, 69);
		contentPane.add(lblNewLabel_5_1_2);
		
	
		JLabel Labelping = new JLabel("0 ms");
		Labelping.setForeground(Color.WHITE);
		Labelping.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		Labelping.setBounds(429, 362, 155, 69);
		contentPane.add(Labelping);
		
		JLabel lblNewLabel_5_1_2_1 = new JLabel("0.000 kb/s");
		lblNewLabel_5_1_2_1.setForeground(Color.WHITE);
		lblNewLabel_5_1_2_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_1_2_1.setBounds(173, 362, 155, 69);
		contentPane.add(lblNewLabel_5_1_2_1);
		
		JLabel lblNewLabel_5_1_2_2_1_1_1 = new JLabel("0.00 kb/s");
		lblNewLabel_5_1_2_2_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_5_1_2_2_1_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_1_2_2_1_1_1.setBounds(285, 456, 204, 69);
		contentPane.add(lblNewLabel_5_1_2_2_1_1_1);
		
		JButton btnNewButton = new JButton("START");
		btnNewButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        if (e.getSource()==btnNewButton) {
		        	// select from the user
		            LinkItem item = (LinkItem) comboBox.getSelectedItem();
		            if (item != null) {
		            	// get the url from the arraylist
		                URL url = item.getUrl();
		                // get the host 
		                String host = url.getHost();
		                try {
		                	// get the address and the host
		                    InetAddress address = InetAddress.getByName(host);
		                    long start = System.currentTimeMillis();
		                    if (address.isReachable(1000)) {
		                        long end = System.currentTimeMillis();
		                        long duration = end - start;
		                        //display ping value
		                        Labelping.setText("Ping: " + duration + " ms");

		                        URLConnection connection = url.openConnection();
		                        connection.setDoOutput(true);
		                        start = System.currentTimeMillis();
		                        try (InputStream inputStream = connection.getInputStream()) {
		                            byte[] buffer = new byte[8192];
		                            int bytesRead;
		                            long totalBytesRead = 0;
		                            while ((bytesRead = inputStream.read(buffer)) != -1) {
		                                totalBytesRead += bytesRead;
		                                long end1 = System.currentTimeMillis();
		                                long duration1 = (end1 - start) / 1000;
		                                if (duration1 > 0) {
		                                	//display speed and upload value
		                                    double speed = (totalBytesRead / 1024) / (duration1);
		                                    lblNewLabel_5_1_2_1.setText("Speed: " + speed + " KB/s");
		                                    double upload = (totalBytesRead / 1024) / duration1;
		                                    lblNewLabel_5_1_2_2_1_1_1.setText("Upload: " + upload + " KB/s");

		                                    // add the data to the JTable
		                                    DefaultTableModel model = (DefaultTableModel) table.getModel();
		                                    model.addRow(new Object[]{url.toString(), speed, upload});

		                                    // refresh the JTable
		                                    table.revalidate();
		                                    table.repaint();
		                                    // print 0 or display 0
		                                } else {
		                                    lblNewLabel_5_1_2_1.setText("Speed: 0 KB/s");
		                                    lblNewLabel_5_1_2_2_1_1_1.setText("Upload: 0 KB/s");
		                                }
		                            }
		                        }
		                        // else the host is unreachable
		                    } else {
		                    	//print ping unreachable
		                        Labelping.setText("Ping: unreachable");
		                    }
		                } catch (IOException ex) { // catch both exceptions
		                    lblNewLabel_5_1_2_1.setText("Error: " + ex.getMessage());
		                }
		            }
		        }
		    }
		});
		
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(0, 128, 192));
		btnNewButton.setBounds(201, 546, 277, 87);
		contentPane.add(btnNewButton);
		
		JLabel LABEL4 = new JLabel("PING");
		LABEL4.setForeground(Color.WHITE);
		LABEL4.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		LABEL4.setBounds(439, 312, 50, 69);
		contentPane.add(LABEL4);
		
		JLabel lblNewLabel_5_1_2_2_1 = new JLabel("SPEED");
		lblNewLabel_5_1_2_2_1.setForeground(Color.WHITE);
		lblNewLabel_5_1_2_2_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_1_2_2_1.setBounds(201, 312, 50, 69);
		contentPane.add(lblNewLabel_5_1_2_2_1);
		
		JLabel lblNewLabel_5_1_2_2_1_1 = new JLabel("UPLOAD");
		lblNewLabel_5_1_2_2_1_1.setForeground(Color.WHITE);
		lblNewLabel_5_1_2_2_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblNewLabel_5_1_2_2_1_1.setBounds(304, 402, 89, 69);
		contentPane.add(lblNewLabel_5_1_2_2_1_1);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setIcon(new ImageIcon("C:\\JAVA_ECLIPSE\\JAVA_SPEEDTEST\\src\\icons8-java-48.png"));
		lblNewLabel_6.setBounds(211, 5, 95, 87);
		contentPane.add(lblNewLabel_6);
		
		
		
		
		
	}
}
