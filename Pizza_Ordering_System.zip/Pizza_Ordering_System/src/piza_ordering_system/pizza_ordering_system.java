package piza_ordering_system;
import java.util.Scanner;
// My Pizza Ordering System */
public class pizza_ordering_system {
	public static void main(String args[]) {
		Scanner order = new Scanner (System.in);
		Scanner total = new Scanner (System.in);
		Scanner object = new Scanner (System.in);
		Scanner Objecker = new Scanner (System.in);
		Scanner ask = new Scanner(System.in);
		double money, add;
		int op1, op2;
		char op =0;
		do {
		System.out.println("-------------------------------------------");
		System.out.println("--------Tech-Pizza-Ordering-System---------");
		System.out.println("-------------------------------------------");
		System.out.println("");
		System.out.println("-------------------------------------------");
		System.out.println("----------Select-From-The-Menu-------------");
		System.out.println("-------------------------------------------");
		System.out.println("[1] Peperoni with Pineapple");
		System.out.println("[2] Chorizzo with green bell pepper and with pineapple");
		System.out.println("[3] Peperoni with Super Dupper Cheeese Toppings");
		System.out.println("[4] Veggie Pizza");
		System.out.println("[5] Meat Pizza");
		System.out.println("[6] Spicy PIZZA with peperoni, cheese, green bell pepper, and pineapple");
		op1 = order.nextInt();
		switch(op1) {
		case 1:
			System.out.println("-------------------------------------------");
			System.out.println("-------------Confirmation------------------");
			System.out.println("-------------------------------------------");
			System.out.println("[1] Peperoni with Pineapple");
			System.out.println("Price: 120 Pesos");
			System.out.println("Are you sure? Yes or No");
			String answerer = object.nextLine();
		    switch (answerer) {
		    case "Yes":
		    	System.out.println("-----------------------------------------");
		    	System.out.println("---------------Add-ons-------------------");
		    	System.out.println("-----------------------------------------");
		    	System.out.println("[1] Coca Cola");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[2] Sprite");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[3] French Fries");
		    	System.out.println("Price: 80 Pesos");
		    	System.out.println("[4] Halo-Halo");
		    	System.out.println("Price: 90 Pesos");
		    	System.out.println("Select from 1 - 4 and if you don't want add ons press 0");
		    	op2 = order.nextInt();
		    	if (op2==1) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 120 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		            op =ask.next().charAt(0);
		    	}
		    	else if (op==2) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 120 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==3) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 120 + 80 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==4) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 120 + 90 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==0) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add =  money - 120;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else {
		    		System.out.println("Select From 1-4");
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	break;
		    case "yes":
		    	System.out.println("-----------------------------------------");
		    	System.out.println("---------------Add-ons-------------------");
		    	System.out.println("-----------------------------------------");
		    	System.out.println("[0] No Add ons");
		    	System.out.println("[1] Coca Cola");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[2] Sprite");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[3] French Fries");
		    	System.out.println("Price: 80 Pesos");
		    	System.out.println("[4] Halo-Halo");
		    	System.out.println("Price: 90 Pesos");
		    	System.out.println("Select from 1 - 4 and if you don't want add ons press 0");
		    	op2 = order.nextInt();
		    	if (op2==1) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 120 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==2) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 120 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==3) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 120 + 80 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==4) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 120 + 90 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==0) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add =  money - 120;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else {
		    		System.out.println("Select From 1-4");
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	break;
		    case "No":
		    	System.out.println("Take Your Time");
		    	 System.out.println("Do you want to continue Buying?, Y/N");
	              op =ask.next().charAt(0);
		    	break;
		    case "no":
		    	System.out.println("Take Your Time");
		    	 System.out.println("Do you want to continue Buying?, Y/N");
	              op =ask.next().charAt(0);
		    	break;
		    }
			break;
			
		case 2:
			System.out.println("-------------------------------------------");
			System.out.println("-------------Confirmation------------------");
			System.out.println("-------------------------------------------");
			System.out.println("[2] Chorizzo with green bell pepper and with pineapple");
			System.out.println("Price: 250 Pesos");
			System.out.println("Are you sure? Yes or No");
			String answerer2 = Objecker.nextLine();
			switch (answerer2) {
			case "Yes":
		    	System.out.println("-----------------------------------------");
		    	System.out.println("---------------Add-ons-------------------");
		    	System.out.println("-----------------------------------------");
		    	System.out.println("[1] Coca Cola");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[2] Sprite");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[3] French Fries");
		    	System.out.println("Price: 80 Pesos");
		    	System.out.println("[4] Halo-Halo");
		    	System.out.println("Price: 90 Pesos");
		    	System.out.println("Select from 1 - 4 and if you don't want add ons press 0");
		    	op2 = order.nextInt();
		    	if (op2==1) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 250 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op==2) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 250 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		              }
		    	else if (op2==3) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 250 + 80 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==4) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 250 + 90 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==0) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add =  money - 250;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else {
		    		System.out.println("Select From 1-4");
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	break;
		    case "yes":
		    	System.out.println("-----------------------------------------");
		    	System.out.println("---------------Add-ons-------------------");
		    	System.out.println("-----------------------------------------");
		    	System.out.println("[0] No Add ons");
		    	System.out.println("[1] Coca Cola");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[2] Sprite");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[3] French Fries");
		    	System.out.println("Price: 80 Pesos");
		    	System.out.println("[4] Halo-Halo");
		    	System.out.println("Price: 90 Pesos");
		    	System.out.println("Select from 1 - 4 and if you don't want add ons press 0");
		    	op2 = order.nextInt();
		    	if (op2==1) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 250 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==2) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 250 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==3) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 120 + 80 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==4) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 250 + 90 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==0) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add =  money - 250;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else {
		    		System.out.println("Select From 1-4");
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	break;
		    case "No":
		    	System.out.println("Take Your Time");
		    	 System.out.println("Do you want to continue Buying?, Y/N");
	              op =ask.next().charAt(0);
		    	break;
		    case "no":
		    	System.out.println("Take Your Time");
		    	 System.out.println("Do you want to continue Buying?, Y/N");
	              op =ask.next().charAt(0);
		    	break;
		    }
			
			break;
		case 3:
			System.out.println("-------------------------------------------");
			System.out.println("-------------Confirmation------------------");
			System.out.println("-------------------------------------------");
			System.out.println("[3] Peperoni with Super Dupper Cheeese Toppings");
			System.out.println("Price: 320 Pesos");
			System.out.println("Are you sure? Yes or No");
			String answerer3 = Objecker.nextLine();
			switch (answerer3) {
			case "Yes":
		    	System.out.println("-----------------------------------------");
		    	System.out.println("---------------Add-ons-------------------");
		    	System.out.println("-----------------------------------------");
		    	System.out.println("[1] Coca Cola");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[2] Sprite");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[3] French Fries");
		    	System.out.println("Price: 80 Pesos");
		    	System.out.println("[4] Halo-Halo");
		    	System.out.println("Price: 90 Pesos");
		    	System.out.println("Select from 1 - 4 and if you don't want add ons press 0");
		    	op2 = order.nextInt();
		    	if (op2==1) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 320 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op==2) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 320 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==3) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 320 + 80 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==4) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 320 + 90 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==0) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add =  money - 320;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else {
		    		System.out.println("Select From 1-4");
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	break;
		    case "yes":
		    	System.out.println("-----------------------------------------");
		    	System.out.println("---------------Add-ons-------------------");
		    	System.out.println("-----------------------------------------");
		    	System.out.println("[0] No Add ons");
		    	System.out.println("[1] Coca Cola");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[2] Sprite");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[3] French Fries");
		    	System.out.println("Price: 80 Pesos");
		    	System.out.println("[4] Halo-Halo");
		    	System.out.println("Price: 90 Pesos");
		    	System.out.println("Select from 1 - 4 and if you don't want add ons press 0");
		    	op2 = order.nextInt();
		    	if (op2==1) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 320 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==2) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 320 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==3) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 320 + 80 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==4) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 320 + 90 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==0) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add =  money - 320;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else {
		    		System.out.println("Select From 1-4");
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	break;
		    case "No":
		    	System.out.println("Take Your Time");
		    	System.out.println("Do you want to continue Buying?, Y/N");
	              op =ask.next().charAt(0);
		    	break;
		    case "no":
		    	System.out.println("Take Your Time");
		    	System.out.println("Do you want to continue Buying?, Y/N");
	              op =ask.next().charAt(0);
		    	break;
		    }

			break;
		case 4:
			System.out.println("-------------------------------------------");
			System.out.println("-------------Confirmation------------------");
			System.out.println("-------------------------------------------");
			System.out.println("[4] Veggie Pizza");
			System.out.println("Price: 200 Pesos");
			System.out.println("Are you sure? Yes or No");
			String answerer4 = Objecker.nextLine();
			switch (answerer4) {
			case "Yes":
		    	System.out.println("-----------------------------------------");
		    	System.out.println("---------------Add-ons-------------------");
		    	System.out.println("-----------------------------------------");
		    	System.out.println("[1] Coca Cola");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[2] Sprite");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[3] French Fries");
		    	System.out.println("Price: 80 Pesos");
		    	System.out.println("[4] Halo-Halo");
		    	System.out.println("Price: 90 Pesos");
		    	System.out.println("Select from 1 - 4 and if you don't want add ons press 0");
		    	op2 = order.nextInt();
		    	if (op2==1) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 200 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op==2) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 200 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==3) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 200 + 80 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==4) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 200 + 90 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==0) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add =  money - 200;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else {
		    		System.out.println("Select From 1-4");
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	break;
		    case "yes":
		    	System.out.println("-----------------------------------------");
		    	System.out.println("---------------Add-ons-------------------");
		    	System.out.println("-----------------------------------------");
		    	System.out.println("[0] No Add ons");
		    	System.out.println("[1] Coca Cola");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[2] Sprite");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[3] French Fries");
		    	System.out.println("Price: 80 Pesos");
		    	System.out.println("[4] Halo-Halo");
		    	System.out.println("Price: 90 Pesos");
		    	System.out.println("Select from 1 - 4 and if you don't want add ons press 0");
		    	op2 = order.nextInt();
		    	if (op2==1) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 200 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==2) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 200 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==3) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 200 + 80 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==4) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 200 + 90 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==0) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add =  money - 200;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else {
		    		System.out.println("Select From 1-4");
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	break;
		    case "No":
		    	System.out.println("Take Your Time");
		    	System.out.println("Do you want to continue Buying?, Y/N");
	              op =ask.next().charAt(0);
		    	break;
		    case "no":
		    	System.out.println("Take Your Time");
		    	System.out.println("Do you want to continue Buying?, Y/N");
	              op =ask.next().charAt(0);
		    	break;
		    }

			break;
		case 5:
			System.out.println("-------------------------------------------");
			System.out.println("-------------Confirmation------------------");
			System.out.println("-------------------------------------------");
			System.out.println("[5] Meat Pizza");
			System.out.println("Price: 300 Pesos");
			System.out.println("Are you sure? Yes or No");
			String answerer5 = Objecker.nextLine();
			switch (answerer5) {
			case "Yes":
		    	System.out.println("-----------------------------------------");
		    	System.out.println("---------------Add-ons-------------------");
		    	System.out.println("-----------------------------------------");
		    	System.out.println("[1] Coca Cola");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[2] Sprite");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[3] French Fries");
		    	System.out.println("Price: 80 Pesos");
		    	System.out.println("[4] Halo-Halo");
		    	System.out.println("Price: 90 Pesos");
		    	System.out.println("Select from 1 - 4 and if you don't want add ons press 0");
		    	op2 = order.nextInt();
		    	if (op2==1) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 300 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op==2) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 300 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==3) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 300 + 80 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==4) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 300 + 90 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==0) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add =  money - 300;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else {
		    		System.out.println("Select From 1-4");
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	break;
		    case "yes":
		    	System.out.println("-----------------------------------------");
		    	System.out.println("---------------Add-ons-------------------");
		    	System.out.println("-----------------------------------------");
		    	System.out.println("[0] No Add ons");
		    	System.out.println("[1] Coca Cola");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[2] Sprite");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[3] French Fries");
		    	System.out.println("Price: 80 Pesos");
		    	System.out.println("[4] Halo-Halo");
		    	System.out.println("Price: 90 Pesos");
		    	System.out.println("Select from 1 - 4 and if you don't want add ons press 0");
		    	op2 = order.nextInt();
		    	if (op2==1) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 300 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==2) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 300 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==3) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 300 + 80 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==4) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 300 + 90 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==0) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add =  money - 300;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else {
		    		System.out.println("Select From 1-4");
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	break;
		    case "No":
		    	System.out.println("Take Your Time");
		    	System.out.println("Do you want to continue Buying?, Y/N");
	              op =ask.next().charAt(0);
		    	break;
		    case "no":
		    	System.out.println("Take Your Time");
		    	System.out.println("Do you want to continue Buying?, Y/N");
	              op =ask.next().charAt(0);
		    	break;
		    }
			break;
		case 6:
			System.out.println("-------------------------------------------");
			System.out.println("-------------Confirmation------------------");
			System.out.println("-------------------------------------------");
			System.out.println("[6] Spicy PIZZA with peperoni, cheese, green bell pepper, and pineapple");
			System.out.println("Price: 400 Pesos");
			System.out.println("Are you sure? Yes or No");
			String answerer6 = Objecker.nextLine();
			switch (answerer6) {
			case "Yes":
		    	System.out.println("-----------------------------------------");
		    	System.out.println("---------------Add-ons-------------------");
		    	System.out.println("-----------------------------------------");
		    	System.out.println("[1] Coca Cola");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[2] Sprite");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[3] French Fries");
		    	System.out.println("Price: 80 Pesos");
		    	System.out.println("[4] Halo-Halo");
		    	System.out.println("Price: 90 Pesos");
		    	System.out.println("Select from 1 - 4 and if you don't want add ons press 0");
		    	op2 = order.nextInt();
		    	if (op2==1) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 400 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op==2) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 400 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==3) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 400 + 80 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==4) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 400 + 90 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==0) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add =  money - 400;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else {
		    		System.out.println("Select From 1-4");
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	break;
		    case "yes":
		    	System.out.println("-----------------------------------------");
		    	System.out.println("---------------Add-ons-------------------");
		    	System.out.println("-----------------------------------------");
		    	System.out.println("[0] No Add ons");
		    	System.out.println("[1] Coca Cola");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[2] Sprite");
		    	System.out.println("Price: 70 Pesos");
		    	System.out.println("[3] French Fries");
		    	System.out.println("Price: 80 Pesos");
		    	System.out.println("[4] Halo-Halo");
		    	System.out.println("Price: 90 Pesos");
		    	System.out.println("Select from 1 - 4 and if you don't want add ons press 0");
		    	op2 = order.nextInt();
		    	if (op2==1) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 400 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==2) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 400 + 70 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==3) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 400 + 80 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else if (op2==4) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add = 400 + 90 - money;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    	}
		    	else if (op2==0) {
		    		System.out.println("Enter Your Money Balance");
		    		money = total.nextInt();
		    		add =  money - 400;
		    		System.out.println("You Successfully Purchased");
		    		System.out.println("Your Total Balance is:" + add);
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	else {
		    		System.out.println("Select From 1-4");
		    		 System.out.println("Do you want to continue Buying?, Y/N");
		              op =ask.next().charAt(0);
		    	}
		    	break;
		    case "No":
		    	System.out.println("Take Your Time");
		    	 System.out.println("Do you want to continue Buying?, Y/N");
	              op =ask.next().charAt(0);
		    	break;
		    case "no":
		    	System.out.println("Take Your Time");
		    	 System.out.println("Do you want to continue Buying?, Y/N");
	              op =ask.next().charAt(0);
		    	break;
		    }
			break;
		default:
			System.out.println("Select From The Menu");
			 System.out.println("Do you want to continue Buying?, Y/N");
             op =ask.next().charAt(0);
			break;
		}
		
		
		
	}while(op =='Y'||op=='y'); 
    System.out.println("Close");
}
}
