package simplecalculator;
import java.util.Scanner;
public class calculator {
 public static void main(String args[]){
	 char op =0;
	 do {		 
	 Scanner select = new Scanner (System.in);
	 Scanner compute = new Scanner (System.in);
	 int num, n1, n2, addition, subtraction, multiplication, division;
	 System.out.println("-------------------------------------------------------------------");
	 System.out.println("                       Java Calculator                             ");
	 System.out.println("-------------------------------------------------------------------");
	 System.out.println("[1]Addition");
	 System.out.println("[2]Subtraction");
	 System.out.println("[3]Multiplication");
	 System.out.println("[4]Division");
	 num = select.nextInt();
	 switch (num) {
	 case 1: 
		 System.out.println("Enter a first number");
		 n1 = compute.nextInt();
		 System.out.println("Enter a second number");
		 n2= compute.nextInt();
		 addition = n1 + n2;
		 System.out.println(n1 + "+"  + n2 + "=" +addition); 
		 System.out.println("Do you want to continue, YES/NO");
         op = select.next().charAt(0);
        
		 break;
	 case 2:
		 System.out.println("Enter a first number");
		 n1 = compute.nextInt();
		 System.out.println("Enter a second number");
		 n2= compute.nextInt();
		 subtraction = n1 - n2;
		 System.out.println(n1 + "-"  + n2 + "=" + subtraction); 
		 System.out.println("Do you want to continue, YES/NO");
         op =select.next().charAt(0);
       
		 break;
	 case 3: 
		 System.out.println("Enter a first number");
		 n1 = compute.nextInt();
		 System.out.println("Enter a second number");
		 n2= compute.nextInt();
		 multiplication = n1 * n2;
		 System.out.println(n1 + "*"  + n2 + "=" + multiplication); 
		 System.out.println("Do you want to continue, YES/NO");
         op =select.next().charAt(0);
         
		 break;
	 case 4:
		 System.out.println("Enter a first number");
		 n1 = compute.nextInt();
		 System.out.println("Enter a second number");
		 n2= compute.nextInt();
		 division = n1 / n2;
		 System.out.println(n1 + "÷"  + n2 + "=" + division); 
		 System.out.println("Do you want to continue, YES/NO");
         op =select.next().charAt(0);;
        
		 break;
	default:
		System.out.println("Select from 1-4");
		System.out.println("Do you want to continue, YES/NO");
        op =select.next().charAt(0);
        break;
	 }
	 
 } while(op =='Y'||op=='y'); 
 System.out.println("Close");
}
}
