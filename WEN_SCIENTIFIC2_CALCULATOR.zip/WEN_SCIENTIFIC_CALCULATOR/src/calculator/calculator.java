package calculator;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import SCIENTIFIC.SCI_CALCULATOR;

import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import java.awt.Toolkit;
import java.awt.Window.Type;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class calculator {
	static double a=0,b=0,result=0;
	static int operator=0;
	public JFrame frmWenCalculator;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					calculator window = new calculator();
					window.frmWenCalculator.setVisible(true);
					window.frmWenCalculator.setLocationRelativeTo(null);
					UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws UnsupportedLookAndFeelException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 */
	public calculator() throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws UnsupportedLookAndFeelException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 */
	private void initialize() throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		frmWenCalculator = new JFrame();
		frmWenCalculator.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\JAVA_ECLIPSE\\WEN_SCIENTIFIC_CALCULATOR\\src\\scientific-calculator.png"));
		frmWenCalculator.setTitle("WEN CALCULATOR");
		frmWenCalculator.setFont(new Font("Gill Sans Ultra Bold Condensed", Font.PLAIN, 18));
		frmWenCalculator.setBackground(new Color(0, 64, 128));
		frmWenCalculator.getContentPane().setBackground(new Color(10, 38, 71));
		frmWenCalculator.getContentPane().setLayout(null);
		Border border = new LineBorder(Color.BLACK, 4, true);
		
		textField = new JTextField();
		Border border1 = new LineBorder(Color.BLUE, 4, true);
		textField.setBorder(border1);
		textField.setFont(new Font("Rockwell Extra Bold", Font.PLAIN, 30));
		textField.setText("0");
		textField.setBounds(33, 88, 374, 55);
		frmWenCalculator.getContentPane().add(textField);
		textField.setColumns(10);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 64, 128));
		panel.setBounds(33, 12, 374, 64);
		frmWenCalculator.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("WEN CALCULATOR V1");
		lblNewLabel.setBounds(53, 25, 260, 28);
		panel.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Segoe UI Emoji", Font.BOLD, 25));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 64, 128));
		panel_1.setBounds(33, 155, 374, 610);
		frmWenCalculator.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnNewButton_1_4 = new JButton("4");
		btnNewButton_1_4.setBounds(12, 216, 89, 71);
		panel_1.add(btnNewButton_1_4);
		btnNewButton_1_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_1_4)
					textField.setText(textField.getText().concat("4"));
			}
		});
		btnNewButton_1_4.setForeground(Color.WHITE);
		btnNewButton_1_4.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_4.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton_1_5 = new JButton("5");
		btnNewButton_1_5.setBounds(140, 216, 89, 71);
		panel_1.add(btnNewButton_1_5);
		btnNewButton_1_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()== btnNewButton_1_5)
					textField.setText(textField.getText().concat("5"));
			}
		});
		btnNewButton_1_5.setForeground(Color.WHITE);
		btnNewButton_1_5.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_5.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton_1_6 = new JButton("6");
		btnNewButton_1_6.setBounds(273, 216, 89, 71);
		panel_1.add(btnNewButton_1_6);
		btnNewButton_1_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()== btnNewButton_1_6)
					textField.setText(textField.getText().concat("6"));
			}
		});
		btnNewButton_1_6.setForeground(Color.WHITE);
		btnNewButton_1_6.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_6.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton_1_8 = new JButton("8");
		btnNewButton_1_8.setBounds(140, 315, 89, 71);
		panel_1.add(btnNewButton_1_8);
		btnNewButton_1_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()== btnNewButton_1_8)
					textField.setText(textField.getText().concat("8"));
			}
		});
		btnNewButton_1_8.setForeground(Color.WHITE);
		btnNewButton_1_8.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_8.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton_1_7 = new JButton("7");
		btnNewButton_1_7.setBounds(12, 315, 89, 71);
		panel_1.add(btnNewButton_1_7);
		btnNewButton_1_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()== btnNewButton_1_7)
					textField.setText(textField.getText().concat("7"));
			}
		});
		btnNewButton_1_7.setForeground(Color.WHITE);
		btnNewButton_1_7.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_7.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton_1_9 = new JButton("9");
		btnNewButton_1_9.setBounds(273, 315, 89, 71);
		panel_1.add(btnNewButton_1_9);
		btnNewButton_1_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()== btnNewButton_1_9)
					textField.setText(textField.getText().concat("9"));
			}
		});
		btnNewButton_1_9.setForeground(Color.WHITE);
		btnNewButton_1_9.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_9.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton_1_10 = new JButton("0");
		btnNewButton_1_10.setBounds(12, 411, 89, 71);
		panel_1.add(btnNewButton_1_10);
		btnNewButton_1_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()== btnNewButton_1_10)
					textField.setText(textField.getText().concat("0"));
			}
		});
		btnNewButton_1_10.setForeground(Color.WHITE);
		btnNewButton_1_10.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_10.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton_1_10_1 = new JButton("+");
		btnNewButton_1_10_1.setBounds(140, 411, 89, 71);
		panel_1.add(btnNewButton_1_10_1);
		btnNewButton_1_10_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_1_10_1)
				{
				a=Double.parseDouble(textField.getText());
				operator=1;
				textField.setText("");
				}
			}
		});
		btnNewButton_1_10_1.setForeground(Color.WHITE);
		btnNewButton_1_10_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_10_1.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton_1_11 = new JButton("-");
		btnNewButton_1_11.setBounds(273, 411, 89, 71);
		panel_1.add(btnNewButton_1_11);
		btnNewButton_1_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_1_11)
				{
				a=Double.parseDouble(textField.getText());
				operator=2;
				textField.setText("");
				}
				
			}
		});
		btnNewButton_1_11.setForeground(Color.WHITE);
		btnNewButton_1_11.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_11.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton_1_12 = new JButton("X");
		btnNewButton_1_12.setBounds(12, 507, 89, 71);
		panel_1.add(btnNewButton_1_12);
		btnNewButton_1_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_1_12)
				{
				a=Double.parseDouble(textField.getText());
				operator=3;
				textField.setText("");
				}
			}
		});
		btnNewButton_1_12.setForeground(Color.WHITE);
		btnNewButton_1_12.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_12.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton_1_13 = new JButton("÷");
		btnNewButton_1_13.setBounds(140, 507, 89, 71);
		panel_1.add(btnNewButton_1_13);
		btnNewButton_1_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_1_13)
				{
				a=Double.parseDouble(textField.getText());
				operator=4;
				textField.setText("");
				}
			}
		});
		btnNewButton_1_13.setForeground(Color.WHITE);
		btnNewButton_1_13.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_13.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton_1_14 = new JButton("=");
		btnNewButton_1_14.setBounds(273, 507, 89, 71);
		panel_1.add(btnNewButton_1_14);
		btnNewButton_1_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_1_14)
				{
				b=Double.parseDouble(textField.getText());
				switch(operator)
				{
				case 1: result=a+b;
				break;
				case 2: result=a-b;
				break;
				case 3: result=a*b;
				break;
				case 4: result=a/b;
				break;
				default: result=0;
				}
				textField.setText(""+result);
				}
				
				}
			
		});
		btnNewButton_1_14.setForeground(Color.WHITE);
		btnNewButton_1_14.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_14.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton_1 = new JButton("1");
		btnNewButton_1.setBounds(12, 121, 89, 71);
		panel_1.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_1)
					textField.setText(textField.getText().concat("1"));
			}
		});
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton_1_1 = new JButton("2");
		btnNewButton_1_1.setBounds(140, 121, 89, 71);
		panel_1.add(btnNewButton_1_1);
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_1_1)
					textField.setText(textField.getText().concat("2"));
			}
		});
		btnNewButton_1_1.setForeground(Color.WHITE);
		btnNewButton_1_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_1.setBackground(new Color(255, 128, 0));
		
		
		JButton btnNewButton_1_2 = new JButton("3");
		btnNewButton_1_2.setBounds(273, 121, 89, 71);
		panel_1.add(btnNewButton_1_2);
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_1_2)
					textField.setText(textField.getText().concat("3"));
			}
		});
		btnNewButton_1_2.setForeground(Color.WHITE);
		btnNewButton_1_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 31));
		btnNewButton_1_2.setBackground(new Color(255, 128, 0));
		
		JButton btnNewButton = new JButton("Clear");
		btnNewButton.setBounds(24, 47, 156, 55);
		panel_1.add(btnNewButton);
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(255, 128, 0));
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setBounds(215, 47, 147, 55);
		panel_1.add(btnDelete);
		btnDelete.setForeground(new Color(255, 255, 255));
		btnDelete.setBackground(new Color(255, 128, 0));
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Basic Calculator", "Scientific Calculator"}));
		comboBox.setForeground(Color.WHITE);
		comboBox.setFont(new Font("Verdana", Font.BOLD, 12));
		comboBox.setBackground(new Color(255, 128, 0));
		comboBox.setBounds(163, 11, 188, 25);
		comboBox.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Get the selected item from the JComboBox
		        String selectedItem = (String)comboBox.getSelectedItem();

		        // If the selected item is "Basic Calculator", show a JOptionPane asking the user if they want to proceed to JFrame2
		        if (selectedItem.equals("Basic Calculator")) {
		        	try {
						UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
					} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
							| UnsupportedLookAndFeelException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
		            int option = JOptionPane.showConfirmDialog(frmWenCalculator, "Do you want to proceed to Basic Calculator?", "Confirmation", JOptionPane.YES_NO_OPTION);
		            if (option == JOptionPane.YES_OPTION) {
		                // If the user clicked Yes, create a new JFrame2 and pass the ArrayList as a parameter
		            	calculator window = null;
						try {
							window = new calculator();
							window.frmWenCalculator.setLocationRelativeTo(null);
							window.frmWenCalculator.setVisible(true);
							frmWenCalculator.dispose();
						} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
								| UnsupportedLookAndFeelException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
		            	
		            }
		        }
		        // If the selected item is "Scientific Calculator", do something else
		        else if (selectedItem.equals("Scientific Calculator")) {
		            // Do something else
		        	try {
						UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
					} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
							| UnsupportedLookAndFeelException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
		        	 int option = JOptionPane.showConfirmDialog(frmWenCalculator, "Do you want to proceed to Scientific Calculator?", "Confirmation", JOptionPane.YES_NO_OPTION);
			            if (option == JOptionPane.YES_OPTION) {
			                // If the user clicked Yes, create a new JFrame2 and pass the ArrayList as a parameter
			            	SCI_CALCULATOR frame = null;
							try {
								frame = new SCI_CALCULATOR();
								frame.setVisible(true);
								frame.setResizable(false);;
								frame.setLocationRelativeTo(null);

								frmWenCalculator.dispose();
							} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
									| UnsupportedLookAndFeelException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							
			            }
		        }
		    }
		});
		panel_1.add(comboBox);
		
		JLabel lblNewLabel_1 = new JLabel("MODE");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Verdana", Font.BOLD, 12));
		lblNewLabel_1.setBounds(114, 8, 55, 30);
		panel_1.add(lblNewLabel_1);
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnDelete)
				{
				String s=textField.getText();
				textField.setText("");
				for(int i=0;i<s.length()-1;i++)
					textField.setText(textField.getText()+s.charAt(i));
				}
			}
		});
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton)
					textField.setText("");
			}
		});
		frmWenCalculator.setBounds(100, 100, 450, 823);
		frmWenCalculator.setResizable(false);
		frmWenCalculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent e) {
		
				}
}
