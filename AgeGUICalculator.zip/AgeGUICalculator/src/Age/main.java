package Age;

import java.awt.Image;
import java.awt.Toolkit;

public class main {
public static void main(String []args) {
	age1 main =new age1();
	Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\AgeGUICalculator\\src\\Age\\baby.png");    
	main.setIconImage(icon);  
}
}
