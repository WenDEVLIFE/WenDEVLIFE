package Age;
import java.time.LocalDate;  
import java.time.Period;  
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class age1 extends JFrame implements ActionListener, MouseListener{
	final int FRAME_WIDTH = 1024;
	final int FRAME_HEIGHT = 786;
	JPanel Titlebar;
	JTextField Age, result1;
	JLabel result;
	JLabel agetxt;
	JLabel info2;
	JPanel Form;
	JLabel title;
	JButton reveal_age;
	JButton exit, min, max, logo;
	JMenuItem maxm, minm, exitm, lockm;
	mouselistener1 mml = new mouselistener1(this);
	ImageIcon exit_focused = new ImageIcon(new ImageIcon("src/Age/exited.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon exit_ico = new ImageIcon(new ImageIcon("src/Age/exit.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon minimize_focused = new ImageIcon(new ImageIcon("src/Age/minimized.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon minimize_ico = new ImageIcon(new ImageIcon("src/Age/minimize.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon maximize_focused = new ImageIcon(new ImageIcon("src/Age/maximized.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	ImageIcon maximize_ico = new ImageIcon(new ImageIcon("src/Age/maximize.png").getImage()
			.getScaledInstance(15, 15, Image.SCALE_AREA_AVERAGING));
	
age1(){
	// to remove the TITLEBAR
	this.setUndecorated(true);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setLayout(null);
	//background
	ImageIcon background_image = new ImageIcon(new ImageIcon("src/Age/background.jpg").getImage().getScaledInstance(FRAME_WIDTH, FRAME_HEIGHT, Image.SCALE_SMOOTH));
	JLabel background_Label = new JLabel(background_image);
	background_Label.setBounds(0,0,FRAME_WIDTH, FRAME_HEIGHT);
	//buttons
	exit = new JButton();
	exit.setIcon(exit_ico);
	exit.setOpaque(false);
	exit.setBorderPainted(false);
	exit.setContentAreaFilled(false);
	exit.setFocusable(false);
	exit.setBounds(990,10,15,15);
	exit.addMouseListener(this);
	this.add(exit);
	//title
	title = new JLabel("Age Calculator By:WenDevLife");
	title.setBounds(140,-80,150,400);
	title.setForeground(new Color (255,255,255));
	title.setFont(new Font("Sans-Serif", Font.PLAIN, 10));
	//logo
	logo = new JButton();
	ImageIcon l = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\AgeGUICalculator\\src\\Age\\age.png").getImage().getScaledInstance(30,30, Image.SCALE_SMOOTH));
	logo.setIcon(l);
	logo.setBounds(100,105,30,30);
	logo.setFocusable(false);
	logo.setOpaque(false);
	logo.setContentAreaFilled(false);
	logo.setBorderPainted(false);
	
	min = new JButton();
	min.setIcon(minimize_ico);
	min.setOpaque(false);
	min.setBorderPainted(false);
	min.setContentAreaFilled(false);
	min.setFocusable(false);
	min.setBounds(930,10,15,15);
	min.addMouseListener(this);
	this.add(min);
	
	max = new JButton();
	max.setIcon(maximize_ico);
	max.setOpaque(false);
	max.setBorderPainted(false);
	max.setContentAreaFilled(false);
	max.setFocusable(false);
	max.setBounds(960,10,15,15);
	max.addMouseListener(this);
	this.add(max);
	//title2
	info2 = new JLabel("Age Credentials");
	info2.setBounds(300,-150,300,400);
	info2.setFont(new Font("Sans-Serif", Font.PLAIN,35));
	info2.setForeground(new Color (255,255,255));
	
	agetxt = new JLabel("Enter date of birth in YYYY-MM-DD format:");
	agetxt.setBounds(20,-300,600,900);
	agetxt.setFont(new Font("Sans-Serif", Font.PLAIN, 25));
	agetxt.setForeground(new Color (255,255,255));
	Age = new JTextField(4);
	//Changing JTEXTFIELD BACKGROUND
	Color color1 = Color.BLACK;
	Age.setBackground(color1);
	Age.setFont(new Font("Sans-Serif", Font.PLAIN, 20));
	Age.setForeground(new Color (0,100,0));
	Age.setBounds(500,130,300,50);
	
	result = new JLabel("You're Age is:");
	result.setBounds(300,80,300,400);
	result.setFont(new Font("Sans-Serif", Font.PLAIN, 25));
	result.setForeground(new Color (255,255,255));
	result1 = new JTextField(4);
	result1.setEditable(false);
	//Changing JTEXTFIELD BACKGROUND
	Color color2 = Color.BLACK;
	result1.setBackground(color2);
	result1.setFont(new Font("Sans-Serif", Font.PLAIN, 20));
	result1.setForeground(new Color (0,100,0));
	result1.setBounds(500,250,300,50);
	//Navbar
	Titlebar = new JPanel();
	Titlebar.setLayout(new BorderLayout(20, 15));
	Titlebar.setBackground(new Color(0,0,255));
	Titlebar.setBounds(-90,-100,1400,140);
	Border border1 = new LineBorder(Color.CYAN, 4, true);
	Titlebar.setBorder(border1);
	Titlebar.add(logo);
	Titlebar.add(title);
	Titlebar.setAlignmentX(JPanel.TOP_ALIGNMENT);
	Titlebar.setLayout(null);

	 reveal_age = new JButton("Reveal Age");
	 reveal_age.setBackground(Color.RED);
	 reveal_age.setFont(new Font("Sans-Serif", Font.PLAIN,20));
	 reveal_age.setForeground(new Color (255,255,255));
	 reveal_age.setBounds(300,400,280,80); 
	 reveal_age.addActionListener(this);
	//Form
	Form = new JPanel();
	Form.setBackground(new Color(0,0,255));
	Form.setBounds(80,100,900,600); 
	Form.setAlignmentX(JPanel.CENTER_ALIGNMENT);
	Border border = new LineBorder(Color.CYAN, 4, true);
	Form.setBorder(border);
	Form.setLayout(null);
	Form.add(agetxt);
	Form.add(Age);
	Form.add(result);
	Form.add(result1);
	Form.add(info2);
	Form.add(reveal_age);
	
	
	this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
	this.add(Titlebar);
	this.add(Form);
	this.add(background_Label);
	this.setVisible(true);
	this.setVisible(true);
	this.setResizable(false);
	this.setLocationRelativeTo(null);
	this.setResizable(false);
	this.addMouseListener(mml);  this.addMouseMotionListener(mml);
}

@Override
public void mouseClicked(MouseEvent e) {
	if(e.getSource()==exit) this.dispose();
	if(e.getSource()==min) this.setState(Frame.ICONIFIED);
	if(e.getSource()==max) this.setState(Frame.MAXIMIZED_BOTH);
	
}

@Override
public void mousePressed(MouseEvent e) {

	if(e.getSource()==exit) exit.setIcon(exit_focused);
	if(e.getSource()==max) max.setIcon(maximize_focused);
	if(e.getSource()==min) min.setIcon(minimize_focused);
}

@Override
public void mouseReleased(MouseEvent e) {
	
	if(e.getSource()==exit) exit.setIcon(exit_ico);
	if(e.getSource()==max) max.setIcon(maximize_ico);
	if(e.getSource()==min) min.setIcon(minimize_ico);
	
}

@Override
public void mouseEntered(MouseEvent e) {
	if(e.getSource()==exit) exit.setIcon(exit_focused);
	if(e.getSource()==max) max.setIcon(maximize_focused);
	if(e.getSource()==min) min.setIcon(minimize_focused);
	
	
	
}

@Override
public void mouseExited(MouseEvent e) {
	if(e.getSource()==exit) exit.setIcon(exit_ico);
	if(e.getSource()==max) max.setIcon(maximize_ico);
	if(e.getSource()==min) min.setIcon(minimize_ico);
	
}

@Override
public void actionPerformed(ActionEvent e) {

	if(e.getSource()==reveal_age) {
		 String s1=Age.getText();  
		LocalDate dob = LocalDate.parse(s1);
		result1.setText(+calculateAge(dob) + " Years old");  
	}
	
}
//the method calculates the age  
public static int calculateAge(LocalDate dob)   
{  
//creating an instance of the LocalDate class and invoking the now() method      
//now() method obtains the current date from the system clock in the default time zone      
LocalDate curDate = LocalDate.now();  
//calculates the amount of time between two dates and returns the years  
if ((dob != null) && (curDate != null))   
{  
return Period.between(dob, curDate).getYears();  
}  
else  
{  
return 0;  
}  
}
}
