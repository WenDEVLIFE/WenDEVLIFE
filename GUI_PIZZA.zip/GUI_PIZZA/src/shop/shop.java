package shop;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import complain.complain;
import home.home;
import loginmain.loginpizz;
import user.user;

public class shop extends JFrame implements ActionListener {
	JPanel sidebar;
	int df= 0;
	JPanel navbar;
	JPanel order;
	JPanel homes;
	JPanel complaints;
	JPanel Orderbar;
	JPanel paymentbar;
	
	
	//labels
	
	JLabel log;
	JLabel hehe;
	JLabel title;
	JLabel money1;
	JLabel troll;
	JLabel shop1;
	JLabel balance;
	JLabel or;
	JLabel h1;
	JLabel cl;
	JLabel fod1;
	JLabel fod2;
	JLabel fod3;
	JLabel fod4;
	JLabel fod5;
	JLabel fod6;
	JLabel fod7;
	JLabel fod8;
	JLabel fod9;
	JLabel fod10;
	
	JLabel Price1;
	JLabel Price2;
	JLabel Price3;
	JLabel Price4;
	JLabel Price5;
	JLabel Price6;
	JLabel Price7;
	JLabel Price8;
	JLabel Price9;
	JLabel Price10;
	JLabel balae;
	JLabel user1;
	JLabel atm;
	JLabel c2;
	
	
	

	
	//buttons
	JButton pera;
	JButton pizza;
	JButton logout;
	JButton home;
	JButton shop;
	JButton trolley;
	JButton comp;
	JButton Food1;
	JButton Add;
	JButton Cancel;
	JButton paynow;
	JButton k;
	JButton user;
	JButton complain;

	
	
	//scrollbar
	JScrollBar meow;
	
	//TextField
	JTextField p1;
	JTextField p2;
	JTextField p3;
	JTextField p4;
	JTextField p5;
	JTextField p6;
	JTextField p7;
	JTextField p8;
	JTextField p9;
	JTextField p10;
	JTextField Price;
	JTextField Gui1;
	JTextField Gui2;
/**
 * 
 */
public shop(){
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setLayout(null);
	logout= new JButton("");
	ImageIcon i = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\logout.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
	logout.setIcon(i);
	logout.setBounds(800,10, 51, 51);
	logout.setFocusable(false);
	logout.setOpaque(false);
	logout.setContentAreaFilled(false);
	logout.setBorderPainted(false);
	logout.addActionListener(this);
	
	
    
	//sidebar
	sidebar= new JPanel();
	sidebar.setBackground(new Color(217, 30, 24));
	sidebar.setBounds(-100,80,200,1300);  
	
	home = new JButton();
	ImageIcon h = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\homes1.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
	home.setIcon(h);
	home.setBounds(120,30, 51, 51);
	home.setFocusable(false);
	home.setOpaque(false);
	home.setContentAreaFilled(false);
	home.setBorderPainted(false);
	home.addActionListener(this);
	
	h1 = new JLabel("Home");
	h1.setBounds(120,50, 200, 91);
	h1.setForeground(new Color (255,255,255));
	h1.setFont(new Font("Verdana", Font.PLAIN, 16));
	
	shop = new JButton();
	ImageIcon s = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\trolley.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
	shop.setIcon(s);
	shop.setBounds(110,150, 51, 51);
	shop.setFocusable(false);
	shop.setOpaque(false);
	shop.setContentAreaFilled(false);
	shop.setBorderPainted(false);
	shop.addActionListener(this);
	shop1 = new JLabel("Shop");
	shop1 .setBounds(120,170, 200, 91);
	shop1 .setForeground(new Color (255,255,255));
	shop1 .setFont(new Font("Verdana", Font.PLAIN, 16));

	complain = new JButton();
	ImageIcon sc = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\service.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
	complain.setIcon(sc);
	complain.setBounds(120,270, 51, 51);
	complain.setFocusable(false);
	complain.setOpaque(false);
	complain.setContentAreaFilled(false);
	complain.setBorderPainted(false);
	complain.addActionListener(this);
	
	c2 = new JLabel("Feedback");
	c2 .setBounds(110,290, 200, 91);
	c2 .setForeground(new Color (255,255,255));
	c2 .setFont(new Font("Verdana", Font.PLAIN, 16));
	

	user = new JButton();
	ImageIcon l = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\user.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
	user.setIcon(l);
	user.setBounds(120,400, 51, 51);
	user.setFocusable(false);
	user.setOpaque(false);
	user.setContentAreaFilled(false);
	user.setBorderPainted(false);
	user.addActionListener(this);
	
	user1 = new JLabel("User info");
	user1 .setBounds(110,420, 200, 91);
	user1.setForeground(new Color (255,255,255));
	user1.setFont(new Font("Verdana", Font.PLAIN, 16));
	
	sidebar.add(home);
	sidebar.add(h1);
	sidebar.add(shop);
	sidebar.add(shop1);
	sidebar.add(complain);
	sidebar.add(c2);
	sidebar.add(user);
	sidebar.add(user1);
	sidebar.setAlignmentX(JPanel.LEFT_ALIGNMENT);
	sidebar.setLayout(null);
	
			
	//navbar
	navbar= new JPanel();
	navbar.setBackground(new Color(217, 30, 24));
	navbar.setBounds(0,0,1200,80);  
	
	pizza= new JButton("");
	ImageIcon e = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\piz.png").getImage().getScaledInstance(91, 91, Image.SCALE_SMOOTH));
	pizza.setIcon(e);
	pizza.setBounds(10,-5, 91, 91);
	pizza.setFocusable(false);
	pizza.setOpaque(false);
	pizza.setContentAreaFilled(false);
	pizza.setBorderPainted(false);
	
	title = new JLabel("Pizza Ordering System");
	title.setBounds(120,-170, 400, 400);
	title.setForeground(new Color (255,255,255));
	title.setFont(new Font("Verdana", Font.PLAIN, 35));
	
	log = new JLabel("Logout");
	log.setBounds(860,-10, 200, 91);
	log.setForeground(new Color (255,255,255));
	log.setFont(new Font("Verdana", Font.PLAIN, 16));
	
	navbar.add(pizza);
	navbar.add(title);
	navbar.add(logout);
	navbar.add(log);
	navbar.setAlignmentX(JPanel.LEFT_ALIGNMENT);
	navbar.setLayout(null);
	
	homes= new JPanel();
	homes.setBackground(new Color(249, 105, 14));
	homes.setBounds(110,110,880,50);  
	
	hehe = new JLabel("Shop");
	hehe.setBounds(1,-180, 400, 400);
	hehe.setForeground(new Color (255,255,255));
	hehe.setFont(new Font("Verdana", Font.PLAIN, 30));
	k = new JButton ("");
	ImageIcon q = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\how.png").getImage().getScaledInstance(31, 31, Image.SCALE_SMOOTH));
	k.setIcon(q);
	k.setFocusable(false);
	k.setOpaque(false);
	k.setContentAreaFilled(false);
	k.setBorderPainted(false);
	k.setForeground(new Color (255,255,255));
	k.setBounds(750,10, 31, 31);
	k.setFont(new Font("Verdana", Font.PLAIN, 30));
	k.addActionListener(this);
	
	homes.add(hehe);
	homes.add(k);
	homes.setAlignmentX(JPanel.LEFT_ALIGNMENT);
	homes.setLayout(null);
	
	Orderbar= new JPanel();
	Orderbar.setBackground(new Color(0,0,255));
	Orderbar.setBounds(110,180,880,300);  
	//food1
	fod1 = new JLabel("Regular Pizza");
	fod1.setBounds(10,-180, 400, 400);
	fod1.setForeground(new Color (255,255,255));
	fod1.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	p1 = new JTextField();
	p1.setBounds(110,10, 80, 30);
	p1.setFont(new Font("Verdana", Font.PLAIN, 14));
	p1.setText(""+0);
	
	Price1 = new JLabel("P 100 each");
	Price1.setBounds(200,-180, 400, 400);
	Price1.setForeground(new Color (255, 255, 7));
	Price1.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	// food2
	fod2 = new JLabel("Meaty Pizza");
	fod2.setBounds(10,-130, 400, 400);
	fod2.setForeground(new Color (255,255,255));
	fod2.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	Price2 = new JLabel("P 150 each");
	Price2.setBounds(200,-130, 400, 400);
	Price2.setForeground(new Color (255, 255, 7));
	Price2.setFont(new Font("Verdana", Font.PLAIN, 14));

	
	p2 = new JTextField();
	p2.setBounds(110,60, 80, 30);
	p2.setFont(new Font("Verdana", Font.PLAIN, 14));
	p2.setText(""+0);
	
	//food 3
	fod3 = new JLabel("Cheese Pizza");
	fod3.setBounds(10,-80, 400, 400);
	fod3.setForeground(new Color (255,255,255));
	fod3.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	Price3 = new JLabel("P 210 each");
	Price3.setBounds(200,-80, 400, 400);
	Price3.setForeground(new Color (255, 255, 7));
	Price3.setFont(new Font("Verdana", Font.PLAIN, 14));

	
	p3 = new JTextField();
	p3.setBounds(110, 110, 80, 30);
	p3.setFont(new Font("Verdana", Font.PLAIN, 14));
	p3.setText(""+0);
	
	//food 4
	fod4 = new JLabel("Hawaiian Pizza");
	fod4.setBounds(5,-30, 400, 400);
	fod4.setForeground(new Color (255,255,255));
	fod4.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	Price4 = new JLabel("P 300 each");
	Price4.setBounds(200,-30, 400, 400);
	Price4.setForeground(new Color (255, 255, 7));
	Price4.setFont(new Font("Verdana", Font.PLAIN, 14));

	
	p4 = new JTextField();
	p4.setBounds(110, 160, 80, 30);
	p4.setFont(new Font("Verdana", Font.PLAIN, 14));
	p4.setText(""+0);
	//foood 5
	fod5 = new JLabel("Crust Pizza");
	fod5.setBounds(5,20, 400, 400);
	fod5.setForeground(new Color (255,255,255));
	fod5.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	Price5 = new JLabel("P 450 each");
	Price5.setBounds(200,20, 400, 400);
	Price5.setForeground(new Color (255, 255, 7));
	Price5.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	p5= new JTextField();
	p5.setBounds(110, 210, 80, 30);
	p5.setFont(new Font("Verdana", Font.PLAIN, 14));
	p5.setText(""+0);
	
	p6 = new JTextField();
	p6.setBounds(500, 10, 80, 30);
	p6.setFont(new Font("Verdana", Font.PLAIN, 14));
	p6.setText(""+0);
	//foood 6
	fod6 = new JLabel("Veggie Pizza");
	fod6.setBounds(400,-180, 400, 400);
	fod6.setForeground(new Color (255,255,255));
	fod6.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	Price6 = new JLabel("P 150 each");
	Price6.setBounds(600,-180, 400, 400);
	Price6.setForeground(new Color (255, 255, 7));
	Price6.setFont(new Font("Verdana", Font.PLAIN, 14));
	//foood 7
	p7 = new JTextField();
	p7.setBounds(500, 60, 80, 30);
	p7.setFont(new Font("Verdana", Font.PLAIN, 14));
	p7.setText(""+0);
	
	fod7 = new JLabel("BBQ Chicken Pizza");
	fod7.setBounds(360,-130, 400, 400);
	fod7.setForeground(new Color (255,255,255));
	fod7.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	Price7 = new JLabel("P 500 each");
	Price7.setBounds(600,-130, 400, 400);
	Price7.setForeground(new Color (255, 255, 7));
	Price7.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	p8 = new JTextField();
	p8.setBounds(500,110, 80, 30);
	p8.setFont(new Font("Verdana", Font.PLAIN, 14));
	p8.setText(""+0);
	
	fod8 = new JLabel("Buffalo Pizza");
	fod8.setBounds(360,-80, 400, 400);
	fod8.setForeground(new Color (255,255,255));
	fod8.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	Price8 = new JLabel("P 700 each");
	Price8.setBounds(600,-80, 400, 400);
	Price8.setForeground(new Color (255, 255, 7));
	Price8.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	
	p9 = new JTextField();
	p9.setBounds(500, 160, 80, 30);
	p9.setFont(new Font("Verdana", Font.PLAIN, 14));
	p9.setText(""+0);
	
	fod9 = new JLabel(" The Works Pizza");
	fod9.setBounds(360,-30, 400, 400);
	fod9.setForeground(new Color (255,255,255));
	fod9.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	Price9 = new JLabel("P 800 each");
	Price9.setBounds(600,-30, 400, 400);
	Price9.setForeground(new Color (255, 255, 7));
	Price9.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	p10 = new JTextField();
	p10.setBounds(500, 210, 80, 30);
	p10.setFont(new Font("Verdana", Font.PLAIN, 14));
	p10.setText(""+0);
	
	fod10 = new JLabel("Margherita Pizza");
	fod10.setBounds(360,20, 400, 400);
	fod10.setForeground(new Color (255,255,255));
	fod10.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	Price10 = new JLabel("P 750 each");
	Price10.setBounds(600,20, 400, 400);
	Price10.setForeground(new Color (255, 255, 7));
	Price10.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	Add = new JButton("Add all");
	Add.setBounds(300,250, 100, 40);
	Add.setForeground(new Color (255, 255, 255));
	Add.setBackground(new Color (0, 255, 0));
	Add.setFont(new Font("Verdana", Font.PLAIN, 14));
	Add.addActionListener(this);
	
	Cancel = new JButton("Cancel All");
	Cancel.setBounds(450,250, 100, 40);
	Cancel.setForeground(new Color (255, 255, 255));
	Cancel.setBackground(new Color (255,0,0));
	Cancel.setFont(new Font("Verdana", Font.PLAIN, 14));
	Cancel.addActionListener(this);
	Border payment1 = new LineBorder(Color.ORANGE, 4, true);
	Orderbar.setBorder(payment1);
	Orderbar.add(fod1);
	Orderbar.add(Price1);
	Orderbar.add(p1);
	Orderbar.add(fod2);
	Orderbar.add(Price2);
	Orderbar.add(p2);
	Orderbar.add(fod3);
	Orderbar.add(p3);
	Orderbar.add(Price3);
	Orderbar.add(fod4);
	Orderbar.add(p4);
	Orderbar.add(Price4);
	Orderbar.add(fod5);
	Orderbar.add(p5);
	Orderbar.add(Price5);
	Orderbar.add(fod6);
	Orderbar.add(p6);
	Orderbar.add(Price6);
	Orderbar.add(fod7);
	Orderbar.add(p7);
	Orderbar.add(Price7);
	Orderbar.add(fod8);
	Orderbar.add(p8);
	Orderbar.add(Price8);
	Orderbar.add(fod9);
	Orderbar.add(p9);
	Orderbar.add(Price9);
	Orderbar.add(fod10);
	Orderbar.add(p10);
	Orderbar.add(Price10);
	Orderbar.add(Add);
	Orderbar.add(Cancel);
	
	Orderbar.setAlignmentX(JPanel.LEFT_ALIGNMENT);
	Orderbar.setLayout(null);
	
	paymentbar = new JPanel();
	paymentbar.setBackground(new Color(255,76,48));
	paymentbar.setBounds(110,500,880,150);  
	
	cl = new JLabel("Total Price");
	cl.setBounds(100,-170, 400, 400);
	cl.setForeground(new Color (255, 255, 7));
	cl.setFont(new Font("Verdana", Font.PLAIN, 20));
	
	Price = new JTextField();
	Price.setText(""+0);
	Price.setBounds(80,60, 150, 40);
	Price.setFont(new Font("Verdana", Font.PLAIN, 20));
	
	balae = new JLabel("Enter Your Balance");
	balae.setBounds(300,-170, 400, 400);
	balae.setForeground(new Color (255, 255, 7));
	balae.setFont(new Font("Verdana", Font.PLAIN, 20));
	
	Gui1 = new JTextField();
	Gui1.setText(""+0);
	Gui1.setBounds(320,60, 150, 40);
	Gui1.setFont(new Font("Verdana", Font.PLAIN, 20));
	
	atm = new JLabel("ATM Number");
	atm.setBounds(550,-170, 400, 400);
	atm.setForeground(new Color (255, 255, 7));
	atm.setFont(new Font("Verdana", Font.PLAIN, 20));
	
	Gui2 = new JTextField();
	Gui2.setBounds(550,60, 150, 40);
	Gui2.setFont(new Font("Verdana", Font.PLAIN, 20));
	
	
	paynow = new JButton("Pay Now!");
	paynow.setBounds(750,60, 100, 40);
	paynow.setForeground(new Color (255, 255, 255));
	paynow.setBackground(new Color (0, 255, 0));
	paynow.setFont(new Font("Verdana", Font.PLAIN, 14));
	paynow.addActionListener(this);
	
	paymentbar.add(Price);
	paymentbar.add(cl);
	paymentbar.add(balae);
	paymentbar.add(Gui1);
	paymentbar.add(atm);
	paymentbar.add(Gui2);
	paymentbar.add(paynow);
	Border payment = new LineBorder(Color.BLACK, 4, true);
	paymentbar.setBorder(payment);
	paymentbar.setAlignmentX(JPanel.LEFT_ALIGNMENT);
	paymentbar.setLayout(null);
	
	
	
	
	this.setSize(1024 , 720);
	this.setResizable(false);
	this.setVisible(true);
	this.add(sidebar);
	this.add(navbar);
	this.add(homes);
	this.add(Orderbar);
	this.add(paymentbar);
	this.setTitle("Shop");
	this.setLocationRelativeTo(null);
	this.getContentPane().setBackground(new Color(255, 255, 255));
}


@Override
public void actionPerformed(ActionEvent e) {
	
	//quantity of an item
	
	int r =  Integer.parseInt(p1.getText());
	int m = Integer.parseInt(p2.getText());
	int c = Integer.parseInt(p3.getText());
	int h = Integer.parseInt(p4.getText());
	int c1 = Integer.parseInt(p5.getText());
	int v = Integer.parseInt(p6.getText());
	int b = Integer.parseInt(p7.getText());
	int bf = Integer.parseInt(p8.getText());
	int w = Integer.parseInt(p9.getText());
	int mar = Integer.parseInt(p10.getText());
	//add all the quantity and price
	int total = (r *100) + (m * 150) + (c * 210) + (h * 300) + (c1 * 450) + (v * 150) + (b * 500) + (bf * 700) + (w * 800) + (mar * 750);
	if (e.getSource()==Cancel) {
		p1.setText(""+df);
		p2.setText(""+df);
		p3.setText(""+df);
		p4.setText(""+df);
		p5.setText(""+df);
		p6.setText(""+df);
		p7.setText(""+df);
		p8.setText(""+df);
		p9.setText(""+df);
		p10.setText(""+df);
		Price.setText(""+df);
	}
	if (e.getSource()==k) {
		JOptionPane.showMessageDialog(this, "Input a number in the selected pizza you want , and click add to total the price , and cancel to cancel the price. Also enter your bal and credit card to proceed",
                "Guide", JOptionPane.INFORMATION_MESSAGE);
	}
	if (e.getSource()==complain) {
		dispose();
		complain window = new complain();
		Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
		window.setIconImage(icon);    
		window.setLayout(null); 
	}
	if (e.getSource()==logout) {
		 int result = JOptionPane.showConfirmDialog(home,"Are you sure to exit?", "Logout",
	               JOptionPane.YES_NO_OPTION,
	               JOptionPane.QUESTION_MESSAGE);
	            if(result == JOptionPane.YES_OPTION){
	            	dispose();
	            	JOptionPane.showMessageDialog(this, "You Sucessfully Logout",
	                        "Success", JOptionPane.INFORMATION_MESSAGE);
	            
	            	loginpizz main = new loginpizz();
	            	Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
	        		main.setIconImage(icon);    
	        		main.setLayout(null);
	            
	            }else {
	            	shop mains = new shop();
	       		 Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
	       		 mains.setIconImage(icon);    
	       		 mains.setLayout(null); 
	            }
	}
	if (e.getSource()==home) {
		dispose();
		home main1 = new home();
    	Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
    	main1.setIconImage(icon);    
    	main1.setLayout(null);
	}
	if (e.getSource()==shop) {
		dispose();
		 shop mains = new shop();
		 Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
		 mains.setIconImage(icon);    
		 mains.setLayout(null); 
	}
	if (e.getSource()==user) {
		dispose();
		user main = new user ();
		 Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
		 main .setIconImage(icon);    
		 main .setLayout(null);  
	}
	if (e.getSource()==Add) {
		
		
		Price.setText(""+total);
	
}
	//button paynow functions
	if (e.getSource()==paynow) {
		String id = Gui2.getText();
		int g = Integer.parseInt(Price.getText());
		int bl= Integer.parseInt(Gui1.getText());
		
		if (Gui1.getText().isEmpty() ) {
			 JOptionPane.showMessageDialog(this, "Please Enter Your Money Balance",
                 "ERROR", JOptionPane.ERROR_MESSAGE);
		}
		if (Gui2.getText().isEmpty() ) {
			 JOptionPane.showMessageDialog(this, "Please fill in the ATM Number",
                   "ERROR", JOptionPane.ERROR_MESSAGE);
		}
		
		if (Price.getText().isEmpty() ) {
			 JOptionPane.showMessageDialog(this, "Total Price is Empty",
                 "ERROR", JOptionPane.ERROR_MESSAGE);
		}
		if (g>bl) {
			
			JOptionPane.showMessageDialog(this, "Insufficient balance ",
	                  "ERROR", JOptionPane.ERROR_MESSAGE);
		}
		else {
			Price.setText(""+0);
			Gui1.setText(""+0);
			Gui2.setText("Enter Your Code");
			
			int payment = bl - total;
			JLabel hericon = new JLabel(new ImageIcon("peso.png"));
	         ImageIcon icon = new ImageIcon(new ImageIcon("src/icons/peso.png").getImage().getScaledInstance(50,50, Image.SCALE_SMOOTH));
	         JOptionPane.showMessageDialog(null, "Your Credit Balance is now  " + payment,null, JOptionPane.INFORMATION_MESSAGE, icon);
		}

	}
}
}
