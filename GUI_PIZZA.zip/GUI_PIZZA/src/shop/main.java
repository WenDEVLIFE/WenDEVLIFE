package shop;

import java.awt.Image;
import java.awt.Toolkit;

public class main {
	public static void main(String [] args) {
		 shop mains = new shop();
		 Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
		 mains.setIconImage(icon);    
		 mains.setLayout(null);  
	}
}
