package home;

import java.awt.Image;
import java.awt.Toolkit;

public class main1 {
public static void main(String [] args) {
	 home main1 = new home();
	 Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
	 main1.setIconImage(icon);    
	 main1.setLayout(null);  
}
}
