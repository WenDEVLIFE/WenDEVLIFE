package loginmain;

import java.awt.Image;
import java.awt.Toolkit;

public class main {
	public static void main(String []args) {
		
		loginpizz main = new loginpizz();
		Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
		main.setIconImage(icon);    
		main.setLayout(null);  
	}
}
