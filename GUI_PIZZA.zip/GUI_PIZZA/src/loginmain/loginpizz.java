package loginmain;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Shape;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import home.home;

public class loginpizz extends JFrame implements ActionListener {
	JPanel form;
	JButton pizza;
	JButton pizzaman;
	JLabel Logintitle, login, pass1, copyright;
	JPasswordField pass;
	JTextField User;
	JButton LOGIN;
	JCheckBox checkBox1;

public loginpizz() {

	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setLayout(null);
	
	//logo
	pizza= new JButton("");
	ImageIcon i = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\piz.png").getImage().getScaledInstance(400, 400, Image.SCALE_SMOOTH));
	pizza.setIcon(i);
	pizza.setBounds(500,150, 400, 400);
	pizza.setFocusable(false);
	pizza.setOpaque(false);
	pizza.setContentAreaFilled(false);
	pizza.setBorderPainted(false);
	this.add(pizza);
	
	//connected to form panel
	pizzaman= new JButton("");
	ImageIcon p = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizzaman.png").getImage().getScaledInstance(91, 91, Image.SCALE_SMOOTH));
	pizzaman.setIcon(p);
	pizzaman.setBounds(250,50, 91, 91);
	pizzaman.setFocusable(false);
	pizzaman.setOpaque(false);
	pizzaman.setContentAreaFilled(false);
	pizzaman.setBorderPainted(false);
	
	Logintitle = new JLabel("Login");
	Logintitle.setBounds(150, 30, 300, 300);
	Logintitle.setHorizontalAlignment(JLabel.CENTER);
	Logintitle.setForeground(new Color (255,255,255));
	Logintitle.setFont(new Font("Verdana", Font.PLAIN, 30));
	

	login = new JLabel("Username");
	login.setBounds(20, 100, 300, 300);
	login.setHorizontalAlignment(JLabel.CENTER);
	login.setForeground(new Color (255,255,255));
	login.setFont(new Font("Verdana", Font.PLAIN, 16));
	
	
	User = new RoundedJTextField();
	User = new JTextField();
	User.setFont(new Font("Sans-Serif", Font.PLAIN, 20));
	User.setBounds(220,240,250,30);
	
	pass1 = new JLabel("Password");
	pass1.setBounds(20, 200, 300, 300);
	pass1.setFont(new Font("Sans-Serif", Font.PLAIN, 20));
	pass1.setHorizontalAlignment(JLabel.CENTER);
	pass1.setForeground(new Color (255,255,255));
	pass = new JPasswordField(15);
	pass.setFont(new Font("Verdana", Font.PLAIN, 16));
	pass.setBounds(220,340,250,30);

	 LOGIN = new JButton("Login");
	 LOGIN.setBounds(200,500,250,30);
	 LOGIN.addActionListener(this);
	 
	 copyright = new JLabel("@Copyright 2023");
	 copyright.setBounds(40, 480, 300, 300);
	 copyright.setHorizontalAlignment(JLabel.CENTER);
	 copyright.setForeground(new Color (255,255,255));
	 copyright.setFont(new Font("Verdana", Font.PLAIN, 16));
	
		checkBox1 = new JCheckBox("Show Password");  
	    checkBox1.setBounds(200,400,130,30); 
	    checkBox1.setForeground(new Color (255,255,255));
	    checkBox1.setBackground (new Color(217, 30, 24));
	    checkBox1.addActionListener(this);
	

	//form
	form = new JPanel();
	form.setBackground(new Color(217, 30, 24));
	form.setBounds(-100,0,500,1300);  
	form.setAlignmentX(JPanel.LEFT_ALIGNMENT);
	form.add(pizzaman); 
	form.add(Logintitle); 
	form.add(login);
	form.add(User);
	form.add(pass1);
	form.add(pass);
	form.add(LOGIN);
	form.add(checkBox1);
	form.add(copyright);
	form.setLayout(null);

	

	
	
	
	
	
	
	
	
	
	this.add(form);
	this.setSize(1024 , 720);
	this.setResizable(false);
	this.setVisible(true);
	this.setTitle("Pizza Ordering System by:WenDevLife");
	this.setLocationRelativeTo(null);
	this.getContentPane().setBackground(new Color(255, 255, 255));

}
class RoundedJTextField extends JTextField {
	   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Shape shape;
	   public RoundedJTextField(int size) {
	   super(size);
	   setOpaque(false);
	}
public RoundedJTextField() {
		// TODO Auto-generated constructor stub
	}
public RoundedJTextField(JTextField user1) {
	// TODO Auto-generated constructor stub
}
protected void paintComponent(Graphics g) {
	   g.setColor(getBackground());
	   g.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 15, 15);
	   super.getComponentGraphics(g);
	}
	protected void paintBorder(Graphics g) {
	   g.setColor(getForeground());
	   g.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 15, 15);
	}
	public boolean contains(int x, int y) {
		   if (shape == null || !shape.getBounds().equals(getBounds())) {
		      shape = new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 15, 15);
		   }
		   return shape.contains(x, y);
		   }
		}

@Override
public void actionPerformed(ActionEvent e) {
	// Get the value of UseField and PassField
	String userValue = User.getText(); 
	// to get the value of Password
	String passValue = new String(pass.getPassword());
	if (e.getSource()==checkBox1) {
		
		if (checkBox1.isSelected()) {
		      pass.setEchoChar((char)0);
			} 
			
			if (!checkBox1.isSelected()) {
			   pass.setEchoChar('*');
			}
			
	}
	if (e.getSource()==LOGIN) {
		
		  if (userValue.equals("WenAdmin") && passValue.equals("wenpizza2023")) {  //if authentic, navigate user to a new page  
			  JOptionPane.showMessageDialog(this, "User Successfully Login",
                     "Success", JOptionPane.INFORMATION_MESSAGE);
			  dispose();
			  home main1 = new home();
				 Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
				 main1.setIconImage(icon);    
				 main1.setLayout(null); 
			 
	        }  else {
	        	JOptionPane.showMessageDialog(this, "Username and Password is empty or incorrect",
	        			"ERROR", JOptionPane.ERROR_MESSAGE);
	        }
                    
	      
	}
	
}
}
