package user;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollBar;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import complain.complain;
import home.home;
import loginmain.loginpizz;
import shop.shop;

public class user extends JFrame implements ActionListener {
	// panels
	
		JPanel sidebar;
		JPanel navbar;
		JPanel order;
		JPanel homes;
		JPanel money;
		JPanel complaints;
		JPanel Activity;
		JPanel results;
		
		//labels
		JLabel log;
		JLabel hehe;
		JLabel title;
		JLabel money1;
		JLabel troll;
		JLabel shop1;
		JLabel balance;
		JLabel or;
		JLabel h1;
		JLabel cl;
		JLabel c2;
		JLabel user1;
		JLabel complain;
		JLabel Activities;
		JLabel no_found;
		JLabel no_found1;
		JLabel u;
		JLabel u1;
		JLabel p1;
		JLabel p;
		//integrs
		double bal=1000.00;
		int orders =0;
		int c;
		
		//buttons
		JButton pera;
		JButton pizza;
		JButton logout;
		JButton home;
		JButton shop;
		JButton complain1;
		JButton trolley;
		JButton comp;
		JButton user;
		JButton change;
		JButton change1;
		
		//scrollbar
		JScrollBar meow;
		
		JTextField myuser;
		JTextField myuser1;
		JPasswordField mypass;
		JPasswordField mypass1;

public user() {
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setLayout(null);
	logout= new JButton("");
	ImageIcon i = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\logout.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
	logout.setIcon(i);
	logout.setBounds(800,10, 51, 51);
	logout.setFocusable(false);
	logout.setOpaque(false);
	logout.setContentAreaFilled(false);
	logout.setBorderPainted(false);
	logout.addActionListener(this);
	
	
    
	//sidebar
	sidebar= new JPanel();
	sidebar.setBackground(new Color(217, 30, 24));
	sidebar.setBounds(-100,80,200,1300);  
	
	home = new JButton();
	ImageIcon h = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\homes1.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
	home.setIcon(h);
	home.setBounds(120,30, 51, 51);
	home.setFocusable(false);
	home.setOpaque(false);
	home.setContentAreaFilled(false);
	home.setBorderPainted(false);
	home.addActionListener(this);
	
	h1 = new JLabel("Home");
	h1.setBounds(120,50, 200, 91);
	h1.setForeground(new Color (255,255,255));
	h1.setFont(new Font("Verdana", Font.PLAIN, 16));
	
	shop = new JButton();
	ImageIcon s = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\trolley.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
	shop.setIcon(s);
	shop.setBounds(110,150, 51, 51);
	shop.setFocusable(false);
	shop.setOpaque(false);
	shop.setContentAreaFilled(false);
	shop.setBorderPainted(false);
	shop.addActionListener(this);
	
	shop1 = new JLabel("Shop");
	shop1 .setBounds(120,170, 200, 91);
	shop1 .setForeground(new Color (255,255,255));
	shop1 .setFont(new Font("Verdana", Font.PLAIN, 16));
	
	complain1 = new JButton();
	ImageIcon sc = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\service.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
	complain1.setIcon(sc);
	complain1.setBounds(120,270, 51, 51);
	complain1.setFocusable(false);
	complain1.setOpaque(false);
	complain1.setContentAreaFilled(false);
	complain1.setBorderPainted(false);
	complain1.addActionListener(this);
	
	c2 = new JLabel("Feedback");
	c2 .setBounds(110,290, 200, 91);
	c2 .setForeground(new Color (255,255,255));
	c2 .setFont(new Font("Verdana", Font.PLAIN, 16));
	
	user = new JButton();
	ImageIcon l = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\user.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
	user.setIcon(l);
	user.setBounds(120,400, 51, 51);
	user.setFocusable(false);
	user.setOpaque(false);
	user.setContentAreaFilled(false);
	user.setBorderPainted(false);
	user.addActionListener(this);
	
	user1 = new JLabel("User info");
	user1 .setBounds(110,420, 200, 91);
	user1.setForeground(new Color (255,255,255));
	user1.setFont(new Font("Verdana", Font.PLAIN, 16));
	sidebar.add(home);
	sidebar.add(h1);
	sidebar.add(shop);
	sidebar.add(shop1);
	sidebar.add(complain1);
	sidebar.add(c2);
	sidebar.add(user);
	sidebar.add(user1);
	sidebar.setAlignmentX(JPanel.LEFT_ALIGNMENT);
	sidebar.setLayout(null);
	
	
//order panel

			
	//navbar
	navbar= new JPanel();
	navbar.setBackground(new Color(217, 30, 24));
	navbar.setBounds(0,0,1200,80);  
	
	pizza= new JButton("");
	ImageIcon e = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\piz.png").getImage().getScaledInstance(91, 91, Image.SCALE_SMOOTH));
	pizza.setIcon(e);
	pizza.setBounds(10,-5, 91, 91);
	pizza.setFocusable(false);
	pizza.setOpaque(false);
	pizza.setContentAreaFilled(false);
	pizza.setBorderPainted(false);
	
	title = new JLabel("Pizza Ordering System");
	title.setBounds(120,-170, 400, 400);
	title.setForeground(new Color (255,255,255));
	title.setFont(new Font("Verdana", Font.PLAIN, 35));
	
	log = new JLabel("Logout");
	log.setBounds(860,-10, 200, 91);
	log.setForeground(new Color (255,255,255));
	log.setFont(new Font("Verdana", Font.PLAIN, 16));
	
	navbar.add(pizza);
	navbar.add(title);
	navbar.add(logout);
	navbar.add(log);
	navbar.setAlignmentX(JPanel.LEFT_ALIGNMENT);
	navbar.setLayout(null);
	
	homes= new JPanel();
	homes.setBackground(new Color(249, 105, 14));
	homes.setBounds(110,110,880,50);  
	
	hehe = new JLabel("User information");
	hehe.setBounds(1,-180, 400, 400);
	hehe.setForeground(new Color (255,255,255));
	hehe.setFont(new Font("Verdana", Font.PLAIN, 30));
	
	homes.add(hehe);
	homes.setAlignmentX(JPanel.LEFT_ALIGNMENT);
	homes.setLayout(null);

	// result
	results = new JPanel();
	Border payment1 = new LineBorder(Color.BLACK, 4, true);
	results.setBorder(payment1);
	results.setBackground(new Color(255, 76, 48));
	results.setBounds(110,180,880,450);
	
	no_found = new JLabel("Your User information");
	no_found.setBounds(50,-170, 400, 400);
	no_found.setForeground(new Color (255,255,255));
	no_found.setFont(new Font("Verdana", Font.PLAIN, 20));
	
	no_found1 = new JLabel("Change Information");
	no_found1.setBounds(630,-170, 400, 400);
	no_found1.setForeground(new Color (255,255,255));
	no_found1.setFont(new Font("Verdana", Font.PLAIN, 20));
	
	u = new JLabel("Username");
	u.setBounds(50,-120, 400, 400);
	u.setForeground(new Color (255,255,255));
	u.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	myuser = new JTextField("WenAdmin");
	myuser.setBounds(130,65, 200, 30);
	myuser.setFont(new Font("Verdana", Font.PLAIN, 14));
	myuser.setEditable(false);
	
	p = new JLabel("Password");
	p.setBounds(50,-60, 400, 400);
	p.setForeground(new Color (255,255,255));
	p.setFont(new Font("Verdana", Font.PLAIN, 14));
	p.setFocusable(true);
	
	mypass = new JPasswordField("wenpizza2023");
	mypass.setBounds(130,120, 200, 30);
	mypass.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	u1 = new JLabel("Username");
	u1.setBounds(550,-120, 400, 400);
	u1.setForeground(new Color (255,255,255));
	u1.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	myuser1 = new JTextField("");
	myuser1.setBounds(650,65, 200, 30);
	myuser1.setFont(new Font("Verdana", Font.PLAIN, 14));
	
	
	p1 = new JLabel("Password");
	p1.setBounds(550,-60, 400, 400);
	p1.setForeground(new Color (255,255,255));
	p1.setFont(new Font("Verdana", Font.PLAIN, 14));
	p1.setFocusable(true);
	
	mypass1 = new JPasswordField("");
	mypass1.setBounds(650,120, 200, 30);
	mypass1.setFont(new Font("Verdana", Font.PLAIN, 14));
	 change = new JButton("Change");
	 change.setBounds(300,200, 100, 40);
	 change.setForeground(new Color (255, 255, 255));
	 change.setBackground(new Color (0, 255, 0));
	 change.setFont(new Font("Verdana", Font.PLAIN, 14));
	 change.addActionListener(this);
	 
	 change1 = new JButton("Cancel");
	 change1.setBounds(450,200, 100, 40);
	 change1.setForeground(new Color (255, 255, 255));
	 change1.setBackground(new Color (255,0,0));
	 change1.setFont(new Font("Verdana", Font.PLAIN, 14));
	 change1.addActionListener(this);
	results.add(no_found);
	results.add(no_found1);
	results.add(u);
	results.add(myuser);
	results.add(p);
	results.add(mypass);
	results.add(u1);
	results.add(myuser1);
	
	results.add(p1);
	results.add(mypass1);
	results.add(change);
	results.add(change1);
	results.setAlignmentX(JPanel.LEFT_ALIGNMENT);
	results.setLayout(null);
	
	this.setSize(1024 , 720);
	this.setResizable(false);
	this.setVisible(true);
	this.add(sidebar);
	this.add(navbar);
	this.add(homes);
	this.add(results);
	this.setTitle("User info");
	this.setLocationRelativeTo(null);
	this.getContentPane().setBackground(new Color(255, 255, 255));
}


@Override
public void actionPerformed(ActionEvent e) {
	String i = myuser1.getText();
	String d = new String(mypass1.getPassword());
	if (e.getSource()== change) {
		if (myuser1.getText().isEmpty() && new String(mypass1.getPassword()).isEmpty() ) {
			 JOptionPane.showMessageDialog(this, "Username and Password is empty",
                   "ERROR", JOptionPane.ERROR_MESSAGE);
		} 
		else {
			JOptionPane.showMessageDialog(this, "You Successfully change your information",
	                   "Success", JOptionPane.INFORMATION_MESSAGE);
			myuser.setText(i);
			mypass.setText(d);
			myuser1.setText("");
			mypass1.setText("");
		}
	}
	if (e.getSource()== change1) {
		myuser1.setText("");
		mypass1.setText("");
	}
	if (e.getSource()==complain1) {
		dispose();
		complain window = new complain();
		Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
		window.setIconImage(icon);    
		window.setLayout(null);  
	}
	if (e.getSource()==logout) {
		 int result = JOptionPane.showConfirmDialog(logout,"Are you sure to exit?", "Logout",
	               JOptionPane.YES_NO_OPTION,
	               JOptionPane.QUESTION_MESSAGE);
	            if(result == JOptionPane.YES_OPTION){
	            	dispose();
	            	JOptionPane.showMessageDialog(this, "You Sucessfully Logout",
	                        "Success", JOptionPane.INFORMATION_MESSAGE);
	            
	            	loginpizz main = new loginpizz();
	            	Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
	        		main.setIconImage(icon);    
	        		main.setLayout(null);
	            
	            }else {
	            	user main = new user ();
	           	 Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
	           	 main .setIconImage(icon);    
	           	 main .setLayout(null);
	            }
	}
	if (e.getSource()==home) {
		dispose();
		home main1 = new home();
    	Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
    	main1.setIconImage(icon);    
    	main1.setLayout(null);
	}
	
	if (e.getSource()==shop) {
		dispose();
		 shop mains = new shop();
		 Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
		 mains.setIconImage(icon);    
		 mains.setLayout(null);
	}
	if (e.getSource()==user) {
		dispose();
		user main = new user ();
		 Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
		 main .setIconImage(icon);    
		 main .setLayout(null);  
	}
	
}
}
