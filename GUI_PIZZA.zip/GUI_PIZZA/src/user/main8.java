package user;

import java.awt.Image;
import java.awt.Toolkit;

public class main8 {
public static void main(String [] args) {
	user main = new user ();
	 Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
	 main .setIconImage(icon);    
	 main .setLayout(null);  
}
}
