package complain;

import java.awt.Image;
import java.awt.Toolkit;

public class main5 {
	public static void main (String [] args) {
		complain window = new complain();
		Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
		window.setIconImage(icon);    
		window.setLayout(null);  
	}
}
