package complain;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JTextArea;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import home.home;
import loginmain.loginpizz;
import shop.shop;
import user.user;

public class complain extends JFrame implements ActionListener {
	// panels
		JPanel sidebar;
		JPanel navbar;
		JPanel order;
		JPanel homes;
		JPanel money;
		JPanel complaints;
		JPanel Activity;
		JPanel results;
		
		//labels
		JLabel log;
		JLabel hehe;
		JLabel title;
		JLabel money1;
		JLabel troll;
		JLabel shop1;
		JLabel balance;
		JLabel or;
		JLabel h1;
		JLabel cl;
		JLabel c2;
		JLabel feed;
		JLabel Activities;
		JLabel no_found;
		JLabel user1;
		
		//integrs
		double bal=1000.00;
		int orders =0;
		int c;
		
		
		//buttons
		JButton pera;
		JButton pizza;
		JButton logout;
		JButton home;
		JButton shop;
		JButton complain;
		JButton trolley;
		JButton comp;
		JButton submit;
		JButton user;
		
		//scrollbar
		JScrollBar meow;
		
		JTextArea co;
		
		JComboBox<?> m;

 @SuppressWarnings("unchecked")
public complain() {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		logout= new JButton("");
		ImageIcon i = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\logout.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
		logout.setIcon(i);
		logout.setBounds(800,10, 51, 51);
		logout.setFocusable(false);
		logout.setOpaque(false);
		logout.setContentAreaFilled(false);
		logout.setBorderPainted(false);
		logout.addActionListener(this);
		
		
	    
		//sidebar
		sidebar= new JPanel();
		sidebar.setBackground(new Color(217, 30, 24));
		sidebar.setBounds(-100,80,200,1300);  
		
		home = new JButton();
		ImageIcon h = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\homes1.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
		home.setIcon(h);
		home.setBounds(120,30, 51, 51);
		home.setFocusable(false);
		home.setOpaque(false);
		home.setContentAreaFilled(false);
		home.setBorderPainted(false);
		home.addActionListener(this);
		
		h1 = new JLabel("Home");
		h1.setBounds(120,50, 200, 91);
		h1.setForeground(new Color (255,255,255));
		h1.setFont(new Font("Verdana", Font.PLAIN, 16));
		
		shop = new JButton();
		ImageIcon s = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\trolley.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
		shop.setIcon(s);
		shop.setBounds(110,150, 51, 51);
		shop.setFocusable(false);
		shop.setOpaque(false);
		shop.setContentAreaFilled(false);
		shop.setBorderPainted(false);
		shop.addActionListener(this);
		
		shop1 = new JLabel("Shop");
		shop1 .setBounds(120,170, 200, 91);
		shop1 .setForeground(new Color (255,255,255));
		shop1 .setFont(new Font("Verdana", Font.PLAIN, 16));
		
		complain = new JButton();
		ImageIcon sc = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\service.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
		complain.setIcon(sc);
		complain.setBounds(120,270, 51, 51);
		complain.setFocusable(false);
		complain.setOpaque(false);
		complain.setContentAreaFilled(false);
		complain.setBorderPainted(false);
		complain.addActionListener(this);
		
		c2 = new JLabel("Feedback");
		c2 .setBounds(110,290, 200, 91);
		c2 .setForeground(new Color (255,255,255));
		c2 .setFont(new Font("Verdana", Font.PLAIN, 16));
		user = new JButton();
		ImageIcon l = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\user.png").getImage().getScaledInstance(51, 51, Image.SCALE_SMOOTH));
		user.setIcon(l);
		user.setBounds(120,400, 51, 51);
		user.setFocusable(false);
		user.setOpaque(false);
		user.setContentAreaFilled(false);
		user.setBorderPainted(false);
		user.addActionListener(this);
		
		user1 = new JLabel("User info");
		user1 .setBounds(110,420, 200, 91);
		user1.setForeground(new Color (255,255,255));
		user1.setFont(new Font("Verdana", Font.PLAIN, 16));
		sidebar.add(home);
		sidebar.add(h1);
		sidebar.add(shop);
		sidebar.add(shop1);
		sidebar.add(complain);
		sidebar.add(c2);
		sidebar.add(user);
		sidebar.add(user1);
		sidebar.setAlignmentX(JPanel.LEFT_ALIGNMENT);
		sidebar.setLayout(null);
		
		
	//order panel
		order = new JPanel();
		order.setBackground(new Color(63, 195, 128));
		order.setBounds(150,180,250,150); 
		
		//trolley
		trolley = new JButton();
		ImageIcon t = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\trolley.png").getImage().getScaledInstance(91, 91, Image.SCALE_SMOOTH));
		trolley.setIcon(t);
		trolley.setBounds(70,25, 91, 91);
		trolley.setFocusable(false);
		trolley.setOpaque(false);
		trolley.setContentAreaFilled(false);
		trolley.setBorderPainted(false);
		trolley.addActionListener(this);
	
		
				
		//navbar
		navbar= new JPanel();
		navbar.setBackground(new Color(217, 30, 24));
		navbar.setBounds(0,0,1200,80);  
		
		pizza= new JButton("");
		ImageIcon e = new ImageIcon(new ImageIcon("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\piz.png").getImage().getScaledInstance(91, 91, Image.SCALE_SMOOTH));
		pizza.setIcon(e);
		pizza.setBounds(10,-5, 91, 91);
		pizza.setFocusable(false);
		pizza.setOpaque(false);
		pizza.setContentAreaFilled(false);
		pizza.setBorderPainted(false);
		
		title = new JLabel("Pizza Ordering System");
		title.setBounds(120,-170, 400, 400);
		title.setForeground(new Color (255,255,255));
		title.setFont(new Font("Verdana", Font.PLAIN, 35));
		
		log = new JLabel("Logout");
		log.setBounds(860,-10, 200, 91);
		log.setForeground(new Color (255,255,255));
		log.setFont(new Font("Verdana", Font.PLAIN, 16));
		
		navbar.add(pizza);
		navbar.add(title);
		navbar.add(logout);
		navbar.add(log);
		navbar.setAlignmentX(JPanel.LEFT_ALIGNMENT);
		navbar.setLayout(null);
		
		homes= new JPanel();
		homes.setBackground(new Color(249, 105, 14));
		homes.setBounds(110,110,880,50);  
		
		hehe = new JLabel("Leave a Feedback");
		hehe.setBounds(1,-180, 400, 400);
		hehe.setForeground(new Color (255,255,255));
		hehe.setFont(new Font("Verdana", Font.PLAIN, 30));
		
		homes.add(hehe);
		homes.setAlignmentX(JPanel.LEFT_ALIGNMENT);
		homes.setLayout(null);
		
		results = new JPanel();
		Border payment12 = new LineBorder(Color.BLACK, 4, true);
		results.setBorder(payment12);
		results.setBackground(new Color(255, 76, 48));
		results.setBounds(110,180,880,450);
		 String list [] = {"Select an option","App Error","Crash Application", "Bugs" , "Login Error"};
		    m = new JComboBox<Object>(list);
		    m.setBounds(30,50,150,30);
		    
		    feed= new JLabel("Leave a message");
		    feed.setBounds(30,-20, 200, 91);
		    
		    feed.setForeground(new Color (255,255,255));
		    feed.setFont(new Font("Verdana", Font.PLAIN, 16));
		    
		    co=new JTextArea(); 
		    co.setFont(new Font("Verdana", Font.PLAIN, 14));
		    Border payment1 = new LineBorder(Color.ORANGE, 4, true);
		    co.setBorder(payment1);
		    co.setBounds(20,120,800,200);  
		    
		    submit = new JButton("Submit");
		    submit.setBounds(350 ,350, 100, 40);
		    submit.setForeground(new Color (255, 255, 255));
		    submit.setBackground(new Color (0, 255, 0));
		    submit.setFont(new Font("Verdana", Font.PLAIN, 14));
		    submit.addActionListener(this);
			
		results.add(m);
		results.add(feed);
		results.add(co);
		results.add(submit);
		results.setAlignmentX(JPanel.LEFT_ALIGNMENT);
		results.setLayout(null);
		
		this.setSize(1024 , 720);
		this.setResizable(false);
		this.setVisible(true);
		this.add(sidebar);
		this.add(navbar);
		this.add(homes);
		this.add(results);
		this.setTitle("Feedback");
		this.setLocationRelativeTo(null);
		this.getContentPane().setBackground(new Color(255, 255, 255));
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		String l  = co.getText();
		if (e.getSource()==user) {
			dispose();
			user main = new user ();
			 Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
			 main .setIconImage(icon);    
			 main .setLayout(null);  
		}
		if (e.getSource()==submit) {
			
			if (co.getText().isEmpty() ) {
				 JOptionPane.showMessageDialog(this, "Please Fill Up the Text Area",
		                  "ERROR", JOptionPane.ERROR_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(this, "Submitted Success!",
	                    "Success", JOptionPane.INFORMATION_MESSAGE);
				dispose();
				complain window = new complain();
				Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
				window.setIconImage(icon);    
				window.setLayout(null);
			}
			
		}
		if (e.getSource()==complain) {
			dispose();
			complain window = new complain();
			Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
			window.setIconImage(icon);    
			window.setLayout(null); 
		}
		if (e.getSource()==logout) {
			 int result = JOptionPane.showConfirmDialog(home,"Are you sure to exit?", "Logout",
		               JOptionPane.YES_NO_OPTION,
		               JOptionPane.QUESTION_MESSAGE);
		            if(result == JOptionPane.YES_OPTION){
		            	dispose();
		            	JOptionPane.showMessageDialog(this, "You Sucessfully Logout",
		                        "Success", JOptionPane.INFORMATION_MESSAGE);
		            
		            	loginpizz main = new loginpizz();
		            	Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
		        		main.setIconImage(icon);    
		        		main.setLayout(null);
		            
		            }else {
		            	dispose();
		            	complain window = new complain();
		    			Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
		    			window.setIconImage(icon);    
		    			window.setLayout(null); 
		            	
		            }
		}
		if (e.getSource()==home) {
			dispose();
			home main1 = new home();
	    	Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
	    	main1.setIconImage(icon);    
	    	main1.setLayout(null);
		}
		if (e.getSource()==shop) {
			dispose();
			 shop mains = new shop();
			 Image icon = Toolkit.getDefaultToolkit().getImage("D:\\Programming\\Eclipseproject\\GUI_PIZZA\\src\\icons\\pizza.png");    
			 mains.setIconImage(icon);    
			 mains.setLayout(null);
		}
		
	}

}
